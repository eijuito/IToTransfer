/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  30/05/2021                                                               */
/*                                                                                      */
/* Sistema: Business Web                                                                */
/* Funcionalidade: ID1005 Emitir Boleto                                                 */
/* Pre-requisitos: Consorciado (Grupo/Cota/Versão) precisa ter boleto pendente, sendo   */
/* que o script seleciona a segunda pendência da lista                                  */
/****************************************************************************************/

Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("ID1005_BW_01_LoadURL");
	
	web_reg_save_param_regexp(
		"ParamName=cViewState",
		"RegExp=id=\"__VIEWSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/frmCorCCCnsLogin.aspx*",
		LAST);    

	web_reg_save_param_regexp(
		"ParamName=cEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/frmCorCCCnsLogin.aspx*",
		LAST);

	web_reg_find("Search=All",
		"Text=Esqueci minha senha",
		LAST);

	web_url("frmCorCCCnsLogin.aspx", 
		"URL=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=WebResource.axd?d=pynGkmcFUV13He1Qd6_TZMxFz5IKif1KtW2p74pW1IfdKOxWKLrwLie54aYU_oGjxAKlvA2&t=637460873481343508", ENDITEM, 
		"Url=WebResource.axd?d=JoBkLzP19aTuxbWOhHobYlCD3IF2HpnPRl2uT83w-Q91Zsyx9KUoKs-5JzEly0j_ibsEbQ2&t=637460873481343508", ENDITEM, 
		"Url=https://iecvlist.microsoft.com/ie11blocklist/1401746408/versionlist.xml", "Referer=", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_BW_01_LoadURL", LR_AUTO);

	lr_think_time(1);

	lr_start_transaction("ID1005_BW_02_Login");

	web_add_cookie("NWASI=hqow0wwkltcf3vgrrc5xfd2d; DOMAIN={pURL}");

	web_add_cookie("SN_AcessoSiebel=N; DOMAIN={pURL}");

	web_add_cookie("CD_Unidade_Negocio=000001; DOMAIN={pURL}");

	web_add_cookie("NWSAT=93B754F7B3BF4BF53606550480EFE6FB9642157658DD375AC1432C52A91A37887851281E8209A637E50C0EA45D4449277E70A9F68FF3EC655374A7A094A60EA4F177BC867DE5A8784E45E97E3FB2C9ADEB38D81A; DOMAIN={pURL}");

	web_add_cookie("NWSTAU=fKJ2rc3JC6pkJCXZS7xnIRvKlZYQdfHaGs8NzvPsLCCP3M5kwNX8tYzK6KPqIJrpLSFE0/iI/BqLpwK1Ewmsxsajvsg/S5CcUOG1z5TXDjwXqs3bGFyP6/+g08OMdDt7JLCPUopj8517wuDlgGgYfs+GnjbbL+oVer3qQnp9uLqRc5lfIQ6hzPHkzp4Wrfud84BPA5TH276ULNY/ARUv0DrAzfUFTgNWWbRF4K3KW17PDt31TKVCb6dr33lXsdnWGP7kI6D0Jt56vOlE1GzEP3Ml8cdBJSkFqpnXzzLKdczoIdEIqcI5FTGEaQ8Wzx01IZEkgQ+lKJB8hZ/wFIX7JlQrgyWUJjWVinp0f7/1idjdvxwi0PHQ+tY8BRs9QTSc+RDFFUMHdoflzYmdogiiNTirW/7UR99mNwvFpYBxSRY=; DOMAIN={pURL}");

	web_add_cookie("trigger_state=Li1; DOMAIN={pURL}");
	
	web_reg_save_param_regexp(
		"ParamName=cVState",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmMain.aspx*",
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=cEventValidation2",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmMain.aspx*",
		LAST);		

	web_submit_data("frmCorCCCnsLogin.aspx_2", 
		"Action=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=btnLogin", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value={cViewState}", ENDITEM, 
		"Name=edtUsuario", "Value={pUsuario}", ENDITEM, 
		"Name=edtSenha", "Value={pSenha}", ENDITEM, 
		"Name=hdnTokenRecaptcha", "Value=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=BC9D8A67", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation}", ENDITEM, 
/*		EXTRARES, 
		"Url=js/cnpAjax.js", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=WebResource.axd?d=5GcSkSOyaAp9rgkHHDGLyx2D0OKDLV07NauD82wFRIs2vQ_Ccf7zx1oVCaSpGgW0R0TI-Q2&t=637460873481343508", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/loading29.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Master_Page.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Fonts.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Menu.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Utils.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/menu.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/left.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=imagens/grid/header.jpg", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/right.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_BW_02_Login",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_03_Atendimento");
	
	web_reg_save_param_regexp(
		"ParamName=cVState2",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConAtSrcConsorciado.aspx*",
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=cEventValidation3",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConAtSrcConsorciado.aspx*",
		LAST);	

	web_submit_data("frmMain.aspx", 
		"Action=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation2}", ENDITEM, 
		"Name=ctl00$img_Atendimento.x", "Value=18", ENDITEM, 
		"Name=ctl00$img_Atendimento.y", "Value=14", ENDITEM, 
/*		EXTRARES, 
		"Url=imagens/menu_right_border.jpg", "Referer=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_BW_03_Atendimento",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_04_LocalizarConsorciado");
	
	web_submit_data("frmConAtSrcConsorciado.aspx", 
		"Action=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState2}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtGrupo", "Value={pGrupo}", ENDITEM, 
		"Name=ctl00$Conteudo$edtCota", "Value={pCota}", ENDITEM, 
		"Name=ctl00$Conteudo$edtVersao", "Value={pVersao}", ENDITEM, 
		"Name=ctl00$Conteudo$btnLocalizar", "Value=Localizar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation3}", ENDITEM, 
/*		EXTRARES, 
		"Url=../js/css/tab/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://{pURL}/NewconWeb/CONAT/frmConAtCnsAtendimento.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_BW_04_LocalizarConsorciado",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_05_EmissaoCobranca");

	web_reg_save_param_regexp(
		"ParamName=cVState3",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);
	
	web_reg_save_param_regexp(
		"ParamName=cDataBase",
		"RegExp=Base_Pendencias\" type=\"text\" value=\"(.*?)\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);	
	
	web_reg_find("Search=All",
		"Text=Alterar valor a receber",
		LAST);

	web_url("Emissão de Cobrança", 
		"URL=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONAT/frmConAtCnsAtendimento.aspx", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=../ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OBWVWyBzSbsk1GHiO89PfBIms69SVgzbqIEAIK3500J5nB9hIYdje4Geiifeoq8sPUvuUESevGr_k4mMEm2gwb6C3dTpzKKs3FCMWcEUmaCaC5lc9_3hWwDGnECxy8WpKxyq14M1&t=2fe674eb", ENDITEM, 
		"Url=../ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvtskd7hFdwKGw538B6WX6lzpBZk5mkVd_9UDNtqDW6fXgrfsbTmiZlKqdG2i6U7OZPhcfD_C6HMF0dVJEtRcsx2mhNbhGKwlFKDqEGraGBO9FYjJvvWR_HqCzmIurzgd7vfgehk1&t=2fe674eb", ENDITEM, 
		"Url=../App_Themes/Default/imagens/radiobutton.jpg", ENDITEM, 
		"Url=../App_Themes/Default/imagens/checkbox.jpg", ENDITEM, 
		"Url=../imagens/info.png", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_BW_05_EmissaoCobranca",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_06_SelecionarPendencia");
		
	web_reg_save_param_regexp(
		"ParamName=cVState4",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);	

	web_reg_find("Search=All",
		"Text=Total a receber",
		LAST);

	web_submit_data("frmConCoRelBoletoAvulso.aspx", 
		"Action=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState3}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtForma", "Value=BB", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Base_Pendencias", "Value={cDataBase}", ENDITEM, 
		"Name=ctl00$Conteudo$edtAgente", "Value=0033", ENDITEM, 
		"Name=ctl00$Conteudo$rdlTipoEmissao", "Value=BA", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso_RowIndex", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hdnPrivilegioDesmarcar", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdn_VL_Total_Receber_Sem_TxCob", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Cota", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Forma_Recebimento", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Agenda_Debito_Avulso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Mesma_Conta_Debito", "Value=N", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=0", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso$ctl03$imgEmite_Boleto.x", "Value=7", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso$ctl03$imgEmite_Boleto.y", "Value=8", ENDITEM, 
		LAST);

	lr_end_transaction("ID1005_BW_06_SelecionarPendencia",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_07_EmitirCobranca");

	web_reg_find("Search=Body",
		"Text=Para sua segurança o boleto foi enviado para registro",
		LAST);

	web_submit_data("frmConCoRelBoletoAvulso.aspx_2", 
		"Action=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$btnEmitir", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState4}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtForma", "Value=BB", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Base_Pendencias", "Value={cDataBase}", ENDITEM, 
		"Name=ctl00$Conteudo$edtAgente", "Value=0033", ENDITEM, 
		"Name=ctl00$Conteudo$rdlTipoEmissao", "Value=BA", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso_RowIndex", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hdnPrivilegioDesmarcar", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdn_VL_Total_Receber_Sem_TxCob", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Cota", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Forma_Recebimento", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Agenda_Debito_Avulso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Mesma_Conta_Debito", "Value=N", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=380", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
//		EXTRARES, 
//		"Url=../CONCM/frmConCmImpressao.aspx?applicationKey=Teane8vcK+xvWWeDYxVN6xzwczjT4CS6VIndDbDM3zI=", "Referer=", ENDITEM, 
		LAST);

	/* antes OK */

/*	web_url("geo2.adobe.com", 
		"URL=https://geo2.adobe.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"x-adobe-uuid,x-adobe-uuid-type,x-api-key");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_auto_header("Origin", 
		"https://rna-resource.acrobat.com");

	web_custom_request("content", 
		"URL=https://p13n.adobe.io/psdk/v2/content?surfaceId=DC_READER_LAUNCH_CARD&surfaceId=DC_Reader_RHP_Banner&surfaceId=DC_Reader_RHP_Retention&surfaceId=Edit_InApp_Aug2020&adcProductLanguage=en-us&adcVersion=21.1.20155&adcProductType=Reader&adcOSType=WIN&adcCountryCode=US&adcXAPIClientID=api_reader_desktop_win_21.1.20155&encodingScheme=BASE_64", 
		"Method=OPTIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://rna-resource.acrobat.com/task_handler", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("x-adobe-uuid", 
		"097f6347-4432-46d2-a0a6-317e9be99656");

	web_add_header("x-adobe-uuid-type", 
		"visitorId");

	web_add_header("x-api-key", 
		"AdobeReader9");

	web_url("content_2", 
		"URL=https://p13n.adobe.io/psdk/v2/content?surfaceId=DC_READER_LAUNCH_CARD&surfaceId=DC_Reader_RHP_Banner&surfaceId=DC_Reader_RHP_Retention&surfaceId=Edit_InApp_Aug2020&adcProductLanguage=en-us&adcVersion=21.1.20155&adcProductType=Reader&adcOSType=WIN&adcCountryCode=US&adcXAPIClientID=api_reader_desktop_win_21.1.20155&encodingScheme=BASE_64", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://rna-resource.acrobat.com/task_handler", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://acroipm2.adobe.com/21/rdr/ENU/win/nooem/none/consumer/282_21_1_20155.zip", "Referer=", ENDITEM, 
		"Url=https://acroipm2.adobe.com/21/rdr/ENU/win/nooem/none/consumer/283_21_1_20155.zip", "Referer=", ENDITEM, 
		"Url=https://acroipm2.adobe.com/21/rdr/ENU/win/nooem/none/consumer/message.zip", "Referer=", ENDITEM, 
		LAST);*/

	/* Abriu boleto */

	lr_end_transaction("ID1005_BW_07_EmitirCobranca",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_08_Sistema");

	web_add_cookie("trigger_state=menu_trigger_6; DOMAIN={pURL}");

	web_revert_auto_header("Origin");

	web_reg_save_param_attrib(
		"ParamName=cEventValidation4",
		"TagName=input",
		"Extract=value",
		"Name=__EVENTVALIDATION",
		"Id=__EVENTVALIDATION",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_find("Search=All",
		"Text=Acesso Atual",
		LAST);

	web_url("frmMain.aspx_2", 
		"URL=https://{pURL}/NewconWeb/frmMain.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ID1005_BW_08_Sistema",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_BW_09_Logout");

	web_reg_find("Search=All",
		"Text=Esqueci minha senha",
		LAST);

	web_submit_data("frmMain.aspx_3", 
		"Action=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$lkbSair", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=SI", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation4}", ENDITEM, 
		LAST);

	lr_end_transaction("ID1005_BW_09_Logout",LR_AUTO);

	return 0;
}