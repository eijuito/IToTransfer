/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  30/05/2021                                                               */
/*                                                                                      */
/* Sistema: Dealer Web                                                                  */
/* Funcionalidade: ID1005 Emitir Boleto                                                 */
/* Pre-requisitos: Consorciado (Grupo/Cota/Versão) precisa ter boleto pendente, sendo   */
/* que o script seleciona a segunda pendência da lista                                  */
/****************************************************************************************/

Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("ID1005_DW_01_LoadURL");

	web_reg_save_param_regexp(
		"ParamName=cViewState",
		"RegExp=id=\"__VIEWSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/frmCorCCCnsLogin.aspx*",
		LAST);    

	web_reg_save_param_regexp(
		"ParamName=cEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/frmCorCCCnsLogin.aspx*",
		LAST);

	web_reg_find("Search=All",
		"Text=Esqueci minha senha",
		LAST);	
	
	web_url("frmCorCCCnsLogin.aspx", 
		"URL=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=WebResource.axd?d=pynGkmcFUV13He1Qd6_TZPBHnXu7ZaxWEJQONjUh0uJzIKviL8GlJyk2FGJmRLU0Jk-Fpw2&t=637460873481343508", ENDITEM, 
		"Url=WebResource.axd?d=JoBkLzP19aTuxbWOhHobYp_zRKsoSuyrj8a5PDXNFmq_SX-oFb9PS7dOphipmVkHhIli-A2&t=637460873481343508", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_DW_01_LoadURL", LR_AUTO);

	lr_think_time(1);

	lr_start_transaction("ID1005_DW_02_Login");

	web_add_cookie("SN_AcessoSiebel=N; DOMAIN={pURL}");

	web_add_cookie("CD_Unidade_Negocio=000001; DOMAIN={pURL}");

	web_add_cookie("NWASI=zx5walezvul5pezf4kcjt0oz; DOMAIN={pURL}");

	web_add_cookie("NWSAT=7F42DD1A208C84C275535FAA1B6A6B24F9E3AD8DE531B7C05F633DCE2863B4EAE033ECA0BBC5EB26C80F5F0B67373CC050FE8FBD0E4A569A5A295882A92C180A2CD84D165D7D7139BDAC09C6D044E46BCE103DCD; DOMAIN={pURL}");

	web_add_cookie("NWSTAU=TSGkpHVi+JhMcgZa/SiMEPlbmLfMN905cEsQ2yz86nQwZVv8td9BBSiGoTmf8/AgR93wBIPr+wbcuT4HydkDW50xapYwknTsyvdQ7CsxztXIxUGajzYjbSNTlkV0etgjhN9GiduhYTquXACzmIv6Vpx3wS37c5dtqhLtKnJABfl4i3rDxePgBCN1XbwGL2OMuaFeC02QrIbOp7Sx1GunLJaBm10NWAlT1v/xeaG7BbhSujkJX0wRVUUBUvrZEkqzeoVPuFSJO5YW1P6gZV8ny7Be4arfeWmW5jAAr3/xso2avHuwo4TTAipFARNdIOnJmcZMzCGIKl6R4F8os3VfWLFB7iPG66Mp3XKXbjgcCiJWfpqB3mHc6u12KdCCcp66AI7fbMc2qW22wIum6oGZcrBuUrw+0CQJw/jcYmqTZno=; DOMAIN={pURL}");

	web_add_cookie("trigger_state=Li1; DOMAIN={pURL}");
	
	web_reg_save_param_regexp(
		"ParamName=cVState",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmMain.aspx*",
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=cEventValidation2",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmMain.aspx*",
		LAST);

	web_submit_data("frmCorCCCnsLogin.aspx_2", 
		"Action=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmCorCCCnsLogin.aspx", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=btnLogin", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value={cViewState}", ENDITEM, 
		"Name=edtUsuario", "Value={pUsuario}", ENDITEM, 
		"Name=edtSenha", "Value={pSenha}", ENDITEM, 
		"Name=hdnTokenRecaptcha", "Value=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=BC9D8A67", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation}", ENDITEM, 
/*		EXTRARES, 
		"Url=js/cnpAjax.js", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=WebResource.axd?d=5GcSkSOyaAp9rgkHHDGLyxQTOfrJ9CzN7j15_cwWMMPRusmUfNMePmLKH6jROlaipvKXDA2&t=637460873481343508", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/loading29.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Fonts.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Master_Page.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Menu.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Utils.css", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=imagens/grid/header.jpg", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/menu.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/right.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/imagens/left.gif", "Referer=https://{pURL}/NewconWeb/frmMain.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_DW_02_Login",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_03_Atendimento");
	
	web_reg_save_param_regexp(
		"ParamName=cVState2",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConAtSrcConsorciado.aspx*",
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=cEventValidation3",
		"RegExp=id=\"__EVENTVALIDATION\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConAtSrcConsorciado.aspx*",
		LAST);	

	web_submit_data("frmMain.aspx", 
		"Action=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation2}", ENDITEM, 
		"Name=ctl00$img_Atendimento.x", "Value=15", ENDITEM, 
		"Name=ctl00$img_Atendimento.y", "Value=19", ENDITEM, 
/*		EXTRARES, 
		"Url=imagens/menu_right_border.jpg", "Referer=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_DW_03_Atendimento",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_04_LocalizarConsorciado");

	web_submit_data("frmConAtSrcConsorciado.aspx", 
		"Action=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState2}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtGrupo", "Value={pGrupo}", ENDITEM, 
		"Name=ctl00$Conteudo$edtCota", "Value={pCota}", ENDITEM, 
		"Name=ctl00$Conteudo$edtVersao", "Value={pVersao}", ENDITEM, 
		"Name=ctl00$Conteudo$btnLocalizar", "Value=Localizar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation3}", ENDITEM, 
/*		EXTRARES, 
		"Url=../js/css/tab/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://{pURL}/NewconWeb/CONAT/frmConAtCnsAtendimento.aspx", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_DW_04_LocalizarConsorciado",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_05_EmissaoCobranca");

	web_reg_save_param_regexp(
		"ParamName=cVState3",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);
	
	web_reg_save_param_regexp(
		"ParamName=cDataBase",
		"RegExp=Base_Pendencias\" type=\"text\" value=\"(.*?)\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);	
	
	web_reg_find("Search=All",
		"Text=Alterar valor a receber",
		LAST);	
	
	web_url("Emissão de Cobrança", 
		"URL=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONAT/frmConAtCnsAtendimento.aspx", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=../ScriptResource.axd?d=JnUc-DEDOM5KzzVKtsL1tajAxTS08H2-pOCwch7HVSmVC7BDMHoeDrXSGYW9uXfV5n9OLyGmT3BXd24rHZ_XDQDLWn3s4DHMAMZ_CTebwmojzM4BXF4WVHurrWWn4SU578llRmDuczVpCon-PoRiN3kD24kaNCS5-eCtpC9g1kVGDZVM0&t=2fe674eb", ENDITEM, 
		"Url=../ScriptResource.axd?d=D9drwtSJ4hBA6O8UhT6CQrRIdgQu86Uth1binLdOmFRA5OnLWZUCdlEdVdRQtR9GysPwI0q-oMCWskCBC7QJt2T5cV7Rjrwhmcv34bUCoIrUlUe51enEoJbb-8WVyTTfwd7pmtxWmynyZG_i9lq99s7IcZk1&t=2fe674eb", ENDITEM, 
		"Url=../App_Themes/Default/imagens/radiobutton.jpg", ENDITEM, 
		"Url=../imagens/info.png", ENDITEM, 
		"Url=../App_Themes/Default/imagens/checkbox.jpg", ENDITEM, */
		LAST);

	lr_end_transaction("ID1005_DW_05_EmissaoCobranca",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_06_SelecionarPendencia");
	
	web_reg_save_param_regexp(
		"ParamName=cVState4",
		"RegExp=id=\"__VSTATE\"\\ value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/frmConCoRelBoletoAvulso.aspx*",
		LAST);	

	web_reg_find("Search=All",
		"Text=Total a receber",
		LAST);	

	web_submit_data("frmConCoRelBoletoAvulso.aspx", 
		"Action=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState3}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtForma", "Value=BB", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Base_Pendencias", "Value={cDataBase}", ENDITEM, 
		"Name=ctl00$Conteudo$edtAgente", "Value=0033", ENDITEM, 
		"Name=ctl00$Conteudo$rdlTipoEmissao", "Value=BA", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso_RowIndex", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hdnPrivilegioDesmarcar", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdn_VL_Total_Receber_Sem_TxCob", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Cota", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Forma_Recebimento", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Agenda_Debito_Avulso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Mesma_Conta_Debito", "Value=N", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=0", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso$ctl03$imgEmite_Boleto.x", "Value=5", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso$ctl03$imgEmite_Boleto.y", "Value=7", ENDITEM, 
		LAST);

	lr_end_transaction("ID1005_DW_06_SelecionarPendencia",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_07_EmitirCobranca");
	
	web_reg_find("Search=Body",
		"Text=Para sua segurança o boleto foi enviado para registro",
		LAST);	

	web_submit_data("frmConCoRelBoletoAvulso.aspx_2", 
		"Action=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$btnEmitir", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState4}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$edtForma", "Value=BB", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Base_Pendencias", "Value={cDataBase}", ENDITEM, 
		"Name=ctl00$Conteudo$edtAgente", "Value=0033", ENDITEM, 
		"Name=ctl00$Conteudo$rdlTipoEmissao", "Value=BA", ENDITEM, 
		"Name=ctl00$Conteudo$grdBoleto_Avulso_RowIndex", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hdnPrivilegioDesmarcar", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdn_VL_Total_Receber_Sem_TxCob", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Cota", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Debito_Conta_Forma_Recebimento", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Agenda_Debito_Avulso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hid_SN_Mesma_Conta_Debito", "Value=N", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=410", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
/*		EXTRARES, 
		"Url=../CONCM/frmConCmImpressao.aspx?applicationKey=Teane8vcK+xvWWeDYxVN6xzwczjT4CS6VIndDbDM3zI=", "Referer=", ENDITEM, 
		"Url=https://acroipm2.adobe.com/21/rdr/ENU/win/nooem/none/consumer/282_21_1_20155.zip", "Referer=", ENDITEM, */
		LAST);

	/* antes de clicar OK */

	/* Abriu o boleto */

	lr_end_transaction("ID1005_DW_07_EmitirCobranca",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_08_Sistema");

	web_add_cookie("trigger_state=menu_trigger_6; DOMAIN={pURL}");

	web_reg_save_param_attrib(
		"ParamName=cEventValidation4",
		"TagName=input",
		"Extract=value",
		"Name=__EVENTVALIDATION",
		"Id=__EVENTVALIDATION",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_find("Search=All",
		"Text=Acesso Atual",
		LAST);	

	web_url("frmMain.aspx_2", 
		"URL=https://{pURL}/NewconWeb/frmMain.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/CONCO/frmConCoRelBoletoAvulso.aspx", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ID1005_DW_08_Sistema",LR_AUTO);
	
	lr_think_time(1);

	lr_start_transaction("ID1005_DW_09_Logout");
	
	web_reg_find("Search=All",
		"Text=Esqueci minha senha",
		LAST);	

	web_submit_data("frmMain.aspx_3", 
		"Action=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://{pURL}/NewconWeb/frmMain.aspx", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$lkbSair", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={cVState}", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=SI", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={cEventValidation4}", ENDITEM, 
		LAST);

	lr_end_transaction("ID1005_DW_09_Logout",LR_AUTO);

	return 0;
}