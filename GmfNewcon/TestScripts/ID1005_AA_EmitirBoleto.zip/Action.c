//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("ID1005_AA_01_LoadURL");
	truclient_step("1", "Navigate to pURL", "snapshot=Action_1.inf");
	lr_end_transaction("ID1005_AA_01_LoadURL",0);
	lr_start_transaction("ID1005_AA_02_Login");
	truclient_step("2", "Click on CPF/CNPJ textbox", "snapshot=Action_2.inf");
	truclient_step("3", "Type pCPF in CPF/CNPJ textbox", "snapshot=Action_3.inf");
	truclient_step("4", "Click on Senha passwordbox", "snapshot=Action_4.inf");
	truclient_step("5", "Type ****** in Senha passwordbox", "snapshot=Action_5.inf");
	truclient_step("6", "Click on Acessar button", "snapshot=Action_6.inf");
	lr_end_transaction("ID1005_AA_02_Login",0);
	lr_start_transaction("ID1005_AA_03_SelecionarCota");
	truclient_step("7", "Click on Grupo/Cota", "snapshot=Action_7.inf");
	lr_end_transaction("ID1005_AA_03_SelecionarCota",0);
	lr_start_transaction("ID1005_AA_04_Boletos");
	truclient_step("8", "Click on button (1) button", "snapshot=Action_8.inf");
	truclient_step("9", "Click on Servi�os", "snapshot=Action_9.inf");
	truclient_step("10", "Click on 2� Via de Boletos link", "snapshot=Action_10.inf");
	lr_end_transaction("ID1005_AA_04_Boletos",0);
	lr_start_transaction("ID1005_AA_05_SelecionarBoleto");
	truclient_step("12", "Click on / label", "snapshot=Action_12.inf");
	lr_end_transaction("ID1005_AA_05_SelecionarBoleto",0);
	lr_start_transaction("ID1005_AA_06_GerarBoleto");
	truclient_step("14", "Click on Gerar Boleto button", "snapshot=Action_14.inf");
	lr_end_transaction("ID1005_AA_06_GerarBoleto",0);
	lr_start_transaction("ID1005_AA_07_ImprimirBoleto");
	truclient_step("15", "Mouse Over", "snapshot=Action_15.inf");
	{
		truclient_step("15.1", "Move mouse over Boleto Banc�rio", "snapshot=Action_15.1.inf");
	}
	truclient_step("16", "Click on Imprimir Boleto button", "snapshot=Action_16.inf");
	lr_end_transaction("ID1005_AA_07_ImprimirBoleto",0);
	lr_start_transaction("ID1005_AA_09_Confirmar");
	truclient_step("18", "Click on Confirmar button", "snapshot=Action_18.inf");
	lr_end_transaction("ID1005_AA_09_Confirmar",0);
	lr_start_transaction("ID1005_AA_10_Logout");
	truclient_step("20", "Click on button (1) button", "snapshot=Action_20.inf");
	truclient_step("22", "Click on button (3) button", "snapshot=Action_22.inf");
	truclient_step("23", "Mouse Over", "snapshot=Action_23.inf");
	{
		truclient_step("23.1", "Move mouse over Voc� deseja realmente...", "snapshot=Action_23.1.inf");
	}
	truclient_step("24", "Click on Sair button", "snapshot=Action_24.inf");
	lr_end_transaction("ID1005_AA_10_Logout",0);

	return 0;
}
