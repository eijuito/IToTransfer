/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  08/06/2021                                                               */
/*                                                                                      */
/* Sistema: Web Service CRM Dynamics                                                    */
/* Funcionalidade: REQ21 CRM Dynamics Atualizar Endere�o                                */
/* Pre-requisitos: Consorciado (Grupo/Cota/Vers�o), Id do Endere�o, complemento         */
/*                                                                                      */
/****************************************************************************************/

 Action()
{
	char *txName = "REQ21_WS_AtualizarEndereco";
	char sNovoComplemento[1024];
	
	strcpy(sNovoComplemento, lr_eval_string("{pComplementoOriginal} "));
	strcat(sNovoComplemento, lr_eval_string("{pComplementoNumero}"));
	lr_output_message("Atualizando complemento para: %s", sNovoComplemento);
	lr_save_string(sNovoComplemento,"pNovoComplemento");

	// Global Sample Request
    lr_save_string(lr_eval_string("{SampleXML}"),"XMLrequest");

	// dynamic parameters used in XML header

	web_set_max_html_param_len("1000000");


	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//codigoCota",
      "ValueParam=pCota", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//codigoGrupo",
      "ValueParam=pGrupo", LAST);
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//versao",
      "ValueParam=pVersao", LAST);	

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//idEndereco",
      "ValueParam=pIdEndereco", LAST);		
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//complemento",
      "ValueParam=pNovoComplemento", LAST);	

	//Dados n�o atualizados:	
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//bairro",
      "ValueParam=pBairro", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//caixaPostal",
      "ValueParam=pCaixaPostal", LAST);	
   
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//cep",
      "ValueParam=pCEP", LAST);	
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//endereco",
      "ValueParam=pEndereco", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//idCidade",
      "ValueParam=pIdCidade", LAST);	

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//idTipoEndereco",
      "ValueParam=pIdTipoEndereco", LAST);	
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//idUF",
      "ValueParam=pIdUF", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//nomeCidade",
      "ValueParam=pNomeCidade", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//numeroEndereco",
      "ValueParam=pNumeroEndereco", LAST);	
	
    web_reg_save_param("cCodigoErro","LB=<tns1:codigoErro>","RB=</tns1:codigoErro>","ORD=1",LAST);
	web_reg_save_param("cMensagemErro","LB=<tns1:mensagemErro>","RB=</tns1:mensagemErro>","ORD=1","NotFound=warning",LAST);
   

	lr_start_transaction(txName);
    web_custom_request(txName,
		"URL={endPoint}",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=",
		"Snapshot=t3.inf",
		"Mode=HTTP",
		"EncType=text/xml", "Body={XMLrequest}" , LAST);


   	if(strcmp( lr_eval_string("{cCodigoErro}"),"0" ) == 0)  //Sucesso
    {
		
		//lr_message("Codigo de Erro: %s",lr_eval_string("{cCodigoErro}"));
		lr_output_message("Grupo: %s Cota: %s Vers�o: %s retornou contrato em %f segundos",lr_eval_string("{pGrupo}"), lr_eval_string("{pCota}"), lr_eval_string("{pVersao}"), lr_get_transaction_duration(txName));
		lr_end_transaction(txName,LR_PASS);
		lr_think_time(12);		
        return 0;
    }
    else
	{	   
		lr_end_transaction(txName,LR_FAIL);
        lr_error_message("Codigo de Erro: %s%s%s%s%s%s%s%s%s", lr_eval_string("{cCodigoErro}")," || Mensagem de Erro: " ,lr_eval_string("{cMensagemErro}"), " || Grupo/Cota/Vers�o: ",lr_eval_string("{pGrupo}"), "/", lr_eval_string("{pCota}"), "/", lr_eval_string("{pVersao}")); 
		//lr_error_message("Codigo de Error: %s", lr_eval_string("{cCodigoErro}"));
		lr_think_time(12);
		return 1;
	}


    }

