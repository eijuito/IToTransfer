vuser_end()
{

	lr_start_transaction("ID500_DW_11_Logout");

	web_add_header("Origin", 
		"https://{host}");

	web_submit_data("frmMain.aspx_3", 
		"Action=https://{host}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/frmMain.aspx", 
		"Snapshot=t243.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$lkbSair", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAJVUW28aRxSGMcPNOJtIDUoTaZm0kXJxwi74JiHL0gZouirGEWDncTVmhmXU3R26MxDyEqm/oW997UOlvvcX8MPSmQVsx7iqOjzs0Tnfme+cjzPnS9p4tAVNz2vySMY8ED36y5TF9D0X8i0e/vwT/eR55Rz8digD236mUXRK+DM5+9gOJzEVGD7aDDk+jQiGTzcjyqZzTsW5mOKYcfhwCWGh7zmBpDHu02iM4cul2w2xT99OpeSRM6RC4D6T1CEhi5iQMSY8xvD7u6G8xQQONN1Q4q9opKqNhTSSHH53q0A/Jk0usVC5Ex6xGWXC8Al8vAnrcsmGDAvjeDdVAtmH6aLb8lbOPPiijkEMuP2mdrS/f2Tv7R8dGqQMRoZRzphgSEZm6bzX8X6kwcT7QC+"
//		"pigGgEMWRUQZm7oIJdhnQMUmcJZDW3gKLIhqPZRjA0oAGGLmRZgsI2EquzQzoXEKz5/zgtDuo3X/f7jndlnuGXrTrh/bBHlLnpZkbcB4M2OS/gISAnC5ZcasWCyBllLPmTpfOaNyeT3BEKCFmqU8DpS9VchAKnyQyeWuZvOsZkTWz0MFCuiptDgDJf7ObAnDLbtjaKGcrGZhbQU14gYMphWnbzK+J/K/heQV/bdfsGnp36jSR0zp1u25/0HNaZz0HtdqoedbtL37rNd2zPuoMWk6lANM1M78u1q8UfdVeQbWXB/nbTVaypJIjlfxmmZo3uxxtfaO9bt8ZSsaj7VfV/ichaVhVf2j13NWf9aOqDmJKtUY3E7ZUGZsE1jE7ueDDxV8oWvzBkboPRXzGBcJCTNXMChRhtCzi6bHFTlQlTz5bqmPnnTWKQ8Xo+MtwFYvJ3MwnD+"
//		"M8DuDzzxbTdiQsPT7eanysJdpzZkzw6iRaqbN9Q5e00gVUstp97273A20B//8oabrRiMchXvy5+JsKJPhlTBFGQ70gVOeJwpXS9m5mU6eiSv81rYRa/B5IFnKEkxePGqi+Z9kHVt2u15TZ2D9o2HV0dZZ7ATlyioPb0INDhb6GHl/GyDpJdhGi8wmL1SdsoJrKOUxyltLTyg588S+yJpsO8xu6rpu5UjentXoA0vfLKf0rqeZSBOwkWo7LGTWh9wkpp7S8dwGhsUQms3xlFlfpWXV9sjZO8bxDI1+OAUqYdfxeYhvX9j/rdqiBCAYAAA==", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=k0yBeGlWQcumga4u+C4GYVlM3yttQUnFhmftZeZLze0NV1gRRCbUT0wWQ307gWFH4/1oXfgAHEcM1J89p2N30krKDschLGQV79YOwL6viYUSByJyJJ4R9EmcN9Qlw4gOuqurOGYW5je7+ezVbmeHUWqCKjxg+ajin9xe+Pfd/8Y06wh7aYIjQQtPxC/LaVY/rWqvFy2lSwJn19CeyiHJnY4S9rA5A+dPdCnBtluZM9XcQN2u", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_DW_11_Logout",LR_AUTO);

	return 0;
}
