/****************************************************************************************/
/* Criado por: Celso Eiju Ito															*/
/* Criado em: 	23/05/2021																*/
/* 																						*/
/* Sistema: Dealer Web																	*/
/* Funcionalidade: ID500 Ofertar Lance               									*/
/* Pre-requisitos: Consorciado (Grupo/Cota/Vers�o) precisa nao ser elegivel a dar lance	*/
/****************************************************************************************/

int i = 0;

Action()
{
	lr_save_int(i++, "IT");
	lr_message(lr_eval_string("IT: {IT} USER {pUser} grupo {grupo}, cota {cota}, versao {versao}"));

	lr_start_transaction("ID500_DW_03_MenuAtendimento");

	web_add_cookie("trigger_state=menu_trigger_7; DOMAIN={host}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_auto_header("sec-ch-ua", 
//		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"");
//
//	web_add_auto_header("sec-ch-ua-mobile", 
//		"?0");

	web_url("frmMain.aspx", 
		"URL=https://{host}/NewconWeb/frmMain.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/frmMain.aspx", 
		"Snapshot=t222.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("frmMainMenu.aspx", 
		"URL=https://{host}/NewconWeb/frmMainMenu.aspx?ID_Modulo=AT&ID_SubGrupo=AT", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/frmMain.aspx", 
		"Snapshot=t223.inf", 
		"Mode=HTTP", 
		LAST);

//	web_revert_auto_header("Sec-Fetch-User");
//
//	web_revert_auto_header("Upgrade-Insecure-Requests");
//
//	web_revert_auto_header("sec-ch-ua");
//
//	web_revert_auto_header("sec-ch-ua-mobile");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_3", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t224.inf", 
//		"Mode=HTTP", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"event\":[{\"download_time_ms\":7034,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"https://storage.googleapis.com/update-delta/jamhcnnkihinmdlkakkaopbjbbcngflc/92.0.4515.9/92.0.4515.7/"
//		"392071c230d4fcbb4f4a80385dad246353767a831e041c46ed99c8001f37adf8.crxd\"},{\"download_time_ms\":4021,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"download_time_ms\":8021,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\""
//		"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"https://redirector.gvt1.com/edgedl/release2/chrome_component/OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component"
//		"/OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"download_time_ms\":4021,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"download_time_ms\":12025,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\""
//		":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"download_time_ms\":4020,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"92.0.4515.9\",\"previousversion\":\"92.0.4515.7\",\"total\":0,\"url\":\"https://www.google.com/dl/release2/chrome_component/"
//		"OPx43-8nRknPlE6XMG0kIg_92.0.4515.9/AMhzTtaxUOl_VXWh5Wc6wVg\"},{\"differrorcat\":1,\"differrorcode\":12,\"diffresult\":0,\"errorcat\":1,\"errorcode\":12,\"eventresult\":0,\"eventtype\":3,\"nextfp\":\"1.02ca16bb859305bbd070a77a30829f8053bf49ec48d1900b80611bb8f1e732b0\",\"nextversion\":\"92.0.4515.9\",\"previousfp\":\"1.4fa55e53e1a9dcf3a4bd7305a086b364cc80efb1b942a900c92f95660376b8e7\",\"previousversion\":\"92.0.4515.7\"}],\"version\":\"92.0.4515.7\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\""
//		"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1935\"},\"prodversion\":\"90.0.4430.212\",\"protocol\":\"3.1\",\"requestid\":\"{ac531ecc-40d2-4dc6-863e-596372f55945}\",\"sessionid\":\"{99b94a49-5391-4639-a3f2-5cad4b9dd840}\",\"updaterversion\":\"90.0.4430.212\"}}", 
//		LAST);
//
	lr_end_transaction("ID500_DW_03_MenuAtendimento",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_04_MenuPosicao");

//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_header("sec-ch-ua", 
//		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"");
//
//	web_add_header("sec-ch-ua-mobile", 
//		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmConAtSrcConsorciado.aspx",
		"URL=https://{host}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx?cd=15000", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/frmMainMenu.aspx?applicationKey=3OuowPITZL0CSJW2Gkc8lY2KFF/Hhymo4cvAN/81GQbSV0u3mfYxcpvHBosVMj6Re6KeWBwWYP43jJudVitmhA==", 
		"Snapshot=t225.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ID500_DW_04_MenuPosicao",LR_AUTO);

	lr_think_time(3);

//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_add_header("X-HTTP-Method-Override", 
//		"POST");
//
//	web_url("threatListUpdates_fetch", 
//		"URL=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
//		"Ch0KDGdvb2dsZWNocm9tZRINOTAuMC40NDMwLjIxMhopCAUQARobCg0IBRAGGAEiAzAwMTABEOKqCxoCGAgvNJ2mIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARD38ggaAhgInjXTZSIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQrOAIGgIYCDGdYhYiBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABEIauCRoCGAiwF5FMIgQgASACKAEaJwgBEAEaGQoNCAEQBhgBIgMwMDEwAxAUGgIYCLHnkC0iBCABIAIoAxooCAEQCBoaCg0IARAIGAEiAzAwMTAEEKggGgIYCGl-GxciBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAMaAhgIeaM2dCIEIAEgAigGGigIDxABGhoKDQgPEAYYASIDMDAxMAEQ7WgaAhgIkbBRnyIEIAEgAigBGicIChAIGh"
//		"kKDQgKEAgYASIDMDAxMAEQBxoCGAiVNYrTIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAfGgIYCGuJ5QQiBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABEJYMGgIYCIHAOukiBCABIAIoARopCA0QARobCg0IDRAGGAEiAzAwMTABEM6PARoCGAjHlNkpIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARDryAUaAhgIqXw9HyIEIAEgAigBGigIEBABGhoKDQgQEAYYASIDMDAxMAEQ7AoaAhgIptQFeyIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
//		"Resource=1", 
//		"RecContentType=application/x-protobuf", 
//		"Referer=", 
//		"Snapshot=t226.inf", 
//		LAST);

	lr_start_transaction("ID500_DW_05_LocalizarConsorciado");

	web_add_header("Origin", 
		"https://{host}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_auto_header("sec-ch-ua", 
//		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"");
//
//	web_add_auto_header("sec-ch-ua-mobile", 
//		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConAtSrcConsorciado.aspx_2", 
		"Action=https://{host}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx?applicationKey=Y0tUAG5AjJq8Q53qxz+kEjoaA/pBy1BDdh7DOKobo+w=", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONAT/frmConAtSrcConsorciado.aspx?applicationKey=Y0tUAG5AjJq8Q53qxz+kEjoaA/pBy1BDdh7DOKobo+w=", 
		"Snapshot=t227.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAL1Y3VLbRhS2DYYYSB3S4qRJaxQn/UkTbMhvw+BkwKaEKRgGOzR3nkVay9tKWnd3BU4vOn2M3vei0162j8Bj9GHSs6tfW/Ikk2ljz1ir863Od87ZPWeP/DpbvDqVL3e7DeoIRi1+hH90CcOHlIstpP/wLX7V7Zam80u6sFZXbxHb7G5aAjPUxk4f5W974l0bmXjLFYI6mzrmHLWJwJuGTRzCBUMGZSh/M30qbRKOLGDHukAjNAI7BrGxI2j+mieWNmLXoLdMZrSoIDpBvGga+S/H4H3suN3GQWuzsyanRrfFjTuZheyFXNYo5gsPnzxavf/oweOvi6VcedEQ4LqgzKG+5nv/XMxkM5nMa/jIq/ws5OCn1X7FBbarTSTQXe0YM06oU39QXZXfu1rDtYTLcN3BLrhu3dUO3ROL6BDIDv0BO/WTx4/RQ/3ho7Un9x/g1a+"
//		"f5KXyD2M61U8biymQX/HH1SNsg1mO6dMVXtpWW+9jG83DqEl6vR2G7Kls9gNfkT9P2luQimam4eevuY1nQ9vSTn2bK2vV1YqGHZ0aoLpecUVvZe1R5dnTi3MbQ77OFYFGjHqlhc98SyoaaHB4veIP1ocw7gsxWK/Vzs7Oqmf3q5SZtXurq2u1l/t7npHBXJsboAWImONr5ys20RnltCdWdGqvw7wVb1YFrNA0aQe2sNwGmoNsPGqKN3N9l/uSekUwF4fyFxw3XMbg2T2qIwv7sFLsqQbKgYWHnVcD7Et9eZ8SHWuwgQ903WXgIgTKRsPgznVOqOsY2KiEj6XZ2kEnFl6Lz5lMG6EcUhAWZRxKI9htdv3tWtEEaKtXYApxotAIxEwsWjCZD5CO5bKNOlV7C5bWfrdDhGvRGAnkNeyZ/5yn7Z68L6pk4P4PokYTYjeg74lNrdR7Y2s+7+"
//		"46uuVyFF8u0I87ULjfnWujNikLFJKePQry7YtyuRYmc5D1aRrGnvX4VX16OpOHwvlLdsOAGmuyde+C7HcpaP4znoo3PRMQrZyuyQBNyyI+VtxlSZ/p7qPvKYMLceRlyyWWUege4VMip8hD6wJ8cv4B9tr/zJdyvWKxNF3O6UbuV7e88OJor/scW4Pud/gEG6VcLlc0SnM9eTTOHoMqqGN9Qwnh9JTSAnEczPrCtvJXdg2IG+kRHTENDmFOGew9gxq5fFGqyspjd3EqI/nmuzdkrd6S1dOUd7vgUAPuRK5sZC+VMvK78NGdTEZaaJSewtOGN8zlpsDkmfJ8C50SEzbZC2blb/5cUyd7rcdAjbMpGg6PdQ5VxAfD8nQHD0X+KvQ05Pz389+oZtC4neXZDqUW5M3kKYbne9yO5dn8vTRymzJBfkI6onsEWilDjrrf7HTaypblC/"
//		"nLwRSPSELLhTQpkE4lSe8q0sahT9oYNJCxZVFIFkJVBwRbW3IGdFcDUDOwFk6oVqtAei0VUxYA+XSS/MtRj9vmIdMbiMnD13QZbSCuh8RLCtA8RBFIFFjTAcPfLqOEN1JC3OjL0nDIcMA060k46A6GoG0mqe1W2oKdIgu6VNSg0HoFMZNLD30cktbtIIZgexvUi1k6xhTl7Bsj5jnga4CmTjbLPKBdDFUHCPAlhUB0IUn0mSLabvlE2w4QHSOLsiY+pRa0fEnnFIy5hrQm9py7nop5zwNt4W39g6aLDyg0SI7s0WP+BcD5nwrx/BsTAtFckqgySoQ8IoEO5UtEuHKXpIir7LUIVAAMDAkZEMwnCb5I8aQJuc8hwZB8jSGhI5eUXNNDQLKMy4BlIcmSKFiQQR0G7WkTnxBBI4bzP+"
//		"S9hm2VmEgxjMmA4WKSYVkx7Bz5DDtMGbbD3EGovdSE1wlHminIqap1CgaOCQgwfZBkWkmLGNVdVXqbxCQCUusnYA+3XohyLcL9vErFwHLgLk5K5cZBUAbpEba2qAWvcJunrsWjKrRtE85VRZcl7gTy9fx3Gc10AMguJcm0FEdlnxWvGUvPoYpUZcQk4ilVy5YOANFikujzNCKwjPcwG82lj6XW878Z0ZXKYJIXy0/TwSi/Lr9dpd21B0ymV8haCCXAEt2Axg8nbcSYRlii7aHcWtE2lyqITZjmA3Kbj8tA+0dJ7V+lJNKu06PMRuwYAgxH4ObOdrjjA0iTmHfGAix3fDoCpEtvLEIqSC1sUghr7Mhd8EVKGVCM3IPiUlLx05RTvcGwV0BVVuwhaIYVwzPKiIntOor6HCAtHsAKe6eSmgq84yKgvjIpkLFMgkDuI8cF7eCTlxl6uM0XD+"
//		"TfGjzKGFXDE0KgujqpdxkN3yEyPQf5EQ5SPsypCNQiVOZUKgCkHydJH6RslGjNlMkstXE6xEyvej6xsDvyz8lULFzga5OO5+Nt34pjLF23kJMI8GUlHa9WKVLguZ7kuTO+kcDbI6zOdINuco5taOVJ1OmEmNQd4J6TV1IxIok/meRgjLhNbNeS//3JfRw72pZCQLnDzv+QqFzUVADYPp3EFlvUNrVIt4k5FD6VMwHbdQnoJMhsb4YshH4HPAlWbpaTxLfH11Gd37EKHT8TigFCWHAajIuAZRlU55an+qqB9EbQn/iDfAQWouGcNyrNwBPqbWwfDfewY4p+TlPdjcTn1LgYjf8FkKxnRu0VAAA=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtGrupo", "Value={grupo}", ENDITEM, 
		"Name=ctl00$Conteudo$edtCota", "Value={cota}", ENDITEM, 
		"Name=ctl00$Conteudo$edtVersao", "Value={versao}", ENDITEM, 
		"Name=ctl00$Conteudo$btnLocalizar", "Value=Localizar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=4wjQoWXoEh5UgG++oBou+Kp0uoLkp/n11UW/fMeBhHPS5fZPGOeOgiYec5IQc/PvaBX7EHeljJhpOanaH4vg/FmgiqSF0cPIdOscnu8lPjwagXz3VOrEjG7UPKfOJ6AgGctOd7j5Wbt1WQE8gxeaCnYbRxqGx2cTAmY6WnaNcZprXACIZ/zhAGJfcopoX189LVgWNKQbQPfTtY2nOAJ597duQU3NDDHNvwNhjgDe/de/EanZX6CW/aA8YqXSqRx6E4/vB+HyQaliIBNNhk9f9yBt6AA=", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_DW_05_LocalizarConsorciado",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_06_MenuOfertaLance");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pDtAssembleia",
		"RegExp=edtDT_Assembleia\" type=\"text\" value=\"(.*?) 00:00:00\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pLanceMinimo",
		"RegExp=ctl00_Conteudo_lblVL_Lance_Minimo(.*?)text-align: right;\">(.*?)</span>",
		"Group=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pPorcentMinimo",
		"RegExp=ctl00_Conteudo_lblVA_Lance_Minimo(.*?)text-align: center;\">(.*?)%</span>",
		"Group=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_url("Oferta de Lance", 
		"URL=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?origem=atendimento", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONAT/frmConAtCnsAtendimento.aspx", 
		"Snapshot=t228.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ID500_DW_06_MenuOfertaLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_07_SimularLance");

	web_add_auto_header("Origin", 
		"https://{host}");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConCpCadCredenciamentoLance.aspx", 
		"Action=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t229.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$rblFormasLance$1", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZzW8bxxUXV1qR+rApyxEtO/FqHduxHcvUkhIlMYnTUCStKNEHQ1JKitTdjHaH5NbLXWZ2ychB2/+gl+bWU4EUCJxLD0WPPenSQ+9FrmnRY48FihZI38zsBz9WilEgQItQELU77837vfdm3seMvoklF2dESVWLtuUS23Sq+OOuQXDFdtwtpD15Fz9V1dSkeFNzTUW5RblwV7dvHbtWhdhal6CC4+D2sYkNJL40xKS1nuwiS8O7Ro9gcYFTjXZTLZguJqiGrRYS7/HhnTZq4q2u69pWQcOOg2qGiwt627AMxyVItwnylRhmtUuGg0xAxZqLBmBcbOlGG1uuLS4P6dbVtrqOhsptZJi3mkRnD+UTzewaup1s6uLLQxOAp4RdZLawU7SPCdiFKNu9aLl1bOIGaESnFQ0d6dih3Ksj3G+DeTYxNPuggYmLmL/"
//		"oJDrOXti8lWiUou0ih0HQB6A6NtEMxA3Ifrtm/nO/3XeGpu1hq6sWD/YLdTojfEu+cX9sNpYQYrr46vMjUYTro54NNxEz99bzLBYwJsXpB5n13OZqZk1ZS6Z+LC3W9ulObhikjTRkqwCrlveAWYztS7d6TsVEln0EuwK9V1crRbXWPVaZl9Vdo2244LmGdI3KIFjHFriSbR613D7uuuAfKuVa7xMVOPgsIKh7to5MtsSUvHBUGJKo7hlWfMz7SDf7laCCQAUHYg5wsA9L5Vyq1dW9rukaHdPmAkXhcFe6sr+nwho4EAFtsLTdIXYPwVQszYOskgGbCAQgdZt0O0zdq1zdIYMebddrlDqzf0DdUEFNRIS0NHe0q9aQCTqXcA9DzMX//Hnn4daP/v6W9MKQZ9kSUBGJnuNqJeTiybGxw9//"
//		"7PpXCWnRZyRM8Rpu14x210SkJV0I3PPIOLFDt8yPLhwVPgdeAAf1uVioVCX5vIWkchvSpZFlCLEu9z7pX8BgZS9oVp/c7G9nxmLA/g18Yt7UCfrwdaz21HFxO120TRNSjgFhl97GFoYoTpcMNoDI04+yH37oMdZcYljNZbntaDYxjeNl+QgTB9gerqUV+rMsF2GpuwQ/tHAXsp25LFe6x6ahQfqt20+w9fB4YwPltNx6Jr+6hpXN/OPl71L44wmwM+7JSdBthggmibeR06oZn+ILMPMImV1cQQZxxsbHxhO/PM8p3t/yx11YRfepL++jzHfqoceJv52nVL8N/9dr9eHjcVitKQG+2AP9mqBv/4trQqMoTjVksUUfxv/6vViliX9DHvl+mMp24hP8VOxRc2KxSREGaD0bTMiTUDDGBFmO/"
//		"RM8Q70zmYCBCwEfTeSTUx7PP3yeGRhIDvCo2clZuqFmWM0sEugbiRHUzEpZmodiwsqVX2B0uyXdOL8ZgIa1Id0crj5QFhsI/MHKaYBQlajS/TVqd1dKVYjRM0zcNGwG2+atnRirSTPA7fdDWLoaMg71gk3pIq+KsFIdE/EitQCTQQtoi2mZhCa5S+slpSR7DpTvAnBrRmeg4Mkj5W5oKXjDEVUTkwP1Ws2GQucq5aFe4U+P3/1j/A9Hb0kXwJlRelwJTWUy3+sCOtO+Jl3Zs2mfT1RyPEBrSvO0g4GFwE3eu2zhthjbkxbDCVWsdz81SAURDZvgtsROiTdAwi9+MyHdpY0RbkOoAbsKLvL41ELHdmjr4/qbBdQAJ4JdUcrfCvwTNHaQNG2qV9eiHmWHHHDZrN8Q1eHoMdn5y5dfP5K+SqSERjKZmpAETW9Is4fVXfVtbHbU9/Ex1lOCICT11HQjmRKk+JHhGNAKt3Q2OC/"
//		"E6OiUYUGWaLltU7wy2MvJOpaZXpxfAH7+Df35pfExijmj3gB90JYNijbp2w7sqCK8uYKkx+ZSY/Rn9oX7Y2NUSz31JpfRYILGQe1JaBRRz2iCUYfEFG/+fIUdAVYaBMRYBbdoOX1nrTRyOifSRB2fuOIiHCSN0y9OPwc9bbnvhCLF67Zt1o3O2Sy6Z1GfHks5MRsF3raJa3xK98uuAedXnfWQtMlluiyti/M+CweipKWNqFEAHR8FXWagxYoHWuwUkb5l2tC2s/DmAQqYPtyiT6SrEzCk02kAvRZJYxoA+MQo+N1Bi2vNCtGKCBIE3XrELiJI3j7wAiPInMIAKBVQowkAKI4C3ohwcbFFDykVgn2kOB9xQLb/"
//		"CNImR6XdilowKA2Q7NgBNvAZXXpIrohqt43ghE2TEPdZNI0wyPi3eowb4Emo4ja9XnB82EuBaJ8CeKODAJQYBbrNgMr7HlDZAiAo4jaBnGibPUxGjWNk7MhILmFu3IuRND4fYKee1z4CUzu2xXNDv30+4fRLRuH2DQ0C0PQo0MuDQIgDuahCr12ClZtj1w8sek2DHmQBYWQMAGZGAe5EWFKC2HcgwBBN2EZgyBwbl7WAQFGGxwBldhRlJGFBBNWJraESPjZcO0Q4fUbfZdxmgYkYwtAYIFwYRVhiCNtVD2GbMMVYEfKlp4Ii5Bo9lusYGTDOoADSxVGkB1Ees7UuS70lowmlyYSMpoe5KKA6ckj34iqSBpoDdvKsUC4e+GnQrmJzyzaxaxd6XdMJs1C5bTgOy+g0xdHbstMvqDejCQA2NwomRxgK9cLuzxkLtGVKU49RChfKli2aAECXRoFeiQICzRx+mdIXS1ep1NPf0RaNivSZuC+"
//		"vRxPD+Jp/vky70+4QGl4B6lQwAijhC0i8fNZG7JMIS1Q+oVsr3OZUBPQwRPYIdJsPj4H0F0alvxoRSDtWw6Z3PUc2a9gK2+Vgx/skmdJ4jQUy3fHRFABd+NYkxJy0j5s2uLWv5M56Q0wYQAy8g+DUqOA3I6r6YHPFGiuG8ANozJu4/RCFfQ6AJnmnHvRggDs8BNBXznJkXySBI/eQ1XXp7Z3tXzAHOfyAnr2cMGJYDh8ZBKjFs3qXQffRCz8e9lXsh3wQUyFRDqk0piIJAHoVkISlTGsEei1iu4QrxxQnke1TBRMtzS0jQY/kVctIWrDM184q0kdlT4sjXPTu+YbdPM9Gh3NWxCjgvDiKc394O4G1Vcwqu26HN9yBkQGNyvbp3MgrkTSDAr90lrNvD8PzS1dok+ie7itzCwGBGUVOn1EqXeBIAmBeP8upfUtbs00DzlkOJEEWPz7ai5SgGX6Ucw6aFL1u+CwyM1YaBb43vJqslvdl6/"
//		"76kPQpBvErw/AQoCz5LuW9/zI7/swzxAkQckPJKBl5e69QlAulvZ39nVq9WigdVAtyqSwXD7gdy+cz7ddOP6sWdw5q8m69VGBtN8VcF5cU+glnMt6DAdYZj3VN2VAyuQ1ZlhVlffWBosDT++Xd3Z39+sG+XIIJtQI81uRCtXD4zoHMPqxdYfMxq+nB42VP6jTAb+aza+ubayxVcZtnaodbtfpO/ZBb1//KNj+fezGfy6bzq+vp/Gb2wVo+cCWVuraibK5k8vksa2H56Liymg+1ECfB8Fw2z6oyh714sL/zgZxJK/ID+Z2DHwLy0Eif4lO59fRmXllWlD6NQKSyurnK9iwfkeofyOCWdLZwWD/YS+8XwLX7hZ2avLm2kmNzlwLtlAy83vBeEx7rLozd9MYE5qR7vpHg38xyJq/kbsPofV+F9Y2N5ewmjKyEfLnV5dxGlvFlfP1XlfQasK5RHXLeYPLB4AdI+"
//		"bNJD88mFc4mFYN4ogxx6kFFoZqV6SUEP/7C95wOa9IQYgK8pCbmdL0Jvy3/NxVreGdHiBYYYO9xTwCdKsDUlDAnTtN8DUWji0wxdrs5J4rslCPGjpqejGQqISWKjlM0keOICy4+ceVOMEk1aRWVpvbQyS62mm5LSIDWMUWaUG/UtgTBPwEyWK7GjKeW5wHW6bOM1kI9dmS8wOK9yXXnXA+quINdyAlItr0CbssMWu5APlyVUZCE7zr3dJ3tapY1UhMAzZ9Cr8YUFuMhg7c3XrGOnc7rjDZHr2bo0Vl7gvWWFC9bCMTrLSZ7wAQarjuerGl+HxS3LQ3y5hNxhf6nvvATdHL3ToG6C4oyz+JQTn+q3Ln3uiwT7HaJJTeQ6eDXda7sw/MnZqImis8xcTVqYvw5JmajJrKjL0wP0vOe58dHp78yXaPtrxBfMZ0e0l6Ts6srSm4lq2Qz8umvHXh9Tdl4LZdflhG0S73TZ3AoRXfte/L7+Ni/"
//		"bwHT6G2ZMHAX5l1mBJs8iiN+zuxEuITSZQiCtuFifnNL2G100yttEwyB7hFfCoRcKgYvYmyM79OYMOkJjYbiHnqj6d8WMNSExE/HaniUZv/l3CmptO6pjCjGM9nNTWVjXUrCOD/Wc4rwr88eSalBvf1ba1B98izVxf9a9Zi32jSMx/zbzJnIWdPhyjTOWR4x3DlT4eO0F0qTHnhekIMqy5+T4fN/ALCbLw0hIwAA", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
		"Name=ctl00$Conteudo$rgLance", "Value=LL", ENDITEM, 
		"Name=ctl00$Conteudo$rblFormasLance", "Value=Parcela", ENDITEM, 
		"Name=ctl00$Conteudo$rblTipoOferta", "Value=%", ENDITEM, 
		"Name=ctl00$Conteudo$edtOferta", "Value=0,0000", ENDITEM, 
		"Name=ctl00$Conteudo$chkLanceLivre", "Value=on", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=100", ENDITEM, 
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConCpCadCredenciamentoLance.aspx_2", 
		"Action=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t230.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$rblTipoOferta", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZzW8bxxUXV1qRkixTliNaduLVOrZjK5aoJSVKYhKnoUhaUaIPRqSUFKm7Ge0Oya2Xu8zskpGDtv9BL82tpwIpEDiXHooee9Klh96LXNOixx4LFC2QvpnZD36sFKNAgBahIGp33pv3e+/NvI8ZfRNLzk+JL2uuqSh3irbl4o5u32kQvYRdZDaxU7RPCLI0lGzo4tIAW0fb6jgaKreQYdI57KF8qpkdQ7fpBElVKTOxTecQf9wxCK7YjruFtCfv4qeqmhoXbw+IPHGtCrG1DkEFx8GtExMbSHxpgElrPtkFnfCu0SVYnONUo9VQC6aLCapiq4nERT6800INvNVxXdsqaNhxUNVwcUFvGZbhuATpNkG+EoOsdslwkAmoWHNRH4yLLd1oYcu1xTvP4xPqi8Voxho2cR0gKG/R0JGOHcq9OsT9NuhrE0OzD+qYuIg5gE6i4+"
//		"yFzVuJRinaLnIYBH0AqmMTzUB8lbLfrpn/3Lu49wam7WGroxYP9gs1OiN8S77xYORSLCHEdPHV50eiCDeHt2W4K6i5SXFyObOe21zNrClrydSPpesVYnQNEzcMe8BfDWm+uk93Y90gLaQhWwUktbwHqyPG9qU7XadiIss+hpVF79XUSlGtdk5U5lh112gZLjirLt2gMgjWsQXeYxtALbdOOi64hEq50f1EBQ4+Cwjqnq0jk60qJc8dFwYkqnuGFR/xPtLtXiWoIFDBgbgBHOzDUjlXqjV1r2O6Rtu0uUBRONqVru3vqeB2B3ZxCyxttYndRTAVS7Mgq2SAH0AAUrdJp83Uvc7VHTDo0XatSqlT+wfUDRXUQERISzPHu2oVmaBzCXcxxE38z5+3H2796O9vSS8MeJbteSoi0XVcrYRcPD4ycvT7n938KiHN+"
//		"4yEKV7FrarR6piINKXpwD2PjFM7dMvs8MJR4TPgBXBQj4uFSkGSL1pIKrcuXRlahhBrWrN65md/OzUSg+Fv4BPzWMbow9ex6lPHxa100TZNSA8GRFR6G1sYNly6ZLABRJ5+lP3wQ4+x6hLDaizJLUeziWmcLMnHmDjA9nAtrdCfJbkIS9oh+KGFO5CZzCW50jkxDQ1SZc1+gq2HJxsbKKfl1jP51TWsbOYfL32Xwh+PgZ1xT06CbidEMEm8jZxm1fgUT8PMY2R2cAUZxBkZHRlN/PIip3h/yx93YLXcp768jzLfqYceJ/52kVK9Nvxfr9WHj0dhtSYE+GIP9GuMvv0vrgmNojjVkMUWfRj96/dilcb+DXnk+2Eq24lP8FOxS82JxcZFGKB1qz/xjkNhGBFkOfZP8Az1zngCBqYDPpqwxyc8nn/4PFMwkOzjUbPjl+iGmmK1sUigxyNGUBsrZWkWigYrS34h0e2mdOviog/"
//		"NZV26PVhloPzVEfiDlc0A4VBK7JR4ZRV+8ZsxiZrQW5l2d6UpGPK7Gyylwk6FqdTiHZ0Yq0qXeb2DtWmbiDcWczAXcKFppQUQWtgOrYSUkuw6UJgLwK0Z7b5SJvd2IqxFGXA+byUGmZjQvkqsZkOhM5XyQBfwp8fv/jH+h+O3pGlwX5Qe10JLmcz3OoDOtK9K1/Zs2oUTlZz00RrSLO1NwPW4wbuSLdwSY3vSfDjhEOudTw1SQUTDJvR3V7ufRBpznzY/uAVhBhNVcJY3Qy20bYe2N66/UUAhcCdYGGXGnUB40LxBwrSphh2L+pYdRgDvkt/01OCIMN7+y5dfP5K+SqSEejKZGpMETa9Ll44Od9W3sdlW38cnWE8JgpDUU5P1ZEqQ4seGY0CH29TZ4KwQo6MThgUZoum2TPFaf78m61hmenF+"
//		"Afj5N7TdV0ZHKOaUegv0QVs2KNqgbzuwt4rw5gqSHptJjdCfSy88GBmhWuqpN7mMOhM0CmqPQzOIukYDjDoipnj75yuss1+pExBjFdyi5fScidLIaZ9KYzV86orzcOAzzr44+xz0tOWeg4cUr9m2WTPa57PonkU9eizkxGwUeMsmrvEp3Tm7BpwzddYn0kaW6bKwLs76LByIkhY2okYBdHQYdImBFiseaLFdRPqWaUNrzsKXhypg+nDzPpGuTsCQTqcB9EYkjWkA4GPD4Pf7La42KkQrIjjT0K1H7CKCxO0DzzGCzCkMgFIBNZoAgOIw4K0IFxeb9CBSIdhHivMRB2T7jyBtfFjanagFg7IA5zN2Lg18RpceEiui2m0jAkcXiGDus2gaYZDxb/UYN8CTcIhb9BrA8WGvBKJ9CuANDwJQYhjoLgMq73tAZQuAoIDbBLKjbXYxGTaOkbEjI7mEuXEvRtL4fICdeF77CExt2xbPDb32+"
//		"YSzLxmF2zcwCECTw0Av9wMhDuSiCr0eCVZuht0qsOg1DXpYBYShMQCYGga4F2FJCWLfgQBDNGEbgSEzbFzWAgJFGRwDlEvDKEMJCyKoRmwNlfCJ4dohwtkz+i7jFgtMxBAGxgBhehhhgSFsH3oI24QpxvoBX3oqKEKu0WW5jpEB4xwKIF0eRlqO8pitdVjqLRkNKE0mZDQ9zEUB1ZFDuhdXkTTQHLCT54Vy8cBPg/YhNrdsE7t2odsxnTALlVuG47CMTlMcvUE8+4J6M5oAYDPDYHKEoVAv7N6cMUdvedLUY5TChbJliyYA0JVhoFeigEAzh1+Y9MTSdSr17Hf0VomK9Jm4L29GE8P4mn2+TLvTahMaXgHqRDACKOELSLx63kbskQhLVD6lWyvc5lQE9DBE9gh0mw+OgfQXhqW/GhFIO1bdpvc5xzZr3Qrb5WDH+"
//		"ySZ0niNBTLd8dEUAJ371iTEnLSPGza4tafkXvKGmDCA6HsHwalhwW9GVPX+5oo1VgzhBzYxGrj1EIV9DoAm+eVi0IMB7uAQQF87z5E9kQSO3ENWx6U3dLZ/6R7k8AN67nLCiGE5fGgQoObP61363Ucv9XjYH2I/5IOYColySKUxFUkA0OuAJCxkmkPQaxHbJVw5pjiJbJ8qmGhpbhkJeiSvWkbSgmW+cV6RPi57WhzjonfHN+jmWTY6mLMiRgHnxWGcB4PbCaw9xKyy63Z4cR0YGdCobJ/OjbwWSTMo8EvnOfvuIDy/WIU2ie7pnjI3FxCYUeTsGaXSBY4kAObN85zas7RV2zTgnOVAEmTx46O9SAma4Uc556BJ0euGzyMzY6Vh4MXB1WS1vCdb99aHpE8xiF8ZBocAZcF3Ke/9l9jxZ5YhjoGQW0pGycjbe4WiXCjt7ezvVGuHhdLBYUEuleXiAbdj6WKm/"
//		"erZZ4fFnYOqvFsrFVjbTTHXxQWFfsKZjPegj3XKY00rG0omtyHLsqKsry4rCjy9X97d3dmvHezLJZhQLcBjVS4cFo7eOWCNCpuJWTUPHq968iYBeDOfXVvfXGNJils7VT3aqtZ2akfcrt5Xtu353Mv5XDadX11P5zezy2v5wIlU6tqKsrmSyeezrHnlo6PKaj7UQhwHk3PZPKvHHPbywf7OB3ImrcjL8jsHPwTkgZEexSdy6+nNvLKkKD0agUhldXOV7VY+ItU+kMEh6WzhqHawl94vgFP3CztVeXNtJcfmLgTaKRl4veW9JjzWXRi77Y0JzEmLvpHg+sxSJq/k7sLoA1+F9Y2NpewmjKyEfLnVpdxGlvFlfP1XlfQasK5RHXLeYHK5/wOk/Pmkh+eTCueTikEkUYY49aCiUM3K9PqBH3zhe0aHNakLMQFeUmMzut6A36b/m4rVvVMjxAkMpGJCjJ/"
//		"CJr25AsxNCTPiJE3VUC86yBRjdxszosgOOGLsuOEJSaYSUqLoOEUTOY445+JTV24Hk1STFlBpYg+d7mKr4TaFBKgdU6Qx9VZ1SxD8wx+D1ZnIKU8vzwWsyWfJrIm67LQ4zUK9wZXnXMuHuI1dSAdItr3abcsMWm5DKlyVUZB/7zuLus62NUsYqTGA5k+hW2MKC++Qwdscr1gnTvt1RpuhtzL01Kw9wXpTipctBOL1JpPdZwKN1x1P1iS/CorblgYp84m4Qv+ZXvgJOr1/r0DdBfWYJ3CopD9V7i2+LssEux1iyXVkOvh1nSv78OKJmaiJ4nNMXI2aGH+OidmoiezUC9ODzLzn+fHR2a9M12j5K8RXTKfns9fk7OqKklvJKtmMfPZrB15fUzZey+WXZASdUvfsGZxH0X17UX4fn/hXLWAavSgT+"
//		"q7BvHuMYJdHccQvmJ0Il1C6CkHQMlzMr28Ju4RueFVtjCHQPeJLgZhLxeBFjI3wfRoTxj2h0VDcQ280/IsChpqQ+MFYDU/R9GZyeqek0pKnMqIYz2Q3N5WNdSkJ4/xEzynCvz57JKX69fZvrkH18fNUF/9r1WPeatMwHvEvMqciZ02GK1O/YHnEcOdMhI+TXiiNe+B5QQ4KLH9Ohs//AUqGWb8cIwAA", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
		"Name=ctl00$Conteudo$rgLance", "Value=LL", ENDITEM, 
		"Name=ctl00$Conteudo$rblFormasLance", "Value=Parcela", ENDITEM, 
		"Name=ctl00$Conteudo$rblTipoOferta", "Value=%", ENDITEM, 
//		"Name=ctl00$Conteudo$rblTipoOferta", "Value=V", ENDITEM, 
		"Name=ctl00$Conteudo$edtOferta", "Value=0,0000", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=100", ENDITEM, 
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConCpCadCredenciamentoLance.aspx_3", 
		"Action=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t231.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZzW8bxxUnV1qRkmxTliNaduLVOrZjK5apJSVKYhKnoUhaUaIPRqSUFKm7Ge0Oya2Xu8zskpGDtv9BL82tpwIpEDiXHooee9Klh96LXNOixx4LFC2QvpnZD36sFKNAgBahIGp33pv3e/PevI8ZfRNPzU+LL2uuqSi3S7bl4q5u324SvYxdZLawU7KPCbI0lGrq4tIQW1fb7DoaqrSRYdI57KFyopldQ7fpBElVKTOxTecAf9w1CK7ajruJtCfv4qeqmp4Qbw2JPHatKrG1LkFFx8HtYxMbSHxpiElrPdkBnfCO0SNYnONUo91Ui6aLCaphq4XERT683UZNvNl1XdsqathxUM1wcVFvG5bhuATpNkG+EsOsdtlwkAmoWHPRAIyLLd1oY8u1xdvPYxNqi8Voxjo2cQMgKG/J0JGOHcq9MsL9NuhrE0Oz9xuYuIgZgE6i4+"
//		"yFzVuORinZLnIYBH0AqmMTzUDcS7lv18x/7nfu3aFpu9jqqqX9vWKdzgjfUm/cj12IJ4W4Lr76/EgU4cbotgx3BV1uSpx6kF3Lb6xkV5XVVPrH0rUqMXqGiZuGPWSvpjRf26O7sWGQNtKQrQKSWtkF74jxPel2z6mayLKPwLPovbpaLam17rHKDKvuGG3DBWM1pOtUBsE6tsB6bAOolfZx1wWTUCnXe5+owMFnAUHdtXVkMq9S8txRcUiiumtYiZj3kW71K0EFgQoOxA3gYB+Wyrlcq6u7XdM1OqbNBYrC4Y50dW9XBbM7sIvbsNJ2h9g9BFOxNAuyygbYAQQgdYt0O0zda1zdoQU92qrXKHV6b5+aoYqaiAgZaeZoR60hE3Qu4x6GuEn8+fPOw80f/f0t6YUhy7I9T0Uke46rlZGLJ2Kxw9//"
//		"7MZXSWneZyRM8Rpu14x210SkJV0MzPPIOLFDs8yOOo4KnwErgIH6TCxUi5J8niOp3IZ0ecQNIdaV3if9Dgw8e1Gz+uTmfjsdiwP7N/CJe1PH6cPX8dpTx8XtTMk2TUgbBkRaZgtbGDZipmywAUSefpT78EOPseYSw2ouyW1Hs4lpHC/JR5g4wPZwNaPQnyW5BK7uEvzQwl3IWOaSXO0em4YGKbRuP8HWw+P1dZTX8mvZwsoqVjYKj5e+S+GPx2GdCU9Okm4zRDBJvo2cVs34FF+EmUfI7OIqMogTG4uNJX95nlG8v5WPu+BF96kv76Psd2qhx8m/nadU/xr+r3314eMx8NakAF/sgX6N07f/RZ/QKEpQDVls0Yexv34vvDT+b8gj34+lsp34BD8Ve3Q58fiECAO0ng0m5AkoGDFBluP/BMtQ60wkYeBiwEcT+cSkx/"
//		"MPn2caBlIDPGpu4gLdUNOsZpYI9H7ECGpmtSLNQjFh5covMLrdkm6e3wxA09mQbg1XHyiLDQT2YOU0QDiQqNL9NWpnR5qGIb/PwVI67FmYEm3e24nxmnSJVz7wRsdEvBDNwVxAgvaVlkJoZru0JlJKqudAiS4Ct2Z0BoqaPFLShszNm4qoupcaqMlqLhQ6U60M9QN/evzuHxN/OHpLuggGi9LjarhSJvO9LqAz7WvS1V2b9uNEJccDtKY0S7sUMDZu8v5kE7fF+K40H044wHr3U4NUEdGwCZ1ecrvMmxzhF78Zl+7R5ge3IZyAXQUTeXxqsWM7tL1x/Q0BaoARYV1Ryt8O7BM0b5AYbapX16IWZYcRMNkFv+mpwxFhovOXL79+JH2VTAuNVCo9Lgma3pAuHB7sqG9js6O+j4+xnhYEIaWnpxqptCAljgzHgA63pbPBWSFORycNCzJBy22b4tXBfk3Wscz04vwC8PNvaLsvj8Uo5rR6E/"
//		"RBmzYo2qRv27CjSvDmCpIen0nH6M+FF+7HYlRLPf0ml9FggsZA7QloBlHPaMKiDokp3vr5MuvslxsExFhFt2Q5fWeiDHI6J9J4HZ+44jwc+IzTL04/Bz1tue/gISXqtm3Wjc7ZLLq3oj49FvJiLgq8bRPX+JTulx0Dzpk66xNpI8t0WVgTZ30WDkRJC+tRowA6Ngq6xEBLVQ+01CkhfdO0oTVnQcsDFDB9uHmfSL0TMGQyGQC9HkljGgD4+Cj4vcEV15pVopUQnGno1iN2CUGC9oHnGEHmFAZAqYAaTQBAcRTwZoSJSy16EKkS7CMl+IgDsv1HkDYxKu12lMMg/cP5jJ1LA5tR10MCRVS7LUTg6AJJiNssmkYYZOJbLcYX4Ek4wG16DeD4sJcD0T4F8EYHASg5CnSHAVX2PKCKBUBQqG0COdE2e5iMLo6RsSMjuYz54l6MpPH5ADv5vOsjMLVjWzw39K/PJ5x+"
//		"ySh8fUODADQ1CvTyIBDiQC6q0uuRwHMz7FaBRa9p0MMqIIyMAcD0KMDdiJWUIfYdCDBEE7YRLGSGjctaQKAow2OAcmEUZSRhQQTVia2hMj42XDtEOH1G32XcZoGJGMLQGCBcHEVYYAhbBx7CFmGKsSLkS08HRcg1eizXMTJgnEEBpEujSA+iLGZrXZZ6y0YTSpMJGU0Pc1FAdeSQ7sVVJA00B+zUWaFc2vfToH2AzU3bxK5d7HVNJ8xClbbhOCyj0xRHbxBPv6DWjCYA2MwomByxUKgXdn/OmKO3PBlqMUrhQpnbogkAdHkU6JUoINDM4RcmfbF0jUo9/R29VaIifSZuyxvRxDC+Zp8v0263O4SGV4A6GYwASvgCEq+ctRH7JIKLKid0a4XbnIqAHobIHoFu8+ExkP7CqPRXIwJp22rY9D7nyGYNW3GrEux4nyRTGq+xQKY7PpoCoHPfmoSYkfZw0waz9pXcC94QEwYQA+8gOD0q+"
//		"M2Iqj7YXLHGiiH8wCZGE7cforDPAdAUv1wMejDAHR4C6KtnGbIvksCQu8jquvSGzvYv3YMcvk/PV04YMSyHjwwC1PxZvcug+eilHg/7A+yHfBBTIVEOqTSmIgkAeg2QhIVsawR6NWK7hJ5jipPI9qmKiZbhKyNBj+RVy0ha4ObrZxXpo4qnxREueXd5w2aeZaPDOStiFHBeHMW5P7ydYLUHmFV23Q4vroNFBjQq26fzRV6NpBkU+KWzjH1nGJ5frEKbRPd0X5mbCwhsUeT0GaVSB0cSAPPGWUbtc23NNg04ZzmQBFn8+GgvUoJm+FHOOWhS9Lrhs8hssdIo8OKwN1kt78vW/fUh5VMM4leG4SFAWfBNynv/JXb8mWWI4yDkppJVsvLWbrEkF8u723vbtfpBsbx/UJTLFbm0z9exdD7TXu30s4PS9n5N3qmXi6ztpphr4oJCP+FMxrs/wDrtsWaUdSWbX5dlWVHWVh4oCjy9X9nZ2d6r7+/"
//		"JZZhQK8JjTS4eFA/f2WeNCpuJWTUPHq948qYAeKOQW13bWGVJiq92una4Watv1w/5uvpf2bbncy8V8rlMYWUtU9jIPVgtBEakUleXlY3lbKGQY80rHx1TVgqhFuIELDmfK7B6zGEv7e9tfyBnM4r8QH5n/4eAPDTSp/hkfi2zUVCWFKVPIxCprGyssN3KR6T6BzIYJJMrHtb3dzN7RTDqXnG7Jm+sLufZ3IVAOyULrze916THugNjt7wxgRlp0V8kmD67lC0o+Tswet9XYW19fSm3ASPLIV9+ZSm/nmN8WV//FSWzCqyrVIe8N5h6MPgBUuFs0sOzScWzSaUgkihDglpQUahmFXr9wA++8D2jg08aQlyAl/T4jK434bfl/6bjDe/UCHECA+m4EOensClvrgBz08KMOEVTNdSLLjLF+J3mjCiyA44YP2rySTQIklKy5DglEzmOOO/iE1dmnYGrdQmN56esiEqTu+"
//		"hkB1tNtyVcAtXjijSu3qxtCoJ/AGTQOtNt2tPNMwNr9FlCa6EeOzFeZOHe5AvgXA8OcAe7kBKQbHv125ZNCi13IB2uyCjIwfecRV1nW5sljfQ4QPOn0LRxhYV4yOBtkFesY6fzOqPN0JsZenLWnmC9JSUqFgLxeovJHlgCjdltT9YUvw5K2JYGafOJuEz/oV78CTq5d7dI7Qw1mSdxqKY/Ve4uvi7LBLtdYskNZDr4dZ0r+/D8idmoieJzTFyJmph4jom5qIns5AvTg+y869nx0emvTNdo+x7iHtPpGe01ObeyrOSXc0ouK5/+2oHX15T11/KFJRlBt9Q7fQZnUnTPXpTfx8f+dQssjV6WCQNXYd5dRrDTozgS58xOhi6UrkAgtA0X84tbwi6cm15lG2cIdI/4UiDu0nF4EeMxvk/jwoQnNBqKW+iNpn9ZwFCTEj8cq+FJmv0jc7us0rKnMqKYyOY2NpT1NSkF4/"
//		"xUzynCvz57JKUH9fbvrEH1ibNUF/9r1eOet2kYx/zLzOnIWVOhZxrnuEcMd85k+DjlhdKEB14Q5KDI8udU+Pwfs5qazSAjAAA=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
		"Name=ctl00$Conteudo$rgLance", "Value=LL", ENDITEM, 
		"Name=ctl00$Conteudo$rblFormasLance", "Value=Parcela", ENDITEM, 
		"Name=ctl00$Conteudo$rblTipoOferta", "Value=%", ENDITEM, 
//		"Name=ctl00$Conteudo$rblTipoOferta", "Value=V", ENDITEM, 
		"Name=ctl00$Conteudo$edtOferta", "Value={pPorcentMinimo}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtOferta", "Value=677,28", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$btnSimula", "Value=Simular...", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=100", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_DW_07_SimularLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_08_ConfirmarLance");

//	web_revert_auto_header("Sec-Fetch-User");

	web_submit_data("frmConCpCadCredenciamentoLance.aspx_4", 
		"Action=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t232.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVaTWwbyZUWabVISbYpyyNantlptceejD2mqOafSHrGk1Ak7VGiH45IabKYNToldpHqcZPNqW5q7MHuYu+LvSSnzWmBBBhMLllgkeOedNlD7kGuSZBjjgGCXSB5r6p/+NPUOAsE2EUoiKqu9+p9772qeu9Vtf4YSawvS2+1HVNV71WtvkOHunWvy/QadYh5Ru2qdcpIv00SXV1KTbAN2ztDu03qPWKYOIY36i/a5tDQLRwgaxoyM8u0j+hnQ4PRhmU7O6T9/Dv0paYlJenuhMhTp99gVnvISMW2ae/UpAaR1gST0etqFdOhjDRp/4xID0T3bo906c7Qcax+pU1tmzQNh1b0ntE3bIcR3WLEg5lktWqGTUwAp21nHMahfd3o0b5jSfdexWq09kE4Y4uatAMQyFs1dKJTG7lzU9wfgr4WM9rWYYcyh+yB2/"
//		"kg7OcPfNxWOErVcojNIbABVNtibYOIech+vWZee3T63pkYtk/7Q616eFBp4YjgKfH+w7mrkXg0okvvvjoSIrw5vfCCeUdzE9LSZma7UMpl8mo+kTyVbzeYcW6YtGtYE/7qyuvNA1xvHYP1SJtYGiBp9X2YHSlyIN87txsm6VsnMLPko5bWqGrN4anGHavtGT3DAWd15NdRBqM67YP3+ALQ6r3ToQMuQSmvn3+uAYcYBQRt39KJyWcVyWsnlQmJ2r7Rj825H/nuqBIoCFSwYWcADvVgUc6NZkvbH5qOMTAtIVCKHu/Jtw72NXC7Dau4B5b2Bsw6JzCUyqsgq2aAH0AA0Z6y4YCre1uoO2HQk6etJlKXDw7RDQ3SJSyalldO9rQmMUHnGj2nsG9iv/jR4PHO3/3uW/JrE57lax5FxM9tp10jDl2Ymzv+2T+8+cu4vO4xMq54k/aaRm9oEnYmX/Pd88R4YQVuWZ2eOBS+"
//		"Al4AB424ONqoyMplE4lyO/KNqWkIsG7v1rRd8IZjdIw2RgfNC3HRH/7zunyt3R8Rn/3p8lwERv0RPhFXwjw2fhVpvrQd2ktXLdOE6GHAhks/pX0K6zFdM3gHYS+/l/3kE5ex6TCj300pPbttMdM4TSknlNnA9jifVvEnpVRhxoeMPu7TIQQuM6U0hqem0YZY2bKe0/7j02KRFNqF7Uw5l6dqqfws9ZcU/mwe7Iy5cuK42gijLP4hsc+axhf0Gow8IeaQNojB7Lkrc1fi37/MKe7f+mdDmEznpSfve5m/qIeexX97mVKjNvy/nqtPnl2B2VqMwhdv4Nc8Pv1fnBPcRTHUkO8tbFz5zV/FLM3/D8SRvw5T+Up8Tl9K52hOJLIgQQemtfG4vAB5Yy6qKJE/"
//		"gGfQOwtx6Ljm82E8X1h0eX7v8SxDR2KMR8suXMUFtcxTZ5VBCcgMP3U26vIq5BSetbw8o1tn8p3La4JzRjvy3ckkBNmxQ8AfPKv6CEdyHBILT7zRf/nxvIwmjCauvT05OZV5+ODov0LaWQZ2rzCicjIocri6PVEMSpGmfF2kSpi3gUlETbIGY0EnqHcxd0L1O8QkipTEuQ05vQLcbWMwlgWV0SKGVzcTEyOqkEkmLnQsiWvZQOhKoz5RQPz82Xf+K/afJ9+Sr4Frw/S4FVjKZX40BHSufVO+tW9hAc80djpG68qrWNbAtNCuKGh2aE+K7MvrwYAjqg+/MFiDsDY1oTS8ef55qDH3sW6iPdiCMFADZ7kjtMrAsrEycrxFBAqBO8HCMDPu+cL9ug+CqYUaDvvoW1xLiHfVq5dacLpYGPz6J796Iv8ynox2EonkvBxt6x356vHRnvYhNQfax/SU6sloNJrQk0udRDIqx04M24Di+"
//		"EznnavRCPYuGn2IHmdOz5RujZd6ik4VrpfgjwK/+IaK/caVOcRc1u6APmTHAkW7+LQLa6sKT05U1iMryTn8ufraw7k51FJPfiBkdLigK6D2AtSR5NzoglHHzJTu/uMWPxRsdRiI6Vecat8eOU6liT14Ic+36AtHWofToHHx5cWPQE9LGTmzyLGWZZktYzCbRXctGtFjoyhlw8B7FnOML3Dl7BlwCNV5iYk1MNdloySteiwCCEkb5bBeAL0yDZrioNWGC1odVIm+Y1pQ1fPtK7YqYHpw6x4RZ8dnSKfTAPp6KI1rAODz0+D3xy1udhusXSVwHMKlx6wqgaDuAa9xgiIoHACpgBpOAEBpGvBOiIurZ3iGaTDqIcVEjw2yvSZIW5iWdi9swiBlwNGOH2l9n+HUQ9AlqN1TAvU67mDhs3Aa45Cxr/"
//		"WYMMCVcER7eINge7A3fNEeBfCmOwEoPg30NgeqH7hA9T4AQXK3GERHyzynbNo4Tqa2QpQaFca9EUoT4wF28VXtYzB0YPVFbBi1zyNc/IRThH0TnQC0NA301jgQEUAOaeDNij9zK/xCgu9e08BzLiBM9QHA8jTAOyGW1GDv27DBCAZswzdkhfcrbZ+AKJN9gHJ1GmUqYMEOajGrTWr01HCsAOHiK3xWaI9vTMIRJvoA4do0wgZHeHrkIjxlXDFeK3jSk34ScoxzHus4GTBmUADp+jTSZpjHrPaQh96a0YXUZEJE04NY5FNtJaC7+yqUBpoDdmLWVq4eemHQOqLmjmVSx6qcD007iEL1nmHbPKJjiMOz98WX6M1wAoCtTIMpIYZCvrBGY8YaXhCl0WNIEUL5tIUTAOjGNNA3woBAM1vctYzspdso9eI/8EIKRXpMwpdvhhOD/bX6apF2tzdguL181EW/B1CCB5B4c9ZCHJEIU1R/"
//		"gUsrWOYoAmoYprgEXOaTfSD9tWnp74ZspN1+x8KroBOLl26Vp3V/xXskBWkixwIZV3w4BUDXvjYIcScd0K4Fbh1JuVfdLi4MIMaeQXByWvAHIVl9vLjihRVH+KbFjC7tPSZBnQOgCXEv6ddggDvZBdC3ZjlyZCeBI/dJf+jg5Z7lXVf5MfwQz2R2sGN4DJ/qBKj1WbXLuPvwPlBs+yPqbXl/TwVEJaDingolAOhtQIpu5M6moPMhyyWYOa44Cy2fGpS108Iy5tdIbrYMpfnT/PqsJH1Sd7U4oVX3/m/Szau8dzJmhfQCzhvTOA8nlxNYe0R5Ztet4M7bN9KnoWyPLoy8FUozEPhvZjn77Ul4cScLZRKu6ZE0t+YTuFHs4iuk4gSHEgDzzVlOHZnapmUacM6yIQjy/eOhvYGEtuHtcsGBQdGthmeRubHyNPCDydnkuXwkWo/mh4RHMZiXGSa7AGXDc6mo/VP8+LPKEedByB01o2aUp/"
//		"uVqlKp7e8e7DZbR5Xa4VFFqdWV6qGwI3U500Hz4gdH1d3DprLXqlV42Y2YJWlDxU8wkvMejrEuu6xptahmCkVFUVR1O7epqtD6uL63t3vQOjxQajCgWYFmU6kcVY6/fcgLFT6S8mzuN2+68pYAuFTO5rdLeR6khLXLzeOdZmu3dSzsGn3ky16MvV4uZNPl3Ha6XMpu5su+E1FqfkstbWXK5SwvXkXvFTVXDrSQFsDkQrbM87GAvX54sPtdJZNWlU3l24d/C8gTPSOKLxa206WymlLVEY1ApJor5fhqFT1y67sKOCSdrRy3DvfTBxVw6kFlt6mU8lsFPnbD107NwOMd9zHusu5B3123L8qd9MAzElyfSWXKauFt6H3oqbBdLKayJejZCvgKuVShmOV8GU//nJrOA2sedSi4nYnN8Q+QyrNJj2eTKrNJVX8nIUMMPaiqqFldbIDkkjj8wveKDvPSiUai8JCcX9H1Lvyeeb/"
//		"JSMc9OcJegY5kJBoRJ7Eld2wUxiajK9IShmvIGUNiSpG3uyuSxA85UuSkKwbhRojL8aptV01i29K6Q184Cq8OnPaQ4Z5+yROpvLhPXuzRftc5i14PvC3Pa3eaO9GodxLk+DpXcNlV0PUHr/h5ZDsj5/zoeI2b3RVWiHW4eUQH1IHYQBTLTeSWYiK+MoC4mFOIH4zv2w9kPPq2n1MdYgdf7cKN86CEaAXejqh81wcM7pr5Rv/UHrzHaVyFx2dyrN4ngOAKHbMC9++uq/WSuBqKWf02hNDn0ha+ea98Sl7cf6eC/ob8LAI6ZNa/V9958J6iMOoMWV/pENOm72G0A8BvXj4wMz0QQyWa8rVjczPGxl5hbHbGWDwOx3mEvudHaHcpQNAItmDMpcXcfYr3FMGWXR6dFS8qSfwOzw00s+"
//		"Suucw3P3J0mlaeDJllb7Uo61n2IzeMuiFF9UsjKC0Ed4PBudvq4nH10UjscpkfuLBBfMOCfzTYPfQ4tnPpQraYKmaRw38Ajk1fZL7oBqLLRWZ8kdl0KV9OFUpcpPcAHLlxkSJg5brQLPKcDAEzk4bQmyrlYWjQ5izlgFvs9KUnULJpB1BI2muR5ao1ZAZlygH9XF7kFHzxeP/dt9wXFx/T0/TxLv7x/sskjVzHfcORiunCwAH0f49AbkoX4Dej4he2stjKYiuHrRy28tjKY6uArQK2trG1ja0itorYKmGrhK0ytsoFFKziF7YQI4MYmaz6/in7YKkBn80/77PxfvSfrrpr1HXOojsNn72rVJTPYLFgoHJvqm2FKpYSBFIgufcFePkxsHQ4ZULtZFsdBq4k/P9noJz6GcWbEdtSzsinBHYS+XQIPsV41mD04kt+0bBDewJ/353kJxc/NB2j58U8EQN1vP54pGRzW2phK6tmM8rFv9nw+"
//		"EgtPiqUUwoBVc4vvrIVndy3HigwW95NJkw63kNHx26Z3WtCP4GEccQuGR0PIqJ8E9zSMxwq3o4w/v6n6xaN8xwBY60nBdJZMgIPUmROxNBIdMEVGg4lZuiDrncPx1Hjsrh30oJLKrz4v7Zb07Ci1DgRok22VFKL23IC+sWFmaBE//sHT+TkuN7eiyFQfWGW6tL/WnXxSiDGE+Oc955gOXTUUjAznUumRwpK5sWgueSmtwUX/L2o4sda0U4E7T8BlS9MC5gmAAA=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$btnConfirma", "Value=Confirmar", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=S", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=300", ENDITEM, 
		LAST);

	/* Protocolo Lance Livre 860360 */

//	web_revert_auto_header("Origin");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmConCpCadCredenciamentoLance.aspx_5",
		"URL=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?Comprovante=S&CredLanceFiltro=False", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t233.inf", 
		"Mode=HTTP", 
		LAST);

//	web_revert_auto_header("Upgrade-Insecure-Requests");

//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"image");

	web_url("frmConCmNewconReports.aspx", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=Save.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t234.inf", 
		LAST);

//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"iframe");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");

	web_url("frmConCmNewconReports.aspx_2", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&sr_print=53b3381ec8d1431e", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t235.inf", 
		"Mode=HTTP", 
		LAST);

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"image");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");

	web_url("frmConCmNewconReports.aspx_3", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=PrevPageDisabled.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t236.inf", 
		LAST);

	web_url("frmConCmNewconReports.aspx_4", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=FirstPageDisabled.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t237.inf", 
		LAST);

	web_url("frmConCmNewconReports.aspx_5", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=NextPageDisabled.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t238.inf", 
		LAST);

	web_url("frmConCmNewconReports.aspx_6", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=LastPageDisabled.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t239.inf", 
		LAST);

	web_url("frmConCmNewconReports.aspx_7", 
		"URL=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=toolBarSeparator.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t240.inf", 
		LAST);

	lr_end_transaction("ID500_DW_08_ConfirmarLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_09_VoltarParaOferta");

	web_add_header("Origin", 
		"https://{host}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");

	web_submit_data("frmConCmNewconReports.aspx_8", 
		"Action=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t241.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAM1ZW2/bNhRe3HJt024e0M0bsFULurwEJQKn65L2IcDiW5I2rl0rSbthgMdIlM1FEj2KSuz+j73tF+wH7O9th6Jv8iXpSg1oHhxdqE8853znO4fUPyv5r1aQ1W6XeSgF96MW/T1mgjZ5JEvEOX9BB+12YRd950i/WFxXo2js8nVbstf0rEV9IrlgcE4uKKpdMyi53R7dbs/crjERySbpUFQ1wmkKepEBzEvaz2I2R2Ro1I9GMHu+jw6MEMqxEDTUc8kOqWQWKoCIMsF4buZd11UwJUHJeYTqRli2JKFLhGxWajUYYjq1anBGXZe6GmvfCOskoichc7hLDYHKPOgJGkXURa/MrOv3uJAt6R1Dtu1Fh4Hi1AszPrjenpqfz0jomIK9YL5v94hDj1gILDsym1ksa5QmTCubx6AiyGWJC5cKdGiYzvKIhx1tYdmM+"
//		"wz8Tg0ZP6SozcLOh4hV4fFZxlhmFQbiV3XNNbAe+5JB9GrMN9bkMve5MGwH9gUZRA7xTduKCY5ZvtV5yJ2u4EGGQGbipMWzQiRphP4AnZjWhgr1CJDAHkSSBtUQCAppY8iEY6IIboZREyTIBqNl6iKl3QeUgOhGNc4l/DPsFlo04Be0GvTkIKkz6KWZAJ+zHiRfHITDWSI7A4o1zn6jjqxxERApFSfMQMGPjXDKldqThsHRM60Sp6uAj7ndpVQaBkdjTnWGZgqr1kgtqiDrrpMh1tsPFKufKZZZ79Xo0XDPA5rpmKKG6WqMXzYFC2WFO3EAiyHUNAesg+B6g2SI6vXN9DxBLPPeIOmsQxfKYK/"
//		"LnAj9Yg4Ly6WG0LPV6CGXRDIeRoZuUEWIdZgkvs06IZGxoOi1WfWnskyFZB5ziKQ1qLplMehJfnKIvtDALOi093xgBrFp2CVoQ19OliKlWEoe7jmw1CE2k3TPDVjIIimIywUZbYrMDuUVFhEfZgSiSVKvgcC6TNGF59HqVvHx9z9sb+083c67hZyXzxduWjnH9ax7J62j9gH1e22whMK9XA5GrHr5Qs66dcoiBiW16yYXc7kb8Nxt677d5bAa4OcBEeeRnkvXyieeUHyHRamMo7sbf6yAf4LYj7gnN/WtTRi0qb12yuglFY9GLpw8iNcWPobXTqHEQNx3Hxe3nmxubW49KxY3i3itDG0ExG43pDH4ysdrTehzmfOCDo75OQ13waxt+HPOyNaz7Sc75CPrc2VAk6gqrarqyIL7ajuKqh2UkPpj0ws3Pe2y0U9uJX0+/PnMdQsrngt34fxXa30BvcA+qBqh6lJcZStFN6WIqXVbic+"
//		"BDHx0kmwwtEjYodimSf2L9gWPeyXexz9zHuAk/ro6Yi0vkBsUpzYV8IwAWV/bcVJVX4LFtgQp6SRTOSV+TKl1K9E+6SFx1duTF7doBAVfZZ8+fxUTn8nB1EzG4xc2MHi2BdEvrzAP2Ve9PN194mX9Ix4dAKBaWljFayRkWUQK8AbwRhRdwqJ32lcb7wKYjB0iPVjGAz0IecSPqHUv8cJI3huTYjT2QKqep87eps76eDzt8VXru/kassxyq3EZzpi+jLHPe7SDDq9l7GjJiFOLPs2f40FvzBhNhXJ0gepXUmEYYuX4hoDhCg6G9SCfQYXxXFdqfTlv0jTzm66H/r7xn6k/2paCC3Uqu9xNZ8TszhxO7a3hye4Ynuxv4UU7VDi9xzSb23iaqThlKZ6POl5Q+/Gy6o2v4boKhapvcAxie0TDjuziBXTHy+"
//		"sinhMmPCYodWIBntTqjGdB9WUdQfuig1YnARxqypmHHr0LkWBgohXfLEmS6WzWhHH6mdO+GWafSm96ETp4b0mfrSF3FGS171Af/bliWCjGQr54yYcXL9rwwmUXnl04JZJ7rYJtLGP9sgfWl7N4XvQXpNliLr0JgHkPFiTSdI0oMfmkaD26ZgIL5py8ouFG6On7Bsz6NGEnh1atySEzDJCSGgdSSTwgbSpfPxlT63GxuPOh0ytx6j50LBnma1JP7YF//v+0QbeHKvk25faHi7vCFI+G/cn6MoYu6w2OmZepg4ZMlldjXsmNudbz4ZUSMJeqpaCXpUVJOrwGhUo4335vs96xz9ZRATvRX1emV/ojFJ75jIQnH4Lw9KccrK+BD5UTxmD66rTZOHVfnbxJfn9a3Ndpz9e7ElUzWRlprydSA8qbyob1ZZo9T3E3h2AhnPs213Xd3J3J4ao+Knycu6UuWnfqpK9zJbcGt+8mI3eS4/zk+F+/"
//		"PtfwFiEAAA==", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$SaveTypeList", "Value=Adobe PDF File...", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioPageNumber", "Value=1", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$PagesRange", "Value=ctl00_Conteudo_StiWebRelatorioAll", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoom", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageFormat", "Value=Jpeg", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioExportMode", "Value=Table", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageResolution", "Value=10", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageCompressionMethod", "Value=Jpeg", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageQuality", "Value=10", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$BorderTypeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioSimple", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoomX", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoomY", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingTextOrCsvFile", "Value=1252", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ImageTypeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioColor", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingDifFile", "Value=437", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ExportModeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioTable", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioSeparator", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingDbfFile", "Value=Default", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$SaveReportGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioSaveReportMdc", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioPasswordSaveReport", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioUserPassword", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioOwnerPassword", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncryptionKeyLength", "Value=Bit40", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioSubjectNameString", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$btnVoltar", "Value=Voltar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=nJfCjoZCq4ZG0dr9n2xdpfEx9MaIujnU6IDUA0rkS4O+R2tIrmHjsCAmMyyjhBTXaJUn8wg3G5rsnFjF4e4e3bQ67jcbp4rsQ+2aMgqOQBCxdHYV7Id1CZVPRWbGXFDXOXSeGZax4+wTr9akYZ30LglsbQSPv5hwb/ZtTIAA6OfEzKm2p/XQIy2yTSAsU6S24+SdTiVzaBKZh5uTOu2SOzufMTo2w85SYcCsbAfyhUslB6ZVv132LXlb8jk9RLs5uJONawX0jCjJlRDPYFbLIppp+VfKVgMBoa5dttv25Uwgv8gy1FxncHMKprIu+ZB5lUoTThY61IXJTa4PmLR7xkcTfbmUZSiwxbbsXgYN5tKnvPXjkEl+pnXWl0VrnbYGlQY3Afl6US6XSnYLbdocTbuqyP27OoJXYjMWTVFAGQsf/3qYA9G0byRX6lh6QQOo16eTVZlzT3E/"
//		"JmVNahsJK8I1DNxsmq34v8WRQybSYhR9Ipc+RCjh3OmX+SG9KXejxxuWsypT9taWnG9Xw1smFLFGaXXxuimTyZGOLfVX6J22q3OW2D2Kb1k0xszWiDpBZnDbzzoHtCY+in5sH/AIFLsh1G0ga+dvWwR9FFrkMWIraHEXfW5M6EjwKzBcYM659gff/MMw6ZPCWlSBUpzmd59bf0921b4cgolam21juH18KUQ46QeSKTF/UOf2exw3bPVHEaiohY1oLLiqiHbqT965P5GeyZRZHHCQiIMghN6fQsyvvzoU2djjHrrnAHLUqnp5yRkaA1s+MVSdLF87FtHVrHPikxxc7HCwvdJQI+sk1nA4XC0pMNe6YReGCKA8+h+7QbgC67lQPBaKtOI5C5Es6idOJPhoXb2i+gRqmoO0m62mnaMwBZ5htBwxCrF8UfeX8O0jrXgqUZS73nJYJuqsaMIqQX9eLh8obc4ci2m64Z1O++"
//		"hRxFgYqXTYFU513RTMmfAktGj35mdET5Z5F+ee4MnUaXotYPKs7WxaqPfFdHNI0fx6B+9ISEDZpnjilfDptuOamHO39f0cbGjUtLT3Du2sBL/lN3cpCfUfnnBrTv0Lq2wBq3Jm1Z2zO7JKD0VRM/THcfx8JekIWUEEm/8oQihhXMas+3/a6tQUCUJ2bNAciEkyFKdNptrZEd6aY5YtCGX7LPui2+dqR/90wIxPN/2y4h0oQIcDVIxHqxCBLs90441NGe3FLMS77ihbGCNEJ9qNT5qf99kmR37M+PDUKM5BlIDShGQSYg39frbbv5w2yNvuZvSVr49yUHOrIpAfixIPqfZ4je1M7zoVycLm2CIN3xxmG4zRc5jbHwa05xeYht2HV8ALwk9vChoaH4I7U9CmfsMIG3PGKbDNoV5eh+a/Yw9Sx8rx/84MLffTm2/WKXVC0PV2fHn8cLpWro/Rs5Ixts0G2Ugn0+YGey3BBZ9v2xTdiYPbLZb4"
//		"/oulpKgGLwoZw3Qy48XvaQE0Zhjrzaz6ywXzZBA8ZJ5vxHTqqK7Ko5Yzsy4+dHF3kEHXOopfUW9ziC6J3fTKxn2/cA0wi2SVp7d+F0AkY5aE4QqvoF7hsXtJdkT5k/kAugpEUQcHnm/1Ce9U7RH0Ef6CUa6WokyudS4/dmQHmKnItBxfZFEaES6ZgLz64kfSTrt68t/pkWqF+ATd6U9+or4KQNu6kkOq9fR0swgJRVZoWqFgxJ+bt9g9O47378Lj3i7N96FD0F1soa2Rb0SsaC7s2tUK8PJuS8OijNJBzjNZMtK7TPD9Rnt4fdKJ3aSOiAV6u7D3ht3v9Ubeq8wLfm70Cm/vzOV3HVlizOA2yQ5sMs5I0WImiazbTMLWw6z8lIPA7BXkE/x02V/sRkcduVnVxa0estwQb/UWPNSUcReaDob+yhmGwXkLd995RIDlEEb3ZfChzpvzdQoHpL6iCX+"
//		"96DDtYF26O2Y0QLuP4hrVftLUIeJTTqeFZKIbMyiIolgvuW68Qav5Po9EnS9H3RIPYUy8ml4FoG/aDsOTFc1MM5uaz/8cblo48GqFDVxj8zq/qQ9AcVryRDsewKXlkRD+bsd6WiH0eCF8F9mGlcgkxmEagbGcc/yx4sKApWatZGE7YIGRoc1v+T04CV+SorpAfPdW7KO0nqg3wDL9BExSAidUnPcfVRHCBRnYy17K/AKjOiBMWkvsMXY1nMOS4NGgY6rRVuU/BOh6ezJ6u2B2niGYTHC7CxJbjusMayQecr+ZDHwLbHbwravlCSoHaI8t3Jvs6+wUe8ANLoNam9tzetc+YbnPeW9an4NIPC5u1WqO28RSnPjebyyv3UAuykM9pY7zcOLiXhS38ZbCy/6sIr9+kUwJ3uxY6t7yBHjgaZBufie/mkk4XriEnDDa2H8dq+RhopBT1RcP1innwO0MjITjklLzsX9FmTW1VdOQ7+45EXHYhYDS+"
//		"7OLV7DMnDGboejifWQk7fDqYZR5NXhkxK9pmCXwMAJLkcarTTJUOKLfJjRgNKRCtBi8xjDFXjtSBAbIKaKlTSpbjzIHn33UzyArnmiAsEHRp0DGcUZNVoMD7LODtzZulT5Q4VHmYS46QG619/WlDMVWvr9P3XML9NlIGUCXbWPCUhWrp6xJ0hmiQIt1CXsSZ2lPAMu+DRQfHk4OjOFBj0JwIR2LTW7bi8X+/N8GC63wxxWd/Hm6WGaaMRudd2mD1fF9EMckx5vgjEAqM0qoKEQG2b7oMRA/5xkYZSof5L5kLDUZOJMoV2sz4dEB3BVfR85gWCdyGYfooCLlMz0wgH+E0ONXd0qMGXR6bBSETdvm7EXD/dRBCQTZ+i9eayC66jhmuVX3PpZ/Kvb85ue83ZR9m8C/AK5g2l4qbf4r/tsLdoHx9GFs+c+6iIfTNetb28nYQTZBWtBO9P34i2UIFPoQ6YHtTlJYVOS+x4Oqmel/8yJ+"
//		"YngwHN2XG7byS3e995n8Hn1oHNRwo2ue5G6d1+ihSDpXtTWcdBOo0XiExtm5c5Zh8i3B4XKJuErfU0zMd5YhAwC3/meXMbZb/nhtyfgVKiqQFahMyGyGs4OuQawMUKnDGzu7UM3uJYIYyw6/pgxnyW58F6tGUxDXNZiuAF5B2HlbgWMg7g+vgbSjFXKdMtQcev0qEg8XiNovbpl4mETGgvtkuQiIfflOJRCcc/yv9hubkTHI+lkl0ndq9LltJkNZXOTdKJj1bsNhjq7neZ7g5MgqEx5zctxgkBYWQtNiAwqBuZfjtfKZx2I=", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_DW_09_VoltarParaOferta",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_DW_10_VoltarAoInicio");

	web_add_cookie("trigger_state=Li1; DOMAIN={host}");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmMain.aspx_2",
		"URL=https://{host}/NewconWeb/frmMain.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{host}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=oDlGaetLIS1/SzzqB0SZ/gpyYQ+WdzhppcHPJNBdau0csfuV2KyaIpCV5LlUB/uL", 
		"Snapshot=t242.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ID500_DW_10_VoltarAoInicio",LR_AUTO);

	return 0;
}