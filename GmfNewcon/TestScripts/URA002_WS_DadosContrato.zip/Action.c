/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  05/06/2021                                                               */
/*                                                                                      */
/* Sistema: Web Service URA                                                             */
/* Funcionalidade: URA002 Dados Gerais da Cota                                          */
/* Pre-requisitos: Consorciado (Grupo/Cota)                                             */
/*                                                                                      */
/****************************************************************************************/

 Action()
{
	char *txName = "URA002_WS_DadosContrato";

	// Global Sample Request
    lr_save_string(lr_eval_string("{SampleXML}"),"XMLrequest");

	// dynamic parameters used in XML header

	web_set_max_html_param_len("1000000");


	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//CD_Cota",
      "ValueParam=pCota", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//CD_Grupo",
      "ValueParam=pGrupo", LAST);

   
    web_reg_save_param("cCodigoErro","LB=<tns:codigoErro>","RB=</tns:codigoErro>","ORD=1",LAST);
	web_reg_save_param("cMensagemErro","LB=<tns:mensagemErro>","RB=</tns:mensagemErro>","ORD=1","NotFound=warning",LAST);
   

	lr_start_transaction(txName);
    web_custom_request(txName,
		"URL={endPoint}",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=",
		"Snapshot=t3.inf",
		"Mode=HTTP",
		"EncType=text/xml", "Body={XMLrequest}" , LAST);


   	if(strcmp( lr_eval_string("{cCodigoErro}"),"0" ) == 0)  //Sucesso
    {
		
		//lr_message("Codigo de Erro: %s",lr_eval_string("{cCodigoErro}"));
		lr_output_message("Grupo: %s Cota: %s retornou contrato em %f segundos",lr_eval_string("{pGrupo}"), lr_eval_string("{pCota}"), lr_get_transaction_duration(txName));
		lr_end_transaction(txName,LR_PASS);
		lr_think_time(12);		
        return 0;
    }
    else
	{	   
		lr_end_transaction(txName,LR_FAIL);
        lr_error_message("Codigo de Erro: %s%s%s%s%s%s%s", lr_eval_string("{cCodigoErro}")," || Mensagem de Erro: " ,lr_eval_string("{cMensagemErro}"), " || Grupo/Cota: ",lr_eval_string("{pGrupo}"), "/", lr_eval_string("{pCota}")); 
		//lr_error_message("Codigo de Error: %s", lr_eval_string("{cCodigoErro}"));
		lr_think_time(12);
		return 1;
	}
    

    }

