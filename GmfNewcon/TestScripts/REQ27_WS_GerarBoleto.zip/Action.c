/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  13/06/2021                                                               */
/*                                                                                      */
/* Sistema: Web Service CRM Dynamics                                                    */
/* Funcionalidade: REQ27 CRM Dynamics Gerar Boleto, ap�s REQ10 Cobran�as Pendentes      */
/* Pre-requisitos: Consorciado (Grupo/Cota/Vers�o)                                      */
/*                                                                                      */
/****************************************************************************************/

 Action()
{
	char *txName1 = "REQ10_WS_CobrancasPendentes";
	char *txName2 = "REQ27_WS_GeraBoleto";

	// Global Sample Request
    lr_save_string(lr_eval_string("{SampleXML}"),"XMLrequest");
    lr_save_string(lr_eval_string("{SampleXML2}"),"XMLrequest2");

	// dynamic parameters used in XML header

	web_set_max_html_param_len("1000000");


	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//codigoCota",
      "ValueParam=pCota", LAST);

	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//codigoGrupo",
      "ValueParam=pGrupo", LAST);
	
	lr_xml_set_values("XML={XMLrequest}","ResultParam=XMLrequest",
      "Query=//versao",
      "ValueParam=pVersao", LAST);	

    web_reg_save_param("cCodigoErro","LB=<tns1:codigoErro>","RB=</tns1:codigoErro>","ORD=1",LAST);
	web_reg_save_param("cMensagemErro","LB=<tns1:mensagemErro>","RB=</tns1:mensagemErro>","ORD=1","NotFound=warning",LAST);
	
	//captura primeira cobran�a pendente
	web_reg_save_param("cCobrancaPendente","LB=<ns0123:idCobranca>","RB=</ns0123:idCobranca>","ORD=1",LAST);

	lr_start_transaction(txName1);
    web_custom_request(txName1,
		"URL={endPoint}",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=",
		"Snapshot=t3.inf",
		"Mode=HTTP",
		"EncType=text/xml", "Body={XMLrequest}" , LAST);


   	if(strcmp( lr_eval_string("{cCodigoErro}"),"0" ) == 0)  //Sucesso
    {
		
		//lr_message("Codigo de Erro: %s",lr_eval_string("{cCodigoErro}"));
		lr_output_message("Grupo: %s Cota: %s Vers�o: %s retornou contrato em %f segundos",lr_eval_string("{pGrupo}"), lr_eval_string("{pCota}"), lr_eval_string("{pVersao}"), lr_get_transaction_duration(txName1));
		lr_end_transaction(txName1,LR_PASS);
		lr_think_time(12);		
        //return 0;
    }
    else
	{	   
		lr_end_transaction(txName1,LR_FAIL);
        lr_error_message("Codigo de Erro: %s%s%s%s%s%s%s%s%s", lr_eval_string("{cCodigoErro}")," || Mensagem de Erro: " ,lr_eval_string("{cMensagemErro}"), " || Grupo/Cota/Vers�o: ",lr_eval_string("{pGrupo}"), "/", lr_eval_string("{pCota}"), "/", lr_eval_string("{pVersao}")); 
		//lr_error_message("Codigo de Error: %s", lr_eval_string("{cCodigoErro}"));
		lr_think_time(12);
		return 1;
	}
    
    
    //REQ27
    
	lr_xml_set_values("XML={XMLrequest2}","ResultParam=XMLrequest2",
      "Query=//codigoCota",
      "ValueParam=pCota", LAST);

	lr_xml_set_values("XML={XMLrequest2}","ResultParam=XMLrequest2",
      "Query=//codigoGrupo",
      "ValueParam=pGrupo", LAST);
	
	lr_xml_set_values("XML={XMLrequest2}","ResultParam=XMLrequest2",
      "Query=//versao",
      "ValueParam=pVersao", LAST);	
    
	lr_xml_set_values("XML={XMLrequest2}","ResultParam=XMLrequest2",
      "Query=//descricaoAvisos",
      "ValueParam=cCobrancaPendente", LAST);	    

    web_reg_save_param("cCodigoErro","LB=<tns1:codigoErro>","RB=</tns1:codigoErro>","ORD=1",LAST);
	web_reg_save_param("cMensagemErro","LB=<tns1:mensagemErro>","RB=</tns1:mensagemErro>","ORD=1","NotFound=warning",LAST);    

	lr_start_transaction(txName2);
    web_custom_request(txName2,
		"URL={endPoint}",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=",
		"Snapshot=t3.inf",
		"Mode=HTTP",
		"EncType=text/xml", "Body={XMLrequest2}" , LAST);


   	if(strcmp( lr_eval_string("{cCodigoErro}"),"0" ) == 0)  //Sucesso
    {
		
		//lr_message("Codigo de Erro: %s",lr_eval_string("{cCodigoErro}"));
		lr_output_message("Grupo: %s Cota: %s Vers�o: %s retornou contrato em %f segundos",lr_eval_string("{pGrupo}"), lr_eval_string("{pCota}"), lr_eval_string("{pVersao}"), lr_get_transaction_duration(txName2));
		lr_end_transaction(txName2,LR_PASS);
		lr_think_time(12);		
        return 0;
    }
    else
	{	   
		lr_end_transaction(txName2,LR_FAIL);
        lr_error_message("Codigo de Erro: %s%s%s%s%s%s%s%s%s", lr_eval_string("{cCodigoErro}")," || Mensagem de Erro: " ,lr_eval_string("{cMensagemErro}"), " || Grupo/Cota/Vers�o: ",lr_eval_string("{pGrupo}"), "/", lr_eval_string("{pCota}"), "/", lr_eval_string("{pVersao}")); 
		//lr_error_message("Codigo de Error: %s", lr_eval_string("{cCodigoErro}"));
		lr_think_time(12);
		return 1;
	}
	
	
	
    }

