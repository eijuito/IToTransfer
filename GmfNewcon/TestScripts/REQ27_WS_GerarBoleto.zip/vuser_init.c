 
vuser_init()
  {
  long file_stream;
  char *filename = "request.xml";
  char *filename2 = "request2.xml";
  char lineBuffer[1024];
  char *requestBuffer = 0x00;
  long bufferSize = 5*1024;

  // Start with 5K, will increase if needed ...
  requestBuffer = (char *)calloc(bufferSize, sizeof(char));

  if ((file_stream = fopen(filename, "r")) == NULL )
    {
    lr_error_message("Cannot open %s", filename);
    return -1;
    }

  while( fgets(lineBuffer, sizeof(lineBuffer), file_stream) )
    {
	if( bufferSize - strlen(requestBuffer) < 1024 )
	  {
      bufferSize += 5*1024;
      requestBuffer = (char *)realloc(requestBuffer, bufferSize);
	  if( ! requestBuffer )
	    {
	    lr_error_message("Unable to allocate buffer of %d bytes", bufferSize);
		break;
		}
	  }
   	strcat(requestBuffer, lineBuffer);
    }

  if(requestBuffer)
	{
	lr_save_string( lr_eval_string(requestBuffer), "SampleXML" );

    // Free our buffer and close the file
    free(requestBuffer);
    }

  fclose(file_stream);
  
  //second XML
  
  // Start with 5K, will increase if needed ...
  requestBuffer = (char *)calloc(bufferSize, sizeof(char));

  if ((file_stream = fopen(filename2, "r")) == NULL )
    {
    lr_error_message("Cannot open %s", filename2);
    return -1;
    }

  while( fgets(lineBuffer, sizeof(lineBuffer), file_stream) )
    {
	if( bufferSize - strlen(requestBuffer) < 1024 )
	  {
      bufferSize += 5*1024;
      requestBuffer = (char *)realloc(requestBuffer, bufferSize);
	  if( ! requestBuffer )
	    {
	    lr_error_message("Unable to allocate buffer of %d bytes", bufferSize);
		break;
		}
	  }
   	strcat(requestBuffer, lineBuffer);
    }

  if(requestBuffer)
	{
	lr_save_string( lr_eval_string(requestBuffer), "SampleXML2" );

    // Free our buffer and close the file
    free(requestBuffer);
    }

  fclose(file_stream);
  
  return 0;
  }

