Action()
{

	rdp_connect_server("Host=10.217.6.5", 
		"UserName=IOAD\\GXQQIB", 
		"EncryptedPassword=60da6923e", 
		"Domain=", 
		RDP_LAST);

	rdp_set_lock("StepDescription=Lock Key Set 1", 
		"LockKeyValue=VK_NUMLOCK", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 1", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=633", "ImageTop=547", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_2.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 1", 
		"Snapshot=snapshot_1.inf", 
		"MouseX=653", 
		"MouseY=567", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 2", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=898", "ImageTop=544", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_4.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 2", 
		"Snapshot=snapshot_3.inf", 
		"MouseX=918", 
		"MouseY=564", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	/*	This script contains keyboard steps without automatic synchronization.
		Consider adding a synchronization step before the relevant keyboard steps.*/

	rdp_type("StepDescription=Typed Text 1", 
		"Snapshot=snapshot_5.inf", 
		"TypedKeys=Vitor.Vitor-2021", 
		RDP_LAST);

	lr_think_time(6);

	rdp_sync_on_image("StepDescription=Image Synchronization 3", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=1021", "ImageTop=542", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_7.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 3", 
		"Snapshot=snapshot_6.inf", 
		"MouseX=1041", 
		"MouseY=562", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 4", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=1004", "ImageTop=550", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_9.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 4", 
		"Snapshot=snapshot_8.inf", 
		"MouseX=1024", 
		"MouseY=570", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 5", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=797", "ImageTop=514", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_11.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 5", 
		"Snapshot=snapshot_10.inf", 
		"MouseX=817", 
		"MouseY=534", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 6", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=846", "ImageTop=526", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_13.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 6", 
		"Snapshot=snapshot_12.inf", 
		"MouseX=866", 
		"MouseY=546", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 7", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=880", "ImageTop=544", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_15.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 7", 
		"Snapshot=snapshot_14.inf", 
		"MouseX=900", 
		"MouseY=564", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	lr_think_time(6);

	rdp_disconnect_server("StepDescription=Server Disconnect 1", 
		RDP_LAST);

	return 0;
}