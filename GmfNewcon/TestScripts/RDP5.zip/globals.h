#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "lrrdp.h"

//--------------------------------------------------------------------
// Global Variables

#endif // _GLOBALS_H
