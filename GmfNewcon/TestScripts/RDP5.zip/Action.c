Action()
{

	rdp_connect_server("Host=vmnewcon022.io.ad.gmfinancial.com", 
		"UserName=GXQQIB", 
		"Password=", 
		"Domain=IOAD", 
		RDP_LAST);

	rdp_set_lock("StepDescription=Lock Key Set 1", 
		"LockKeyValue=VK_NUMLOCK", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 1", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=633", "ImageTop=547", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_2.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 1", 
		"Snapshot=snapshot_1.inf", 
		"MouseX=653", 
		"MouseY=567", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 2", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=898", "ImageTop=544", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_4.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 2", 
		"Snapshot=snapshot_3.inf", 
		"MouseX=918", 
		"MouseY=564", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	/*	This script contains keyboard steps without automatic synchronization.
		Consider adding a synchronization step before the relevant keyboard steps.*/

	rdp_type("StepDescription=Typed Text 1", 
		"Snapshot=snapshot_5.inf", 
		"TypedKeys=Larah.Vitor-2021", 
		RDP_LAST);

	lr_think_time(6);

	rdp_disconnect_server("StepDescription=Server Disconnect 1", 
		RDP_LAST);

	return 0;
}