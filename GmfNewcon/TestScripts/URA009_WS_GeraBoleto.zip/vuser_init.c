vuser_init()
{
	//DXC_LoadFileToParameter("req_pre.xml", "request");
	//DXC_LoadFileToParameter("req_new.xml", "request");
	DXC_LoadFileToParameter("request.xml", "request");
	return 0;
}
