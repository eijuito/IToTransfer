#ifndef _DXC_UTILS_
#define _DXC_UTILS_

// =====================================================
// Function declarations
// -----------------------------------------------------
int DXC_LoadFileToParameter(char *fileName, char *parameterName);
// =====================================================
// Function code
// -----------------------------------------------------
int DXC_LoadFileToParameter(char *fileName, char *parameterName) {
	long f, numBytes;
	char *b;
	
	int rc = 0;
	if((f = fopen(fileName, "r")) == NULL) {
		lr_error_message("Unable to open %s", f);
		return LR_FAIL;
	}
	fseek(f, 0L, 2); // 2 = SEEK_END
	numBytes = ftell(f);
	fseek(f, 0L, 0); // 0 = SEEK_SET
	b = (char *)calloc(numBytes, sizeof(char));
	if(b == NULL) {
		lr_error_message("Unable to allocate buffer of %d bytes", numBytes);
		fclose(f);
		return LR_FAIL;
	}
	fread(b, sizeof(char), numBytes, f);
	lr_save_string(b, parameterName);
	fclose(f);
	return LR_PASS;
}
// =====================================================
// -----------------------------------------------------

// =====================================================
#endif /* _DXC_UTILS_ */