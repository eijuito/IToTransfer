Action()
{
	web_set_max_html_param_len("1000000");
	
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//CD_Cota", "ValueParam=CdCota", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//CD_Grupo", "ValueParam=CdGrupo", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//CD_Transacao", "ValueParam=CdTransacao", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//Celular", "ValueParam=NmCelular", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//ST_Tipo_Boleto", "ValueParam=TpBoleto", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//ST_Tipo_Envio", "ValueParam=TpEnvio", LAST);
	lr_xml_set_values("XML={request}", "ResultParam=request", "SelectAll=No", "Query=//VL_Antecipacao", "ValueParam=VlAntecipacao", LAST);

	web_reg_save_param("response", "LB=", "RB=", "Ord=1", "Search=Body", "NotFound=Warning", LAST);
	
	lr_start_transaction(lr_eval_string("URA009_WS_01_transaction"));
	web_custom_request("wstransaction",
	                   "URL={URL}",
	                   "Method=POST",
	                   "Resource=0",
	                   "RecContentType=text/xml",
	                   "Mode=HTTP",
	                   "EncType=text/xml",
	                   "Body={request}",
	                   LAST);
	
	lr_xml_get_values("XML={response}", "ValueParam=CdErro", "Query=//codigoErro", "NotFound=Continue", LAST);
	lr_xml_get_values("XML={response}", "ValueParam=MsgErro", "Query=//mensagemErro", "NotFound=Continue", LAST);
	lr_xml_get_values("XML={response}", "ValueParam=vencimento", "Query=//DT_Vencimento", "NotFound=Continue", LAST);
	lr_xml_get_values("XML={response}", "ValueParam=VBoleto", "Query=//VL_Boleto", "NotFound=Continue", LAST);
//	if(strcmp(lr_eval_string("{CdErro}"), "0") == 0) {
		lr_end_transaction(lr_eval_string("URA009_WS_01_transaction"), LR_PASS);
//	} else {
//		lr_end_transaction(lr_eval_string("URA009_WS_01_transaction"), LR_FAIL);
//	}
//	lr_output_message("response:%s", lr_eval_string("{response}"));
	lr_output_message("grupo:%s cota:%s tBoleto:%s tEnvio:%s valor:%s Venc:%s vBoleto:%s Erro:%s %s", lr_eval_string("{CdGrupo}"), lr_eval_string("{CdCota}"),
	                  lr_eval_string("{TpBoleto}"), lr_eval_string("{TpEnvio}"), lr_eval_string("{VlAntecipacao}"),
	                  lr_eval_string("{vencimento}"), lr_eval_string("{VBoleto}"),
	                  lr_eval_string("{CdErro}"), lr_eval_string("{MsgErro}"));
	
	return 0;
}
