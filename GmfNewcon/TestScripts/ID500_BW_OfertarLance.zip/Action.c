/****************************************************************************************/
/* Criado por: Celso Eiju Ito															*/
/* Criado em: 	30/05/2021 - recriado em 03/07/2021										*/
/* 																						*/
/* Sistema: Business Web																*/
/* Funcionalidade: ID500 Ofertar Lance               									*/
/* Pre-requisitos: Consorciado (Grupo/Cota/Versao) precisa nao ser elegivel a dar lance	*/
/*                 Dealer (Usuario/Senha) precisa ser ativo e poder Ofertar Lance		*/
/****************************************************************************************/

int i = 0;

Action()
{
	lr_save_int(i++, "IT");
	lr_message(lr_eval_string("IT: {IT} USER {pUser} grupo {grupo}, cota {cota}, versao {versao}"));

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("1024");

//	web_add_header("A-IM",
//		"x-bm,gzip");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");

//	web_url("seed", 
//		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=91", 
//		"Resource=1", 
//		"RecContentType=application/x-gzip", 
//		"Referer=", 
//		"Snapshot=t91.inf", 
//		LAST);

	lr_start_transaction("ID500_BW_01_LoadURL");

//	web_add_cookie("NID=216=GFUP-RAVd26c9DfQ7pP1BPhyuGWfRZubQm0tj1wuKgcAIpL4j1vrmApetiRaMIvdoOqCH_UYf9GnYwTkzd9kH7W4bidMwaz9zKDsSNHgZJhKXNvnDaXXbgZ6gKuWmOWY1HGfY-Id84B7cWRQWjkGzKOpJZhvFNZDwcjHlOGyJFQ; DOMAIN=accounts.google.com");

//	web_add_header("Origin", 
//		"https://www.google.com");
//
//	web_custom_request("ListAccounts", 
//		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t92.inf", 
//		"Mode=HTML", 
//		"Body= ", 
//		LAST);
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_header("sec-ch-ua-mobile", 
//		"?0");

	web_reg_save_param_regexp(
		"ParamName=pViewState",
		"RegExp=id=\"__VIEWSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmCorCCCnsLogin.aspx",
		"URL={host}/frmCorCCCnsLogin.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_6.pb", "Referer=", ENDITEM, 
//		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvOTEuMC40NDcyLjEyNBIXCSwFKB3viEGDEgUNFnpvjBIFDY1wgDg=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	/* Request with GET method to URL "https://{domain}/favicon.ico" failed during recording. Server response : 404*/

//	web_add_header("X-Goog-Update-AppId", 
//		"nmmhkkegccagdldgiimedpiccmgmieda,pkedcjkdefgpdelpbcmbmeomcjbeemfm");
//
//	web_add_header("X-Goog-Update-Updater", 
//		"chromecrx-91.0.4472.124");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("X-Goog-Update-Interactivity", 
//		"bg");
//
//	web_custom_request("json", 
//		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:3565700333&cup2hreq=066d2d49c985dfc20f13fc7ded9b0d57739e44167a40f4cf7a4d86e77d6ba84f", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t94.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\"{d3b9ab65-53ba-48e4-87a1-579ee03cfaf2}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"pkedcjkdefgpdelpbcmbmeomcjbeemfm\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\""
//		"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"1.3bba8f43f392ecbc35b582986edcbf7c6591081b63f3f0214f8eed1d239b0f60\"}]},\"ping\":{\"ping_freshness\":\"{e37a657a-aa12-48cd-89ae-5f63ad92a845}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"9121.329.0.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\""
//		"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\"{5751332b-f6f2-469d-8500-b1e47afe8c0d}\",\"sessionid\":\"{f03b039e-8502-44fd-ad13-a763dde6e206}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.82\"},\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);

	lr_end_transaction("ID500_BW_01_LoadURL",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_02_Login");

//	web_add_header("X-Goog-Update-AppId", 
//		"ihnlcenocehgdaegdmhbidjhnhdchfmm,cmahhnpholdijhjokonmfdjbfmklppij,gcmjkmgdlgnkkcocmoeiminaijmmjnii,khaoiebndkojlmppeemjhbpbandiljpe,lmelglejhemejginpboagddgdfbepgmp,giekcmmlnklenlaomppkphknjmnnpneh,oimompecagnajdejgnnjijobebaeigek,obedbbhbpmojnkanicioggnmelmoomoc,gkmgaooipdjhmangpemjhigmamcehddo,jflookgnkcckhobaglndicnbbgbonegd,jamhcnnkihinmdlkakkaopbjbbcngflc,aemomkdncapdnfajjbbcbdebjljbpmpj,dhlpobdgcjafebgbbhjdnapejmpkgiie,ehgidpndbllacpjalkiimkbadgjfnnmc,ggkkehgbnfjpeggfpleeakpidbkibbmn,"
//		"hfnkpimlhhgieaddgfemjhofmfblmnib,llkgjffcdpffmhiakmfcdcblohccpfmo,ojhpjlocmbogdgmfpkhlaaeamibhnphh,pdafiollngonhoadbmdoemagnfpdphbe,hnimpnehoodheedghdeeijklkeaacbdc,eeigpngbgcognadeebkilcpcaedhellh");
//
//	web_add_header("X-Goog-Update-Updater", 
//		"chrome-91.0.4472.124");
//
//	web_custom_request("json_2", 
//		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:2750523642&cup2hreq=3ee6233b585d838d7dff078910985756991bc2e1f02dbedbd99b817abfca0189", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t95.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{3f255add-28d1-4059-af5f-b44cebedd97d}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"VDKB\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\""
//		"package\":[{\"fp\":\"1.b4ddbdce4f8d5c080328aa34c19cb533f2eedec580b5d97dc14f74935e4756b7\"}]},\"ping\":{\"ping_freshness\":\"{df8610e2-2cee-47a6-bc77-dd1ae7fb2665}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"1.0.6\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"VDKB\",\"cohort\":\"1:bm1:zx9@0.1,zvx@0.01\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.4302cf764844fc6ca4cd4de8cf5e13481c4dd15b4bd8d667869f9ae2fb54f9bd"
//		"\"}]},\"ping\":{\"ping_freshness\":\"{cfa7837d-326b-4628-8876-e19dabf2329f}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"9.27.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"VDKB\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ffd1d2d75a8183b0a1081bd03a7ce1d140fded7a9fb52cf3ae864cd4d408ceb4\"}]},\"ping\":{\"ping_freshness\":\"{c20b3bb4-d339-4160-85e7-0d09eb08e696}\",\"rd\":5269},\"updatecheck\":{},"
//		"\"version\":\"43\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"VDKB\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.418f6627139e37d2fe70c56c6c895b513c1428afc03e057e0616db650c689c74\"}]},\"ping\":{\"ping_freshness\":\"{6ba4e786-e77c-4cdc-9b17-7b8c3704aecb}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"282\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"VDKB\",\"cohort\":\"1:j5l:\",\""
//		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{73f7a7fb-b296-4f3d-bf66-728feb8eb772}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{8b776396-eed6-40cc-b065-027a17a2b351}\",\"rd\":5269},\"updatecheck\":{},"
//		"\"version\":\"4.10.2209.0\"},{\"accept_locale\":\"PTBR\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"VDKB\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.08c7fbd71f7945793f9ac8a85ddb8d9aa3f02ff4d9893af776014b144485cd8a\"}]},\"ping\":{\"ping_freshness\":\"{be258700-9111-4a94-8618-ee77402d72c6}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"20210517.374775859\"},{\"appid\":\""
//		"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"VDKB\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.48b7cd9a9a4134d608effe24870c91e3bfc6a097c1472878a0c6d8b61f87d0fe\"}]},\"ping\":{\"ping_freshness\":\"{965892ef-da2a-4c26-b4b3-408f11b71739}\",\"rd\":5269},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"90.262.200\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"VDKB\",\"cohort\":\"1:s7x:\",\""
//		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.da6e5438360451f080aa9a979fdf5e13097788f7f07530c48a9c2b9564cae34c\"}]},\"ping\":{\"ping_freshness\":\"{100fc3a1-ce10-47e6-ae59-a2bdbc507ffb}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"2644\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"VDKB\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
//		"1.0071ab39c36a9b977de5c26a994736cd0ef838e35533da235a9a022920646606\"}]},\"ping\":{\"ping_freshness\":\"{71a6c829-d43c-4dd3-b35c-eb081a1c4421}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"93.0.4533.0\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{477d57c8-1b96-4385-ba33-f733aaa4eb9c}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"VDKB"
//		"\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.308252f48758ca2d64b68306a87d022ab2be5aaa05afb9bbe554b3a95e409e8f\"}]},\"ping\":{\"ping_freshness\":\"{5e12e371-6c6d-4743-b842-b8e50fc18de7}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"20210524\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"VDKB\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages"
//		"\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{2adc4c5c-072a-473d-97de-ab71f5f65eb7}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"VDKB\",\"cohort\":\"1:ut9:102l@0.01\",\"cohorthint\":\"M80ToM99\",\"cohortname\":\"M80ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
//		"1.075a4a3eff2ad353b5bf9ef7cd3245c7fdca80542d0ebd1031d4a04d24d244d1\"}]},\"ping\":{\"ping_freshness\":\"{5c747fde-d0fe-4924-86cc-51db42c9ab58}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"2021.6.1.1141\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"VDKB\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.0623d6ea89bcc96acc278a0c594d6fdd3363e4830e185ee342e76d83dd8f18e6\"}]},\"ping\":{\"ping_freshness\":\""
//		"{146c511c-6ce7-4de6-bfa2-af456dad6d03}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"6651\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.2731bdeddb1470bf2f7ae9c585e7315be52a8ce98b8af698ece8e500426e378a\"}]},\"ping\":{\"ping_freshness\":\"{489c4d6a-5e44-40ec-b366-b63d74355007}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"1.0.0.8\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"VDKB\""
//		",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{0ab643ef-e5d7-49be-87ef-6622b1e1a279}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"1\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"VDKB\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":["
//		"{\"fp\":\"1.baeb7c645c7704139756b02bf2741430d94ea3835fb1de77fef1057d8c844655\"}]},\"ping\":{\"ping_freshness\":\"{f3f41ffd-9e99-40e4-9beb-497e9cdad5a9}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"2021.2.22.1142\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"VDKB\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{6965e8dd-7983-44a4-9449-83ed46edf5ee}\","
//		"\"rd\":5269},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"VDKB\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{a4013ceb-3b6a-40ba-b4ba-470568c6bb28}\",\"rd\":5269},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\""
//		"domainjoined\":true,\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\"{c2cfa91c-7e13-4970-8102-6c39eee4c5e4}\",\"sessionid\":\"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\""
//		"1.3.36.82\"},\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);
//
//	web_revert_auto_header("X-Goog-Update-Interactivity");
//
//	web_url("plugins_win.json", 
//		"URL=https://www.gstatic.com/chrome/config/plugins_3/plugins_win.json", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t96.inf", 
//		"Mode=HTML", 
//		LAST);

	web_add_cookie("NWASI=wyksazf4mhcuktoqwwxzq5mf; DOMAIN={domain}");

	web_add_cookie("SN_AcessoSiebel=N; DOMAIN={domain}");

	web_add_cookie("CD_Unidade_Negocio=000001; DOMAIN={domain}");

	web_add_cookie("NWSAT=0812E8E3E401843B73A00D5F4672175F1702B7ACED2E91C9EE806A54F573A2E5DA25E1D12413436A93429A7492595F39DFAACAD3E215A9B0F02EE4490B694396402AB7500D017C3EC25C6B42C29375FD03C6BDA1; DOMAIN={domain}");

	web_add_cookie("NWSTAU=baiBG3bA60mUbXI9s3zEYlCitj/o11XKqzK81jxRM1LuCbfytpgFJ6tndsTf2izOSO95X8o1VO/FUPXUFzsNG2TYE6PoQ8+X5/kpt6+9K53pBDtWgIS9V+36wnGlrBcGuIWBuYRh82/x8SJs5US5YUQ6/XQTd2QPMknTDcbnvUwW8Ag91jen2UbfjveIlZDQuYnh3Uv4turNLtUHcWNw9vfJanj32K/ihxcF3GNk9hstYRZx9e9/iJ5jF5E3+JOQhkuUjTFMSbgDoqxYXcJlQR6KPS8CRkQPzSZgA0LxBVOcd7Yii6YR7ZBbg52bPtUtXLuylcRhVxKVYWdO0txexmltXfJoY+cEOXhWw0fCj3WBmLW7zOqwvAYUdMu+Go69jmkuNQsBYtVORagJPba6pS3J607jyFI72JJpUIuwdC7yELWtIR/fGtsQO8ty/kiTV1R8R+vEOo4B8KXmA2fasA==; DOMAIN="
		"{domain}");

//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");

	web_add_cookie("trigger_state=Li1; DOMAIN={domain}");

//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");

	web_add_header("Origin", 
		"https://{domain}");

//	web_add_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_header("sec-ch-ua-mobile", 
//		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmCorCCCnsLogin.aspx_2", 
		"Action={host}/frmCorCCCnsLogin.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer={host}/frmCorCCCnsLogin.aspx", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=btnLogin", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value={pViewState}", ENDITEM,
//		"Name=__VIEWSTATE", "Value=kzLZq6tXG8fpDX1U9P+YI03QuAh6bV8+MiF2VUymC2U6E0rigaTQPpDVzhtGmlzcf8NsekuxsKisDVQ31202jU7V1zPal59E5tdiNv1WHFiumHD34OyxNmiu7ZOGFXyAGvxsQYvoE4vifsMhadriYtMtkpgHDgewg/PhG9+I5R8izXcSO3vKI9s9gI8lQNSebtHqrOIqQRHVWZvVmDcJ0eoyGHe6ny9OwUschusxYCh5sDQxxffNr1Kvhu9JRlSYt38GMxRGnX3tEwHoYAfCKEKcE8JIG6Wb56hNXHBjrjUIrIAN6WvDejUcKULsGp0TBeqjbiLlE3sgXaxw3hxIZXD+BKkspQXcuso4E5ohbGDMEuxvG97OxIcZR5aktwNTRcxgeg3NYuTpVB6PrUSrwOpFizRRWBjtL+"
//		"ym1SsT4kDWwLeGkF2Lp3V7gD9Y2idKAKUxRwcFJVzHu9iY8puoSKfTILR1TvwyOqLZ5kdEFKfyy6vz1DBRMgBryltAFek/8uNfOiZguisojWrFKK8ph2r7pR9ZZqFrUtM6jb2GzMvwHFUmLSoxRcUgV+JuzpXeQtdDfLMEDmlsfaIriMdIoOqU/VTQLf3uFaNfKxic+be+8fc2kzVag2LZW4jDj428h55HQJRwQpUPDpPbYLRbjPLPW0o17gJfFZktbPaQCpH33j7emHrAic0fq6XJOrxUuFDTJtOYJq5yLvu5mURLB7totfhutw9mKaDW4ClxyqjwvzqP4dnkIPirz6O7bd/oc/GbdWus630KCKyj0Os53Vw8gFhJtUfsFGMQhoB97SZQMD4sWVCM1/lKFr1PiyWIMQrGAefaMPNG9Qw421MbFSM1tf21TIhzn6GKU9LfRuN6QMYIygymWYnTiAa9rPGP0paq/"
//		"PqnIRhmpo7l17zduKxHf0uMgEHxOGFwQ19DY7kIGdhVmIdvcjMSftT+t6/JW/7PA8/CGsjsqh40h3cz5RF+Ew3Z3XElfzydCOD1JBy8uNjOMiPqpGsValYU1FQdTqtejRLzL/QO6qhGfUfW3PHD//N4YJVg5oFMt+j3p2linwG52CtU129y6iYD0bkkKoofbOkGLTY3AWmkOm54XBMKIow87gi6xk/rPqq2J+PEnKCO3lBryWMa0uoDcf10a5VWw4XO8+CHQAo0PY6fgwTk2lUBLhU9BeGncDqwBq8lqr+6fNfM2lq9Eyfk8YxEdxre9OuJ83aEf9arwfkLuciuPG0J1kYZ6JWHaviIYdcJtfAJDNg1ts7glZpvHESt5AuDnGo8EzyHgXHVNOQFAo71pdB6hoKiNjOldVKZV+kqqFfMkz1NhLWdRBydt7ONQsboa8/vQkXN8Ccpm7ZS5uIv+/dH3yGrJPeQQjWoDUvD9hUJsFVhh2dRs+"
//		"Kx0dZ6odvMrDlhK2vsQqGW9Tt2L7MI7rgMuYKDOhE06SJU4Xz6U90ZEXOPgxJFTJ+4ijKy9CjN85sySGoVUbaHMr/bIwuWcdy/VFL65WR5cF61yxH+Ioxt2hGFl56FnUgSPcmHkmxxxml/9Uk6YE/fp4k4/Nw0YcyWYU5TWvAHUS7uv5X2PiU2nt1mw5gu1wt3DdFN7z9w/zGTtjJaAbNebA+0Qq6/iue6XlLyYWtAJWt647OUGtqWZYuQmpDoDV6xmbOHVSu/l567dV6Mp/KYvfLfjKaKxjX9QA5g8rDcuwrB5ldrQylNDjLt4WFkUkyPze39imXOdnt6YxpsnEncNlpl8d+hco7t3r6Vj9UpHA329lAWN1g/sxwRtVnPsMYhOzOfrhh6wIyVVMhXxmZla/"
//		"qCiSXcQpZfLuWG9Ys0tNi62aUa0eyiIg0gYi9wVu8DNwrEUABC3SrCe4nBbscydbmNo7Di6sLLb9RHyYQBMxmqG1lE7muv5O/HuZPJA6KsAgYZk+gyH2ARp24YrEAAi8ZbSkMton7wwwLgAXoI1oHHeVPkhh0E8YzuEDZn95IjMxbmOCfg4YZg4Wv58C7ANaqO6JX58juroh5c0m86XICReyxR/DV/bkiPBepiGxxSKId6AN/SiLkULjaUXMa0MC1/feriLehwS2Lny2BTz7iRXyjbnWuonlRaEaWmT32WFWRLVTOLR6VQe/TOCp5rmusxoM6QiWQAdmxfcAL1t4eiWf4+JFnGj9AzpZTEREXd9fMbjQ99lPkKZqt3bPj28zxKb4arxvXNQ1dxtAw9LO+GUPQK+vZ/jEwJ06XFmn+y2Mi8giCsoGwXjkYAqbyNyH5yzZYOpujMP6AFvdwSjegfOlbEXaDrbl8o5s2V5FydFbP9uVcqlnn+"
//		"MgpOk4YUkF++5Vi6tYeyRfqlDMWrESz+OVj7q2nEbab1I7+Ykqds6gtXdpebcawoLPANlmbzehP4SQ4FtoJ+noR4orQJZ6A2hUFs+72GsXCsM1HmkYdh+0UMVaFi2H7T7kVBGgHLtNmKuVi+muh7vWTiziRmtely+zXAOL4av3rTguL0nQRIU9Ir2ay06xzfmTyoBkLukAByFJ7bHgOQ82HBVrCzEB8CSy7YZ3SwHDPYdtKBoUtqpKa2w40IXgYAtlO1ONQifz/IFjxBQ5ZlfBhT7y7FJ6StDYHf55fNFQtMkyP+R1k45Zvaj53mhp4DglNn88q63MHHBfjLkxbCco6oCxQmAPCDmOf/7K/U/FuGzlTyaY4w2kap9HZ1tUwDwbiS2NTNSD/rP+m2BkduRKBMxo3e+nxICFiD9oYRUp5mWLy9oxkoVWmwr7Ej6vz9lhBE+GmxsgV9jOnkAQMZI1tGo2dLj/MyRBKkbTs7mXO5Hbd90C+"
//		"NERkWm1FrP7/iLAf1gTdneGBydvIMMv7grklQQHVT+sF1NLDk1Izg8HVoivxIpd94USw1LJjhdk7gdbdnljk0ig7Fw5juTXEO4mumDdlRXLUctxsAnI9DEcodwil/XnSmo2IFvK4w4EqqhfOP90SExYHUmAREMI1p2Wrl6cKjyEOssXsLCCd1PhUgX/1AY03yWKVoEXjyJsRI+6f22vEVY1IjYHD/kc7EHEs/dLuKYqBiB63A4OWwB/4mDYsxqGH16hjS+zz5ph+Y+cBWlW0kApj9cdAQyp4EfaR86kIXp5WUsElsmavLUER6kaHpDWCKgFs+VY3L2upjNzTmz8vdIHomXtiPNkoQG4/6xSktwo0x8bTb0j9nyVXJLtZk8+r9btzNNoPCXFDzo8663F7s15ufE/yevlJYFbog6NdAM9GsqDUH7PtcGCBFJOEkaWy24PXBTzomiHzuT26yVIcdic7JBq6gQtwxXObfYHBTN4xfaqPHUNvR1"
//		"+Uk0oT3GVfCx0XGWK+gQBgN0bTnd/Hb3B1zLEaXM/MP5dweWhlTxg5uGUcm0uf2bPINTM23xd2G9SsZcPc1HD4VIbZ9/Llium3KWziRrasMyA7XELruFn3/2jH46gDDN58sI9HTiSZiw4QdWUU+H8LEPqGSgdKelRxYwge3w7ooAxKstHqJ/TKe7id7eaYDYEH8mJhBs6+6MgUvRzjjiqNYeL9imYiFxr6HknOaZgV5aMqeu+8k2hcIR2klm3S7m/rvq1a53W9T4LPlxi7xe+yBKgSFWRseyQaM8tVCJoo6mGpQO13IH6ZhgE/iNjaCbpubEceNI1n/m9QzKqWBVQSzo12QmWwjmCJb5dh2mxaenloADLaoOJyOKojn5y4mQYo2+OZHn5NPmjE4egNjFWFA9mQMldbp/DYGd4ny15Cm7pVCeXLIyeOzeB+XoGSljYdOgjDO8V57DhSw7o6qP+5rv729yYX3SZ3rmZpJ6qQ9Ds/"
//		"YKbGlXMHqN315Y2dgYSGST07aBoBKBP3z2GI4HQ8lxOK3Xz2xITkrfEIqQF8wGKaa4c28O+Z/Oc4zvjH5qebvrqk8oCFfq0ZMSKsdMKIeK+OoStMaiwyZePFZlYHJhtuVE6VEUOqsI6SdVa5/a6xdJCcgGK0zxeQNOSYOZ/q9DQOyWSgnlbGvkQ3Peu3VMsLdyPskcKtKInoHIbcAUlkcSefnLvVNdql3uSveFwHDKJFHETs4RfGyccD7hk+HTusQbctZhszKz6nN3u3nbM0aoll4uBdd7V7/ga6X/I4yqJdHrZRHxvcOqyFzCdfJ64iFNVYhhQTxdYZDdXpKDT9/RdGxHFcZ0Dz9eAUloyNMWi60c5abSU4UXIplCiO8H8LeF6gxfa9ZwG0rEAeaWaExBeoy+A3vjSSLaeuV9jCUUBhznrh0TAymnRD42lpQpy/0svbMABpQtRucvVTotjZSlgUWNuFwtBOUfE5SHR7vadQ4hwBgRHN+"
//		"3vjakzGuNEHKhwYAWRuq4ntEE9ArYgQPNCKDlOY9J1mnR2uA7UT5bbRNkvj83MtAAYzh2njDaS/E+fhu/8q1e/xHBzEe4m9avW9U3vjSyWdwxKEhRJOwWJ0Y8LUR5UK5TsZ3QVJDgHcy4dDv8Z9DoYM9jAkaLp/ZTaQX/wNwokwTHlfSJTBi2yl/Rl6GUznsG8LPAKt+1c4eUdRFWYRvr9WPuiEvVCtgSg8cDfIMj1IKhEid+OWz/Rv8nFuxz4HB8KJvDTp8C2QWBDL1T35uBhirzph7XuKNUkxI1jpBLcPXAdPq480GI4uaeBnkHY+aWATCWM/mS1l3MHRSQvFc9+k+AsFoUA6V3QEqHEHaKh5qz1KtTKf8cGAXaQtUCIlzuWeoXEC+UAGBbwNUs8vyhhhJYqY/tK4w2P/mYiBv68m2WqUlvdJHMPw6cOWVbUT0YeMYtP+"
//		"X1NZQ205eUPnPcGyubLUOATIwx6IxI5BHzdWoP2qtrr0PHdKTtVkVK0Pw8rIqMlUiKkybBdmGOxSePI9L4Tk6ORhkgpJYIY8peeepFQs/rYzWvwjWw308y6V4OBH9Pa2d071mFWmTd64LpbSbMi8wp/jj4/gmtmneslOMeHQF7jU6Ge6H7w+ZAnv6BNKJwa0pR/6MkiKpMQ2I/l79fv0V7PG0cfW8VYtNbRAxobX/mK4rXuKML2DpZNheB+kRFv+/p5zqj1UpETMPC579srFISB4Bte7jhEAnjZXtwDUSbA4fOXxE27s5KbcLK6g1NR6C1h5kDKyo2L/yiNq9Yd3mPJH80EllZaTrhaYOzjxcmsjM6+x942Cmi1uxplT5oaCToA/LgHy8mD9DAQqSIj4tolnByipvIXwu+EaICRT0UrxIU/5VlFEQyGu29kN/kGb7/KAVPO5q2sq+1812P49kcQDOM6tTsuvi9LH8y1/"
//		"JIDE72admM66PB0AoOjlO/nhVZ7NZDTkV4VrlbGdRUb2/GAG5qjgnC/+lz49ueI1Yu7l7q085CAaQ9ZAl0AXYI7LIzTCHOTXxesVn2Htxc5uJs8MB0LmKhW5ur8//iF2aIb8Iir7w1bQvsy7Frh5MN5Xh8bY2RGChqBOOPuSbdewyKg4K/SFfFq/9fgsKyXyCorEG7asCa6eNtq6xNSsckIsh0pQMxh+ilMw742AXUECW2qGwW6xk+yt1s5HgVMPOIaEZztambVwSHGgVjy5VAUZ9aj/6jxvjmBz2Qe60oRgyZtaf8IZ0oLu2ITNE5jQF1bTrFuRFrT7ei933nN1mtLou9+C/X0BoPsDROs0K48OFd5EmLwh4LSsUkksk6heYixV6U87Hwj+r6CtccQN63pN7LbrVblaIABbcOLW8be4FXqQAaRM/LhBoFht0b61oHwkKZJTPgsM+PMdKOUs/v/"
//		"wGTd1hlr2aP8Buh9fKinry54dN3g5ikuUtgaq79+a2NC3KVX8Hk/mzz/9ZtEBqo4zYOeK40EHa8vSUeQBmrGhfbOXZV/dqHRYC3ZLwZJnEkR6LO04T0Gj4hiqGMioZRm96iJBM661+fhjCW4jmEaFTF1qFVDLfnOhTzDKvWTlZaL62j0PLCtrB4pCx2+HLr6nzolr6AkP9MOpKziJnuS9t/mcg4dJ+d34fHfW90pItbFiwx+Bsli1IsVvpzKar1K7VTnDu1CG+ybrzFrQEBvByRfYqQsKZYmMbsxwuzWApNMSB32LhWNn681L7DC4EIoxnSOBPRUftsdUNSc8dnttZYpaoFekobLvNyOKdzWrRvaAcK+JmTejBA6AqcKm6Q4fThX4H19fEks6XinIjLiGOwy63sSKdaMchwpK0zm/5rhXAQ/4/tUX9Cr/0IMmDM0t0g8tJ1WbaMi44f4MUeeDT2raUn+71oxZtk+I6KhMVy/"
//		"D9S8s6FuPx2tNRFrJq2wrjcD2jKyLbapvoveMqPi86GmdRiiZw20BSZnjKETGPqM5hXiVZS1DTEpulRajqFVcflpT0aRaDQPEKeiWIr2kObG7ZvCwm4vqi4/6eF2e6AmzifdbWktCO1M4RWmVPBh0I9vhE9eDc+xHKf7uGLe0tk+9Nb55RrBkcGzaA4wgVJhSxcsL9ChOyBEUas6diHjvS74iCpXVGdMUN0NQQtYFODXAkIItXGrqWbp4bdLevZ0D0E/gyQPOkmMLjUO+ro3RPfW/t2sx7YPt3y4+F4pvvOFVGdfL2KXekIbktqVE2qiwbGu+nr4EKFDt/u3k6OO9+ArUAzrwVvFS2th7D4VPFkhPmFFx/GJaNuQ7ew+875bPdmcm5d4KFWDQ4BatraXW8ER1k9g1DMHTRMblm9Ll1wIwr4YMu2BSqdDLa0Af71N+kjU1j1c+iH/PD3Fz3VoXor7V/hX7+LSGpEcwIrGgWU4w+"
//		"p6pV0Jq4zpejrX67JSpZzl5C5/F0QQkkawrOIBcZDmLu5h9S7GbcTkDo0sycF+AYzi2qwOzcIOhaKZEToIqlJb8PrdSY5sDDuOE4X5X1xYr7TXXucTo9g5CrYTX3cEOHehIFAlwq1iiAwM+zMPFcbGWvWeoopPuEpEj2vrLc4ZQMQlLIi5yBDdZLFrIJLVjmqhsMrgLxBA6iNjkaWgL8DBcuqYW0PISTFS9afLPsFUv7zePaTTf3AB8+D0D7STIi7K5rd6T5sNJHCgLJmZI3/LXDSGF16dydUiRC8jhgt6mDwAkA5Op8zuhetxzgApD51NxrYrT8wjv2dfI2u22LnoV932++03/GQ/YYHEMGRkhYLM88tHSUx2nzH7dUtE+OYAZLlqdWtYvBD72IQfvFft7XmEUQtPpSKeMYTAHsVFOlxTDuOel/RJUH3pG1FDU0WfntF4xr7DspEBAIczlUS92J0GK4djia8Bd4qxfgkbbsPs6LA9cX8/"
//		"PQSWkCidYK5drHz27DNgPG6R8Tl783HHwriUiLPgWUP+r+L2htug9obRgwjNMk16zZGiVq/GjVu3AbpHmgMJKtQoIEJ6KsW/W+N+nUXm8M2yKqBfF//jO8fjeDiQD8QrlCTaQQ6yYkyWHALEDhAhpY378Ot10mHc4KXF951BycbOWPSRYjKya96RU+uLywhWGzRdJFGv4JTOTgz7432yRCr1ii09moICWNAMAHT3/924eRD1uqZtjJtM0tMVYjT7giZ5M61hDOTaYOs42sSrVUh2NJIN7SAZLyVE/rtYao36FY4gMXdCYw3WFF1PfkP4pCdsJb5fuN5Ga1KSfQlobL/7KOTJ/O2gFLP0zhUyMG0IMtz414zX599XhB5dptrVQk6qBXo+DRQIbvmVrv4vxU/ZQvwgGKCsWAJGNAVdFX+"
//		"acTEYPzOJ4WDeTQHD0MQeA95a7OUk5m6uTED2M6PVFleW9nuOGcwQrYoppQcCO3yfGmjH8PGNlsfEO7DNLILEXoSGhoG9dfIGgxQxarUNqxMnSj8JuxBV5n8HTShRhokfSX625i/Hs7lYXHJYf2dbpv4GkTUMUxLUiOjFnLNpMYwpbeKMOaIEIIsWblMzgohTHLJ2K071kDijiet/yRbUl67gHqSuyD34iYS3RjRPZJdQ9oAugz9lk+qX/JTMDe/KodpSzUgVc5pWC6aqdyATNHOUPhCbWJiGjvFWs+gXzbVrUBShxa5+xmLOaPbqd3Bze2in6Ym8qzPpO2nWGh6/bZOsZy8SUoYBVYzqgAq+dEOUh2YeYU037eRMeEZ+URt5KCAYk2MnF+"
//		"IK85Te1kzXnLpP4Uf3Vw7qtHSU22ysOm6HijXPRC0nUOFRkDnTIwttJe1EuQ2YDKpIX79kN7VkF8raxqXJ66BMKmqpKa3dtar57UGP9CescJWZYZQ4U1wFLQmH3/YUBsyLEnD8ND8SiidN7WWh2DDBt25AfX5TDcbeljZWayEWt+MUTo2zpZANnGaDlLt+1szvjosRnoHv43XPTuRq30UFW6cdYMn3V3bqV8hOWWQjCCoZTvlwEnRsCac84AMcSAAB3JQuSY5KnxsO9O5j1cMFh8g44yjSMxihbMC9t/JkIn6bgC3+r0dAMmbbxAObqjOoRSLXlgjCXF3bZllJjAeRdasDIWSTbH0MSD6dgK9qgxFDKT70uizhnHk/44opoTKswL71MFl54MUQiLh5cBnBNW01zweBOl+EaXxYAhtxa5w+MFoCBIVAVBqhqreJGpe8gyggm+ss3rBGr2V69LISEPWgd+"
//		"rbDqdGdvAi0hkufizYNeSlCkW5aJXUMuCwD8PmOQG3e69+pAAm7VqjCebBwMVMlt5F4FtcDOXWm42nNlrAujVzo1hqp2v2QaZiwVbG4A+zKmQAnW/weqMSuo+wYwnHQm+IgAjeDN3ztwyaTHTICYE8ujH6TmaOBRR73giPoEnvMEqysRd1qsaCXUP0n/c2NnHtDWlko7yZHhETbOYG8Eth2heHje+wMh+I/sp6kIxcS+6TW25anyIJkz9Ju217hMeHz1AAjLXM1trBLjeQRhh+RY2aTHErvMrCOTbwV8x8iaA9GSXAiTxuJpHyw/sWmON6Ijlaqu4Nj13MTei/r1DkmEk/"
//		"tIUJbpcJhq8FX6r8TFZArXrIg7KJYYEaMXvQOSSJ8SpZLBF1bcq1c427cp7DBkkU0hlOVaHgKEDY91K5qYJ6Q1J7UusjEA4NnaJwVqFg7mdwrqSvA5jUMA7nYwMKzNnZYocfTQ0xn92pccZAA31hOa7sqRlQtDggoEF+oekzAaDwCL+UG1N93SI16oZcxlLZiyEIPxkhn097wR+NDh/B9FxBLuwkpS5+7itwcic9TM3Jb6Y4gAHJgaM81rVgNH/zLoUaxjbbTIGgLXsvnCc3MKX9FCnx/tcuZSufwknctuqn9SsmxwULp3Q2GeDZPRnP8eF/Llc0J0WFzFrV1TDDZP82sMnlIAbvOF4jvwSwqwPE6fWXycLrqsAWXfMLIc91Fccsk/pb4eRL25kxQK2sOPewVz18B8lnlAqCVCxix03j89XrqrSyszvNURfHOwPaafREHMyXMqQ2AlwzgaoT4QPNoll7qoFpelvzz/"
//		"9pA8MGFw03poGgLgJBaGjHoMd9ToDUsvMToDom7UxuA1P6DZXTTqdzY3yZfP8P0lya63mzbM/J8WM7qrZ4rbjI0VRPGdIEv7wRJMibF3uXQV8XjTagl9mrPJNZsVCKy/gDdZKja8CIXHpACh8ZKxBq1MNsB7OgSDR2iv7K5RquAI6hOjDTH1eB9hUcZ6oPMFuch61vi/OC062zqm4Ns4X40kviC1UDgGl0+/T6sIYslkGgWO+vhc1Y9Rpd/ZQmNKJyalqjRHgj+OURMFaGM858VwZ6Y7Pnp0weTdGZRUHfkNfYU/7HUF1L+I074yLx1zXsBI6ToMfAE6mepj0PuNZUN3r0016G+xkQ+MD24ViOm5XXpqg8y3kWsGZMC3urnciw6wGeUVd1zwydcb5MXmfQ8kzQAn2sEhItktcpssbIy3JG2XKDH5S08TI+Zylhkc6QGCkxxAMZ/8VRLfIflIGSdIT+"
//		"fudBIbzR1MDVGuLfaQWXnGVq8UW6fwTfnlVfuxOLmPAo+LI0fuTCTX0T6IGzDadGE21VUoKrblmNV95wMksZSjrNxAcMs7wpuTzd0lsJg9MA4oOnaOnZdQIGpoocDghAFeG/LUa3ma8c4ZX628i1ImG0npzVaQnuoQ/Y3wW0dvSqX2C4hsf4mhtxKDq3jc8IqmywB7L/RBEMZvFc1Z3e0jdkIgNQU952JQVY01e9Q3ftTxzMnevMX0JoQH7YZDeQdoBKWnbajPtP+DGNdDsc0Bx0N2kxOaHBSmNk0Hew7ECRigt81yYL8Oi+w5JySKJjNkgA8J1ZkxrG5C4lzlj/nigExJrzg3KKPbHAvgoaL2l3OQvmNcN+DfYGvAKWEC8pYebZjpe1KCefGo5fwJtQaXJktMLpuzee/vU071GMSn31PvMWruywy7yaLoqhos4R+UBE/Ka2uTqfZLryQA7LHxNaf4/"
//		"rZZnO9etRDAtQCzTPKkPd6cdwrdkpo8Y3nHpPVCz/OMBkHqQsycPdeoLvbgBTr8BiHxwtmZj/xAjcAgiHRLZgwCfJVf748M0YynW3A0HTOXBmcxqUkLZMUXCYbxFIeeLd8yxta3djkOLSC0StYfs8lIFGE+OiRLG6eTYxw0bUpWK0PLcwJiFo27dK2zKq38BzeqqgBL+3Qot4zdcCtyNTG+9mNFmXcWgJQP6xlOnPjK26ZaeApkn28oPPUCBGy6QPjszXTF1uPtETrNQaqWSgmEBitTlclbMwqaOxM32uW3VZdF+n2hPVfSdZEt3mLfItNjj9bk8zS1IE9SFyqIfG+P3FSK/RUye81NUHR/Y3yTeolR3L32q9SPTMovAvEuMZB6kLQrROxLMaDoWqMMH2kMEyUOuo4A0GiKMuaqxKgteK0coFeXqZ7vrZ3Ej7ba7Ht4nyyQwqa2mRWRuBO0YFnIapzx6CBVNwRmIT4d6bNjbDz5q8i/"
//		"cnISMDl+henWRwfcB16qF/2qhPrCjFGWoWXke/0B8S7T8BlwmvW1RCTUkd9k8DqGuswM1hJIl8X+99lV3h//Y05Qy97qY7EU38XOCWXMHNpOLXznF9/q8EwHyzX3RBrPHz5SS/g9JDgWfil3bJJk5fQlEaTbqxCJI7qHoC9AYuZ+L/BX12ktvBf8tnNbwFmnNEFyxD2AsRAWYFaIW6onCOVWcKO0Ns4WwS+FY3PKCvFIsu8Y4SNYRERQdG++4ACM9nDFLiQyZm+vQab3ZMbTlhdKhf2EEVD6nsPlltV1YvKg7mI7g/jxHJXvWDvYjfBK8AWlbM1vI9RwfXHyBrspHh6ElVLVqHduWCU+GbUyBMwLz4DgCV2ia0XjdLDCnA0a4eVMG9OEbaKmf/krhQE1LdaINyv686zYLDj4WYDHxDz/BrMB7tJ6xbBLifzPb6rRDKHik04P3IwlaFF/KtRx+"
//		"45L4AAse2o7q0V3OLQdkTgs9H3D89vHWIdVZjaWfd7LWjuzDLi6SCw/OmnZPTr0cUeE20Z4ihKFjPPtkVAkh2qeofUKlA22Q1JokH4mQg8NhykNvB6WdjfnjRS5ATMw0n8lLybJDS1xpQRHKlsZxyWX7HbHrFcikFVtlVrsxjRcLHY4HVbBczXknKy6Xq5eyqyquOmVpECpw9HdZYlt/1QBbKZmPplWo396LCVvVRPEBTw7B3QwG0PSEFGSTbw3MO7xttzvyi5ZEVgsf2+eOkUjp56dNoWHss7FM3B9o2RDsxtW3qTgboeXpZFrXxt39J5UPEnVmiGRW5dAGy45Up7Vo6lA+2KiZ9sm269CEu0lK9rnA1AGSrDvEoiF4MA/9h/Do9d8vzqCSsDN5krYyG0Q9vjBG6XPOoalaGoUgrY+YFeU8rrvfHwZv+ufA2odJ40aRzQ+"
//		"ItQxJ01hhOEDHQYyeGDsO2mBGIz7gYwqqmfiqhCy9l9vHn96rP4vaHhwKugr6axpa9YQJ6I7FzBMh4K1cwnvJcxbcZ91CqaYBfLdxpw/bYrlrbnVrYCfLd++Ea6SyqvvLm0WsKuclH3z2DhO8pLSgtQDF56q281oqB1iL7hyHLU307y081N+iz4El+lO2H3AawaFZaxS1ryzRkIERjK/E6n12IRlPduvoMGVQha5PbR7W7Bro1JyMMoCv3mzKOWeJ+yNj6GhiTRmAABpyT48UcXpWCY1cSzoMuxJPKxAQ+"
//		"3iDmFkbFHUiWcc2tVyQSX2wcHbbPWkTS0EGlk0sbjHuAeMT2qroE4BVjdaNnGq1lxqHHNqNAImj9JMoaMvBHQfDwCHjpDLYiUJsHBVvxAq9XWQlONptXEUoUKvF7QBq3KtM5Z8Sy4Nzwqv3BJianWxYtGs5QzntExyaSTPrSuulfCffERzjo5xjiZ7UqEkPy8co908Z9z6lJyQno+zl6vUYBL8sLDygd8kslKJD0PH1Cgh31Z1LRBkcgFsBRIqP2aiN3sijLZcdtwojExlol7bj5+EQbls32ITC4CYgleVKRF686bToycTIeydKf4knaWzm5l1Qf6Jc+SNGGP303UPga401D4kPZG7qj6ouXz+hQOKtGJ2+O9apIxZW5+hTvvg3MZXt3pF1ZBiV+5iZNMg1Jz91DrHvfl/FV7JPN0DlLZZEkqhr/IFWy/"
//		"Sm6S37r2aWlnPwz1DR0B9q4LNXG48bQOgKZXMlNd8NR5HXjJmCGdW015Qqnquj0KXVuVWqtplj0mhND0qqET7q7vz54ZwUv7wLhRUDD4hPj0ie3iIJL571fIPmHCv6egrIlMBuRqUSInPi2uDoOcezrbMm/+C3Ew+4Vaz0TSxMyGEIv5ue/YyPYYufj2KFY9WAp7Top0YzaN7VyImUULnEJT8ztmrp3NOIJwRE0d5lNLp0WAv4+4Bwllj+IdDcgwHVZmN9hCG681jKIveMzSt+yprZmyD7DQ7KGhtXbAfhFyrhu/Ccy+EjrNDR9WU6PBjNIv2atOTgCUalun6a8pg380kHpn+6wRhS4C5JyjqiPm19L5RiPrgF/MdD2xzcW9myU0y9jCOBY/yaw1UOLGO+o6hXxP/cPXqzALEBR7tkaUiIkGVc86depzpjUW3KmiLHAJ6l7pRc4pqIL1wFEVCcaquF+"
//		"GQOC0SAFTmBn26x7HaH3cppf0bT42b3O9aTMwoJu5tm/CNSwv3wqICNdHEuocxux+1U1J1FBgV3PUCrzYKTi86IwZAA5dIBXwP61HWB4NrSIZsM2mFFMwAUACcKk0tbdKSvwNBbccfjXP98Rw8ZJEQaYC+0r5lQFHmfjXRBiBJeQVwjOd87nYoXapBE9N4HeJTDkveLqs2vrP7adIL1JyPIY9kpdpRmhczEnokBFpDfDGENkD/NTlb33NcaG90fPB6P7FRvq/Mg0S5yJyx3BEJo3dkww+L5XLcNkR2DyrLT0TTGfRclJ+NwvjNSNAHPxhuHaKURahL2yRrBdtHOfIwK1v2AblyNhe5SftJmjKo5zkVN/QKQchTQIy+F7UogNR8+YXA0mGTHFuD+Isfi02dYqHRP8Lsfamfg3jH9NQrbWxJYxIRhgMmfou/bUXSsnflZhZ7PVDJjsITNXw2ap4ypXgGkf9+gw+6+o+"
//		"Ht3opp3r34Q4vbKDRde6valg0MPuqi0GKxi5sromrm7KCD6723CWXlRYeLb2EenHAza6Ks/Qwh7Q3ns4g+319hDX/UJNlv69b8S+P06x3wLzC+17JkZSqu5ZicBlCXndVMZUlybU6bf2WuLZZEDafw8bIt4YblLpP5s49J/mlLzoLrSq+BGlnGY1lFOrsqdAunPHwd2kSBk1RvPFLrXeGOvZC4p9NUeYPxFZboTcSNrNiza2aFDnzdfzV9Kn5qd4hE0EZOT1wF4OwVjZREUDDADFnldDXiejRzsWliFnh9iVAvYDA0yeZFROSRKbMc72zSTlyqccg4oG+Kc9bBL04YoavUTQAU2L0+vQWaeHirPEUK3/TI36rbwTbP7MJGtaoU9WcnJLbCYYNlUzRxmempdiQ/4yO8GhogsHpP4NZ/OHX7G/fWKXGVKBwfIN15a/yFuTLQ3evTsWrcNImNFWSQQrECyfsv72FrmxUIR/"
//		"nulLCsFkmxPjFcZ+JczKmOV9eOUuP8OlOZ4RTDzrofS8yxuWdOt4YL1awzUF4YKpjW4W4cWjsj/By4yV8IzQe5el9JxmkwpTvhx/bklEjs4z29H4Nevnx3uCPor2TF29vO+6FmkHblruC4/h3ThUfH2Olts4UtcYVh9O4jGjAk+d+YxeqdLOsqWYgUvHvLbFVYY4Vn3CxHR3KJ7XQbRW5DKq8AOlcDfCoYAosEEjveCOL6YNEp9RwDmCdx4AsKwWe6bwTtob5J4m1jhAZa2CornPBQ7q/DMdMwOCH30iZnmlqxxgOsFp81Q+1nTIgdgk28jSk+y76mcqBKKOsrUi9WXyGdR4Uj0r8dRkSjem0gXWnYlrEnf21YFvsP3Io4y7tN8I+e2toSQWGndF25vzmTwnWGTg885Ptl9LyY43b/DuGR03X9xUXbai+XOxD9B8WFRGXddkgpu9R3W9IRy/"
//		"Zdz9n5WVpWZidW9wdoU3JQr1IGgGiWLSZyYlKm7As2luTaoHXIb5kzTOGbFxvi7KK/oi3CCgpnSNKapUAWu7yxQI3ZVETYr2b4vFzsX1EZLHAj3dfWcaEhUUcixxCq2LonMyLYuOjzht0AG01+tN2I5hb/POKI2G4podA2ZRm+pGX8ieFDjYee3lh3XhNMclU+KYRLBvGV/29Q8Irqpl1xR4YjIzCilKmQ1Xd49z6EHtQRdZqoOjC11ZeMaZGM0frNHbeN6Jnt4r6CwkFEqmbfZo/b+qHEIGFziHIUpTTLMLHWutVoaq4xY42bw99XWa0kBOvfbrYXYYe1uIc/oJEdaoqS1qa05bUsF1HaGYXcAY3HA3ClUTjhIMM8FGYmHzRulQgs9nv6tM6EWfmPJzRVd6oeX9CTnvhkrsogsRhKhNF+cwooQHP03vfsV8gQJ4u/"
//		"dgs6hlPrN3Q05qMh1sN2TKdrk8NYEvHXZ9ii9VfxwixskcW4TxTnoMc1F2EKMwR0hJqtHuriP8k+iKg6pe9Y9KVw5yDpnv/a3Dr9IPuW5Lwz7vRf07YU0QKfV5OiixjlGV5yr250bCkv+rWosfAmfdzrFXbhHMZ+pHUCbVhTtEQX34VG7s4aOeQPWQLw8vnGSMCRw6Xk1pFd1LGCLJmkjZLjiMZgWK8f+2gh1DZHCWr//7cz07BWdgCKl9GHSdBBpL49oClHPbaTx5HyW4GxoVNsA/nCeTj/+Wf6JQ9ampvtaxI0s+6/oCMhM04JIhC5Vet7/uzH2irA2l0RdA+Ygb+xgJxJeYX86tCAxqEkRvjCHQkoZupjnViWKcvl+2dptVF14RSFMAE0UR/aNiHDsl/nJiemxO0hR84QoAdkKAlcbCFszYgrnAyBZ+w6TsbMUS5jXxaUS80BMZhei5/gQWY3ksnT6EQUzugC8sXeC+nAVJ/"
//		"vSvg3V05kSsLpOXT8wTViln/KS7nHR2XIG4j9yFkJhNve1oz3CqWlXLV2QqBEr693oJ4FWJ+bepSPkC30WycPcUq8rdasFCZBOkNsj2wTfsWC018Lc4+dovkctMj4obAZDt9COG0LAMKuSaaP6HlDuEehmPRT/0N9AJx3WoSpY+tr/l5XJ7aGht4o6SsUsNne+MfX8/cLGJM4GTLCIgzdq8YTsQTfJtt2tbfZMh5uszDbftF5+4SETq4sPossITu7+DF61CJcDQ3pt5iL7vcBv8tPV2ocjlNnlpGAf7SASg3yXr6OKLkeSQNPxuaKKbYFgtLkWY1L3Au1Fp5RpSeHhM40AqI/Eyex5uP6m8hVARa666P1UK++yJZLgt8K4R0MEQb8awoUyc1xlqHxTgDPOSKnddZyCgMa4rSrqOh1JfEqIhbDSnh16vOaASZt3asWRqXC/AEkp5a5j5+XNjsA8USL7JOqwhJCc2zFmuqFW/eRh+"
//		"nJXHYPjYVvmWbypMADZv0x91h6AXebXFwS5H0dbFzs213D9iArBwvsxnbcpYulQS8rn39ZJ0FgafTdCizALzv4Llw6KFT84tFB2JqBHO1ro9uBBxj3+j/Yh/SLBHsS3Lmx4xN+QMKrpJDTpfnUDkIjN7JXwrHk4+g2uJNrVTjwTBWIDqbEFK7rvYb/1evamB9BGjx0Jb2vhL3d++TD2AmnEyMb0J9UF7jI3XTBQwy7t5pexcXq2ETu1C6gzvqCgg7y0eUXzU7eNr7/GrUXdSYJYUg2JlWvSZGsi0WYl81NTZ0ArAVFy0755H9Ic/jm/tI+1EKh1+fQQ0SohWxOaA/7WoWDYfMvldbqu3gSa5brhkFVSvQWJYhzmJEe1NXMiolKVjmGfhRmiotGqFM0yQZs55u8pYBb1mZOIx5MdnXIXh3AYV7gFNpDGnqMAkYmfhJywGGzuBbO3wP/FcmJcFZP8xHbFKgooqTqrwoxL+1gHhAY+Feh+"
//		"YTuOppUoGMQT2AulhwvOae4TT6aHridd6Kz24gutzPJaU91rNBXOUPqEMwJfkMHIAU709+LGeMKF/LTkJ3RiiAhId89N/maGuXnx2xOm0q0GByApn9XujwvT3aMRoqZUfNjGUrL6EdfTDIknMeb4jBAsenHsU4L615OJkU4FvXdq+ZkMCwR50sGgNEaGNvJr9H6S00pf3BJGyhJPeCFZmWTArsWwawRPUQtczV3uuH+wImCGGiSp4fhxskClUT9DUs1t9vWn0T98f7ZBVIneG6pNzPV4uDpyveReHt7B1lrpWCFXkG0JndicBscpaj79PXzk9qYbrpd0Bmj2vIpGkEE7nprjnq2IRMnXjOBp+tfVaC2nbA5ZPs3ENu7b7SyvOY1QWGll9Wb4n9JTu2zN4TeWdPk4sx/iMu0/j/FUy73J4BwF1DH4+762t8WrTKsMbvWykNiCQPV7Ws8QGGP3tiYsSQhXJy/96qkR05I/"
//		"tMwQapIAHJHfcWEssV70jMJgaJU9sO3YBxr6C1UQuLnkYPEuqlbkPIxZpdkRkEu4ujW/DrmLmRmKiCLJ0kudcm7d35T/knV9Gjs9RLDP7vWKu5iaJxW7MHHnxGVdJVDWIkNqAzJsDTLES5/jg1CRDahmoR6I9lWy3y+d6hRwzdf6FeWnLvTYun1tJP7vjVEEvqtu+7AIiTyyDxFUuaWTiZQLbr/MXclL+JFktVgN1S8mr6dc+/DTUgKmO+u3xF6rUL5zM6+EUO2Uxj++oTjTccOxOdtuGI5uKW/7Q9yM0HKxG27TwVwHvCOFSGabATNm5kYD2kr4DIm2SdzNEywi8WnnicG9/lr1067PaKYEMb0uGrXP0t05OeDYBdMIE8MDxjO2oZWfVwGTXksbMjvoWPpGP2OrRztV5UVl1dgl9tqwv8WIOH/+HOCm9lbRn9kg41JQygERo87m9zGKNg43PWrm1yUJzU6JsXcrQL67tI+"
//		"YbNYp6JflDVol62q6nUNMnJ8AFY1d3aOkFtvgJQy2STIXLxl7KBX16FuaajvI2VK2/nz+UnVwnUXWqzv2ET4ID3w4RVwUJHV7/EpVnCACJakkEBfD8tdGYTh+dvgTJ5hEiI505wyx2g7yAl7vh4z94rXMyeAF3rFp2dagoSzyorZpcJLNJKa5KNco1iexGiiWrWH2WN9SISSF3mul5PyW0CGFhoHjPJN2RFyG8bvCCD14cAsPPzKRrQfCcjWE/7tkplGMXfuQbEnXH4NsoWmd0V2wRVmYUszl4f49DTGtrVevEO0gokHVqnHM6Hf1HSB6WAZxdUWd13mZskjYhtmWnl/qC7WZbSBXyx5/JF+8wu6fg/mVmXl3lesS2Ahn9rKXtllVFrO4N9lE3qG8348JxGCGzHW6w+NmO9OV2iXgGSgwhgf2EhdWdpzbMMt5Wz+"
//		"H7636VjBYAo0xbQWBSWUQ7Wx4QvaWWJctEkOWn0pI3UkqRpv876aupmn8dQk5gQy/hSVC3SoKBEmNoik9RwdkgdHpa6Qz2CBZCYRTM1sNgxiiZUsXeUEBn4Dl6RVDvtg/DCyIOlHTgVANW3Kff7aD8nfrT7B49RoJy/DlhwXHCa6sMF9daJ4kphgHoeqNHUbT1CyuNVSQhbICDy7fmtACtlmHys0/+AM1eNINOIiSxNJPnfloP4DbRrd5/XuBpoU+9Ze9XEkQEDeLiYLgZR6ArmC9y+dXx9o5c4TORaoTrksh3xKh3IIX0UN/eJleCoU8YosrL3PxxDImjhV39a6xkZah+HRoMzyo2J1XT1IWT52YD5sdzOx/FyMbnQZYUgj6sbUOXAY2JlrQvsbA0vASB6yxlynxwA5bUsXCWYnJhDM+rznr04ii7As9Z3767V7L1XwrbjVaPZ7s7hkT/8/"
//		"LNfTwhJAebhBVWNBD6luKdi4XDIXl0kZ4arhfIj7KBxePmWaBosjmihJyMxxrldFRVjUV2Ka855cpKf7kq/YuOQ6y8sd058nxsL5jCK0tyToeDlOdGQ3zJFnySFI2eVaTGxQNScSZebLxK7nV7aFFvBJVBYQX/i5KKEMiNJJH4zeOqxExJ1t6tzGstO1blOThgtyYx4wup1F3V5+dP17cwcklaqo4IHP9O5Fvn9ieKqdlRlZiF57bHBRbXXZm6TRIOvn1MTho4KnJwsPLcAtsrf/7GC765gqiL3s9i0PDZxSIdDPbABKwfS2UQecnf57xwVoW3jpqNVopDb3v/2g1O6dkk4BgdK+k5tMTNckyb1Dm/vzgvAds/8qa0ldc3tdD3YOgi1dD+IX5Ft8KXTa+nmYt7/HaKu6j7VcsEAREOY/OYYaV2PLOBPvJWC4jzQ7abs29g4pOBExprXqNbLkNUlIMNB1RuXbdQ/"
//		"G8m8GO8SDExrUqbzR3VI2RN6IARdmVECU+sPWEJUDj3+sUgafBfoUtcPLrIQ6G5wD3WkhPkXVUyBoRlsmVecOT5oAEbDLlbool+3/GBRiGq5iS32LxjgTtXEO7eeNIzqfI22mKgSI0eYPY6q0CYrc5aL6l4WhC1QJHVE67oX7iGTwIc4f+ZQ9AeF8Mzi0UBaNVtuNXeZ+tKhr5+NLXngedCLqo/Lqlnm8TCGKA0TPzu3HiBLwGKoKtKrIyTr+co+NRxeWstcb6XcyVsmrYBmt+JXAKEebQuEbHs3lpIHHK6bFGLUKtogD/wW89RV3EvagYMdxew4cPpD+TS6tUQK1px+x52T+Cks44r+AcSINPgafRnK2vD0mgdc/6escEXls6IrMsw7Gkxy00RIA6FnYcqxPMXk8x5/yNdOFyzRodsaWB16qzZEvbxHmKPN4xvTxRKqTZSI3RkZvr5Nnspb2MqfhCgQ8DmLRgn+"
//		"0DWBAzTXPXpEQnvDWKjnT6PcBZvSmWWBcTUnVvXacgPEvQl3FHjFfiu3i83RBYdzfWFmfHy0X+psCCMXssVSlH8B67EuixfBW+koVQ4bsndtbcKZWS1pZ8MhQrA5+Zfox3+CzknLrL3dmpgmm69N1zrUEUjsSVgTdY8x13YyLQud+28AIe1lsiTzHQPZZegG2+YBkPGiYoMrPR2v8QJI6hn7Ous4YHNDvB6BAc//u9ttcCvBYNu0uAH49+8hVyDTnbmgPep/mSkjlynqr8D7lXr53pnJvSHFZZBE4GWDYrNo7+GFIrXkA0dxysREt/pS4/V3C2SJjOjFhBWcoM+c6DJgMHRBoHWxsfi9wNtgfEo0dm1WDkLp1iL08KinICRLg32eDtkQIpDT1ChYPVO0aCh2nx1TSCCprdzhf7arT1cS/X9hNK+TJJY3Yz1w/R4U2puR/SXCy+I69SE4/TDBemdVoOJNnwuusDR5F/HnVf/duppwC1LA+/"
//		"lIO53rlCeOLs4tG8L3vUsCNzptqwPvW4IKXtInpObImFqXXrZS3SsyrqsvaRM+irtFQAdgoMzVTAqN7oO19KqBI7uPghh4N1X8ZSK1yIRpKyt7BiwB9CcPWcjyCa4hKhU3tOuuoRcBHo+ELK5tf2/0wR2LIlVBFcmrjtj9+3L9kbooE+Tpl2zKDb35NJcyigV0eucWSpNEntXb1Ht/KTQbkGqggHmScgIdwnoKNtjAVjbf20DSV3kqwJb1kue7dUgky8M4rtgsTfw0CRSPqtUCS92y8fcL2RCwmE0dcc/V0hQIKBXLe3WKHCRKGCTdIXbvNHzo1KigMhelHFe85C6HLRmNTqhrjVQhk0ivPD+pDyyqENzuhBgWWgwuKMTIPwaZZr2qA+Djueb1+Zc2dsZN6Wu7iEkxQcpG413Hh6Oeia6rd77sjEjI9HAEo5e5VhlyfrOVAALUHx4pzevDW+M5YzJj5stscqVRLN7Ip+m1mp5Ya2nLEOC+"
//		"7Opqzb5n0g5QznwYnAIXGQBGGoBRTz4ZIxLOP2qoW2iFWUrLV15CmiZESpo79cD1zGiFlP6Joo0pGAkKRjfWm5P76SQD1jUWqtynxc/uCuqAAQ2liQK5B9YxrFqQ8lSHusS6n1wtBVqma+Ni0QxQmDxPrVxA0SWB/0U2FNBaWwxlRWi0QAFREeIuaE2bWCdf5x4WwO7v1a8lt/9iPU4nuyPAVfyUX4PYhlrYRfAQxv43AJ4O9I5Tc39QNB9GZUsO3D0wIVyQIqvUB5Qdq0+MRZWAos3iLGvyTs3wWBn960fq+CS2sJMqGcj8pD/e/EzW9OXB1tYlBvBXLAVyF4FmDZsD6ko5WOKpwqpcKoMxyr1Hr4tPffJBVLzvT7nexlJRlMhPxssVYmlraNZfy67mWIKJ8BT3qDCekXnEZG79HEe3XDfWL3Bpy3r5R2zPHfBdSXPsQ9s/"
//		"oKY4TvdTYr65MHr8vTzh6TYb0B36sEdc3sbcOI3qmCk5uXHzYEhVnOgeewa4fsoDkSw395YQ4krfomfPW+VZiAwyR5W3UkeUrQt/ZBeNhwMbeRa8wGYWDUR4A4Apnlt1k/0p+rpuVHKEncT1Mzz1I5zirzPxzQyGEGTutGu5TTZZ9o5Yyr2r6K4xvcSTyEQvaYdXS874U9Rg977lrRx17i24g5CBjsWv2aC1hVrSQ8camdNDQVsFO7rL6yUtWUbKRm15BoZT9rXX98ibEFzf+yl32DVX16UHB0NBkd4M7yXJYIRFTmCYjlhFkeJg2qqWnaoMCwL9TGfdL6LUIWbDTzEOoQTHoZDIacQjFAT74xQfV4u2XxwEL09QbfE7FJ3f52zsCdLGG3jHYMsLJQ0Jw7KGVKHFUtiS8lJAf0GiW7q1KtXmlB9dIADmbdZk5xjzCu6Tw0pwTIR97plxdMBkpodCDqrkwJTiq5jY3+dk3K7AHf36fIP/"
//		"C6Udaw4PF1W7WEvv29aezGJICpX14A8OdtLnTIQn83DCQQ1MQZSASVMzTcbsr3mHmyOJzbQ51VSgg6eOHSPmpCu9qtocPkpVLO4m8rZ0LjrlyDtAgCnJs1YUyzxOVed3n1yr7mXenW3j2UjEhS0RTzz6Falz5pd1FnX2ihYDOvCVIbH7saycrgIpjlT3gMMkItKNo2QuYdjN8VC5WlJEohHzfBPuqvmO2J0aMCosFEZTOXLgZxNLItn5PDMwQEY8T7LHaNL43EyOAqQwVVtJGkjRohq3dgVh9PmKsYHiDDyuETme8Rl1xpTa9ycGi8htm5IFJ7a5HSErjFD0JTbQm9IrTUYYRu4wwBD/uPoJfcGRCVl1ZpwxPg5DXchxSxmQWAWQukJWXyKEYexFlqN5qe0LTv/bouEvc/Qh+w4dIg6uoLbx7lcyP01vvKIbiIH0mdRToaPCmVkBdasEfkAD7yAaYEqAPflgNxumO+zw1QV/"
//		"HmKI9BKH3fmajfGp9ldUX6zf2Ob3MXwB9Bjveey86UrqzwkDib3DmAevZWkYQIfXJ0Hnp9jrQtnmlYtpJNlFmsYrcz9XHK+EwVRxquuIzVna0EEVIIiigGK4TvwU9C9T1suvdtczgJbwVKYzrJVCeK3cbl3Nrs/I7n9jgdw1gcTkHrNwd2k2Wm58f8S3l2iT0X9XriIJ5uFSdaxZM1afxtTxVerxDg5IAbvmhhxrJzWUFp/4IITg0M9N/61sGgHVIvZvcgxSYO8pZ7Oxy1MUqb5yr+YTR1kcqjufxC90Iu2cINGmfxYrGelZibVqR64v8UsG1+n6WlZOLjX2vT1KOobKhYsCWgFBWlivuiN680ePt8DmrApXF4XI9XmT2MWW1ZlSzVZ9xrPBxPvFUgLiQb+tPzF7tsKYWPgjDaDYMTjKxnRFemS4T3DacTW217Zz6QFjwZr+V1rd2IXStQ9VZnAGE7/nVbB4RUiq7G6bgv7Ge+"
//		"7evT9RIAIy80hABiJT0otx0JHht8lzJTioClidtZtcxlbIJiRckIEC40LWfdP7O6jNDqrxdn6R8T29V/JjmxiCHZr/rOnRZGmLHgH5ggfq6AE9aMYdCQsq7V8hA3w9XoTbjX1Nn8CTOC0YeRyN0JVvILekVAusjVPU6VHadiiQn0FyvYMWcp63ZzmhCxgJ65h1RQGZqrYMkriYyZVlGH6neEEeW05ZiyhU5pIdz+ZA3yiK8S/aq4hw3YWCskiBZ1Bbyiqk4KRjw8gt6jxna0cVlL4ZJaMQIVGnPqJhbFeH3Q0ev2Rtj3S44k011LobwiQHs2+Zezg5oyUa8wJlaX78ZOzUM+Sf6Ume7LkbZK4ehR59JKhYZzXJYg/2fk8OLsdENzTvtZRAFPc9lPcyLM6HkHBZwtrsSGafOWTREKWKxAGZh5A68KTAHI2Nb2kYKHWpFopEjrjO5UxQr9r/eH+ku/hddKEceO6gc1ZNUhHWw2H+"
//		"NSExtxE3e6CXQ7GBwxIiMxiHGwckRFp+9oKI0sBJmmwYCgL2bD1m6s9h9VILVLuoVBGlOrwlrk1pCjkihIMMWItbP++tPK4mKdV37UAvuIRyd0KNGtRV8ZRwOj8N7FvB8heD08jI7TgLid4JqqIghjNLjYW+JjPb7iNs/esTnkzPD29tYtrxsPvdOnrJYHRZXU6ujpuO6Q4P2aRhcLhtwpk39kovsll0prq1VALsdSER599qLnFlt2xi+3V6NMxrXShbyhhpB6hSOXMzdLOCKZIILyLOUpuzBxA98VI+ea8DmEbFVgHNrqfH7Iow56lS93oztvWUTeKrHLqdRmY/25cdO3p2Kq+DsTRnPPy1RsUR5V5ULbuu+0QyBAZCPL/lzCX2KbbT/c0KdO9bEzEiHcLj39Ghg4VLV1cTYozIfSKrpDlrcU/"
//		"AIdwJjF0exCc8ENecbsAUU3cm9eWtBj7FMInRO8MuEBOJZ1WWTb6lDBhzWJKPT2GN9sRMyo3a7wGdrBkoX0RSUoipBhuEAcMs9QPyodnBKrTyXy8U3hvnf8pcS4eJ1ssmu6kqPBYhJJWWQWoyvA+t8Z/J9GNa6ZXMQ2ApBLJKfuPcP5onhbg0a9V5iC0JMfUuTvYoTSLnEeVoJO1sSeThkwyp0+4AAVTlaAOAY63pq2HrENEiC4aQoG9VELfZriorcFsuJ2LtsSng+LTSDcgon38C+0XTID5gsnbN1aP72xMN06KvANekgL23TQJ4tem2xs5SmTywBLL7eGfTCxcizholRiWQlIEUQi6/tG1kXiNh40DHZSQ6h8li349dFdlRFsxUxqf6YP0+UawHmLtJx6dJHW1HmASofmlul3bMu2AO2zf2tdD28N0PqYuY+4HPUeoaApmcOsrmFJDjYAtgrIQxthe+"
//		"4jX2or25CKGMONBRIJUGSAV4xC2wN9tuAHaTHMZyhPY60hre9wdc2Rwxv92GJSfJabbkxBlsi7ISdHTzmxypVM29G14lVrSrPtFkA+dg/LNYwXjrYYAWTc40+vOILd5tdvFT62ZzXzofeaQq0C5NHWXUmg5wOhCO+I0hee9Q082lWtpjPJFkhkj4E6p2RzTxT2eSMJ0qlj6ABCr27UB3gnKthK6EqzHO1sFyzjeLe6Qt7stHxiz3expeQgNYpAxwUl8ok0v9qh32ageTP9zxwRbPDuNbluLjik9wV3U+Ys5iantjNpfIDlXOw65GusHJX9e9NxjYUtnp1JV/Hvh7/w9zTUgB3iRKISP4kJG/3ITrVFe97Jp2qIaIaa9JKF7u9PIWNRxfJlojtS/O1HpkqsCc5kIknXu0vGO/n0+IZS5BfgKI10YOfye0ovih3EmUBxvkiTox7Z0zgk456juvIYI/"
//		"EwAUceI527Vy54OnEm45oF71EisVgDtcVx4OdkO0/n6fo0kU1edGr9IqHcW/MPhuFwmGyb+gdHMUvIB0kDMNeWum9tSzzGDzITfscZXB40PB1augYgK0rDLWA6QEpu+scwOmgl5WYY3+KV54T1+bdaW/uBAbQCIFWux3B2/Nbf/sPI6kIG/xbVxZZGtQ+zq40dzTmaUGNaTK4KJNVeFKMMa0F4H7Buo1hZEz0O0VfN4EQXImyitEH5zAS4v7ZAfq0ZilGzy10CWJdyuJl2/WOJvfc0VBgc1tPrG1M9t2i9GfZz631rnrGZc9lAB0Qv7v1ds0ZaYI/Wumh5aaAmN03k/7aCpFoiG1Pw5WIcGDtZ03a6cv2zPcHFGeQLL0apZwepE8V/4v9LE9ftDYL/axZVl36K5b543VFvqZPk8qzB/CA/56ktMhwuHkT/URSbyf+Wc+k1akN840bZlXhN7yWrxaMVyD0yl+"
//		"HcyBp036pgUFMzyAOGZIi3mnu6h2/7Uu84GsRygLIo1mUsnwtl6IPbAMVAmq0KoeYtadeDMPveyonWt4oOa402N7AoacHE0uRKS1D/j/Lr/UfkJ7rqwrYtQy5QygX1ql6JU9FBjBkGVfmkHyZQgE7Oo/4VVtbwog7coJ5fo4M9U/E5K5zo93bZTVLhh5Y2owljycMG9L0duFXimL+3HykT1JBf1r/lbbJ3pAhV30LJ+KCDa3V8mVt4OL6HHAzgi52YaStJcNhWk5SlQGFrW6RshWQuErCVcPvF3PWOYr2J61e0tTQYYzYFwFQSAcxWqELzwKYculVfb0WZ98OsRRLX5CdB1BuZYGhrNBECzgq5h4coSFDKLRC+hPNpvuILbRnwDJPo4bMqWuBjxroPCVorU3wcjCmEx/2fler92cSjwbmvs5TT7JN8FmLI7Mr4BCShRB/"
//		"ZEdWaHRRORW36SnP1nQlVH4YfH4kJarkAcU9lnqwsP0xM7ovtaUzO9vxyG0RLfMl1SpqAOGCj+8p4/OvuF0X6fLac8EtofzBLqFEnC8uH9as0RFRu01ekrvV6C+uwEjjDNQHJTEGfG8CSC91ubZdp1JqKRnKYjzDDMhVctvvZIvjM3OOVoBoz3eY1OCvTfA7PlXLaYqUtfJ37e9bR6kRqVzLhVjP+vfgpdcPXmNp8hipccmJqDj6fB6adZV2adDz+4u9X+jZcDNbfwsPGtoP/Ii8sF7G24juIjy82n7zXLDWpKNRg3FoS7jU9FTLGF3vdBoc9pGrLJDViAb4DWou8OzdZXZcXJ/xLlDdRzRGesOVZhNKGX4AVoUDnmBuxcfXukNR+"
//		"qt21U8UWglfDX3hXcQ2SN4o4ipow2KqoHsOIuq9UU1r0hdHIelSmPHYzRany9Ppy1tju6LBej2Is1waphIFEJ4VmD2JB7hWR7xSlOOLOmDARivOZnj0UFyENs2sy4pJiiPD7W3ITZWreakC6TCmLbOUFVckDy24MQKKdanNzs7vbeaR2lMuR/HYKSHmvEoeSXXQJQZGpWbr/6IvAQu2b9eHU0/VWWPs9qNA2LqsYPpMktwYZGHGpvbECO59BpNVoZWBJWgTsH4/G4uazfDcACXyPTh9NcvuNExi730Urfk+bwqay11UxjxBI0gJjuqFRwS1YT8075dR59z/J7rwMVewZsyMdz8oE/vGHAOCrDF/9t3jnkYbgr5kBHsi0Ko+s7IGUhFCaJWurZ4eLbwGVQR4dGs92Y6E5VaZD4/Xyhr3zhpoj9gliC3XA1JPAS1DS0EGxManngJG/t/Mbdl3aznfiKLNGX2SOOFaKak4wpdgL9hH4yO/"
//		"JYjpY6Tm5Ba/NaxVWokkmU1zMw4EugKKQpo9dKZci0tOgQRbQqIAajBiC8J9EpNRsaOKmuhXrcy0q5fSBACsI50q16VJMFMM38AxNBmKJFu9I6Jy4NeWBhdDzz6ym/Hh3Q4nUiA1GlGRV2aALA5od7+oOBzUo01lE8dKXk2eHoftniF5U84cvVy5Xi4/szgKA95DmhdyY+rxbsBKZV1JYB7Wz6BsVCjx0+ZfRVB3rpdMXHdMutsin00PV3Tqzmw/cMhRXdARyXINCBO5ESLROLym2dknT9+RJHss3qEft4aq+5sq2oFgUMAfsKE6HG//ck5CAO51fshsDrEEauDMZ/8LB5qniv91FkmmmbhwkM5romf4alXQDbImxZipEpwh/BpKbadu6vKXcJbFgBcie2+ecdEoEQRFkEGzzPTvz8V82+kRN9XClyMmD+wfkDR4b8+"
//		"slrHDM9plfbnpCw8ik5a0FRDXTYD7vkK8c5nB2OyXKT4JM7yXRaCRwWrRtC8VR6PjT5OcGpds3Ht3/JfKSGqq1G+tANgqHXAAMT+IfHpLLMTupnWhZzioueD7C2roY/U2PZq08ivz5ygnCI13WpXrjyLhECLJZYE/X6eVLTg/bq4JWrUzAU0/Nn0wrTVCfeb4fPkWkCMDRcGZet4Ik/3oMm4aKarcC057BqhrSUJ/NEHOtJqaSS0ToCZae7s2iaEaKkfe7lNWxr5hw6dxTO8vdroENr1Yt8rAJEAOF4+QwJj1UfRqv7iJqa9TxXPzBgtFtU//5GX9quQN4tpgHYDJ2yVUyz20XTKd7y27vdcMUpdEpRO7gRL7xrkajz6P2URD4+j5k+bM/OU/xGucfFcLaX4sJVyXKuUgzdRco/8fDGiIOqlhV6+jyDFkLdaaxOdx0Ne/4HmTTuH5RlkxsoBkfoCF/ArA/G9Fc3253iNPNPPU+"
//		"DClYwhnCpFCdlZl2jSZA0ahDQS5iNjnIYzMvIMmpwxYz97VG7IcSiXMFTqgulsfQriBnD5uqoXIPLfhGz0GxMAHi7Mya4HLGH9FZZz+zenx7e6U7Eblyb7t20sj62OLxCkTimLGkBvARQdj8UEep3z0NeH/7QE0dzr3Un+OxMNPzPByN2duniqw2pg707ioy27oiT/IjXE8bwcxbI0HSJrI7agkvRTckMngBCc+19eqej63RaQBvgwLOuSJKDcZSDdlkziWcKNMzgEA63hg95q+l7yw9p0gwx41d9hhvT/wSG6kaPrEjGvOz8D1A6jvoLNduN8NTZDA8FT4+hZI9FKVbqOZtVNb2RMv3jTQ1vMNf00EqTK3pHzhS+4tbx/RyJ9bzKxOIwLN2yK8FYcLIxp9+"
//		"Rt92bdO0LLIuOq3HrfER80EMkz9fyeu8lY7RIfEtnjysY7ysNMrKHODi3tvVEguoLUTH0NEgnY5kyJ14MAp3AJlUPRyuFK5ygpdthaycjliRak6fIjeF8O61DYKYBV6K/uLT6ETboNuBGMxLeywkSk+RZdjzJS34NrlUKCZcCKELXwBMm+zUy4FYlXPYtTGGkUyMx6ezOJWz5R5KcS6A48CGb/5lxRgKXg3pTalSGXtU6xBFyOIGo2xqW8i0n7syqdaqlDeKLtv9+U8pt6pHBp/tMVYusSSzSJCPHtFgOkApTDlHAx5gr5oaHxML0CDvuDnUhgDgYTJORKGr+eU1YlyHBgSzEA6UAIo/kvLuH8TA+XXeSPLR4dMt7d3WruDLfvOObcIlG6w/TSDzI8P/VcK1u0ssZ2dpehmnU63fTdhRLgnqxhywBhePsPxBskP0hakfjGQvCetPhqHuVqWCdcHhjVi/"
//		"gMQ7omE9wHYXoPW6pX8kziOTIAZun1mT23+WkNnL0tnkO/WjusukBGJSEpO0FQlCxFX7rmKOvBhWiPVZX9m8mGW+WbA9fso3EHN3KpfzlO8u+Z78WjJoEYPciACiih8SSQ46loisuGv+8e51sAUI14iJZ1qSAWcvLLpqg/48q4UbXG6OKzcxof+B7ZBhGJHyTprUefMgu95e0BNt5p6spxT0w2aXQdO0UpeasjieQUY5jFy1BaPIkT/CFShZtTSKuBP5HqchMVE324pWIYwNMQPtVHrcLxGeo1y68+wBti+X0jhW8HO/m+Dp2dt7QT3Jh2EqKPcXfceEIe6Bu8/unnmDEzck/T3veOt4F4SGrY3Uhcgofu05m49McVjRDP9GaKVaHaS9J8rSqx1Ryuj4al4eN9p1UbD+nMS6e2H0cTY0nIH0Yd65V93K/Tl+"
//		"qakTnKRX8VfVjrUTqfPm4Etb8u6RgwvIExSwwbhXuVc2OUKzEkSQVfQ0a5q8fDepCXYkEOZ3UMZo0qcBCUlhgPa0YUtfohF5kzJ5Ri5xYez5xYBgI/gXWQnliwaaS6hK31rJuRDeFg/342tUpoN6C/3hFedLRK3WlTl8Nkq+npJX/M985BKUp3mIEEMAAwabBLpoOl9Zfw0G/shattE+Ag2+DW07sNk8M/fhJJxN08EpYBzSbJH+275oUvlDUw7tML8MeTU2udYijM+uIsDmhHKrAt9l412qNModYMMZDW60vDsfwrw1s7PJ6qM0MV4HKcEP84I8iUejFsBQZQDaOWMWLVqHgNMT0ENCjtCJOdXO8rR4XqbHX9Q4MoRvmn87GCYR/RgqEH0rvqkIeWQyhvpHJCmvP2xMRxkCTF8GeMOyWiDyt9r/y7naLJuV1ks/4tn8dfNdZnQpmMH71rTb16mL+xWNMnlIFizc4/"
//		"x42CRXHHi6P6Roopd0dG7R+n+Aq+8b5GBbDzpdYpnSudWBcCfk1XPKw6HupVXm0RD4GUzhTh9FG0FxV3Y0gPuWa14A9SNpNF2vXsKmnmSpuvl3qGF6OheMH0xfaFBY/klP/eFNc2B10DCfukmv1Rn0UobyTgxU4qFK6H05Bm9072nF95PpRxC+Pe+9LwGS/BS6Hen1Ebj2+DDeQRe2Q9M0K9heHq2ODkq+k+1MoRBQIu+Logq5S5ff0Dd0Mju9V6DDT/yzfVLwdkKU7nxFsgXeVDhqzKZ+zIoM6nHH/PSA2/t3n7jjdeIuyoxRTeIfD06diYecq39T9t/VSWwiWNa7eWhvdLcuZK6cFFfwMFYZ+4+xp6jSzRPbizB/oulkKuVULTb1QJNCfq4UW0e8cqjiA4mzG7SIl4YK0Tcse+4KJEU3E0d+7z9iyc9WFzsliW1WpSEuMJBqxHlYE33W/"
//		"5yV0Hhfh2BkmZIfLVuiuyIuEcLzeV3cQ3wWkw7PDjnw54t908zjLUnh3Bxc/pc4jivIwOoABiwbDpRuYBoltM7+hVwT/BaXo0WkhZscLUxLULT91h+xKdkJD0XVqEjt31TF3R8iY2YwbytIwiVOMYobKGRD9my7S9DrZuefQyTlGork9d9HUZinQbTLMy2jzuRGKUn56YkREo1G6k/uYpTJEIz6qhXhKbUJ7SIrhBxKAJ3ZdxJK+7QHaB4x5LatvEcILM7Ldheubv6VB2XgGQi0sg58UyGZCI1qUyiacLAUOORYz3PXkHC2u1DBkeHfm3/BV8e8pOEtouA4jZbNzvFdkJvD08HK4AbCHei14/"
//		"qUwxB40vQ3jXTyzgcoiKjPb4CuAbbrymM7ithQEshV421SS6KPXPqG2v0ePtJRmrdwhd0A6DFnQGegBUsdGbnz6AlQ8GWWmwt1hpvM0RJW4eWLwAFF6WMOmsQgbXGYiVB1asmPVAqynfXJiFl3ZOBgqVFQRyPpbGPD0iL8hxpK1T+aFOlL7+CT2bEpn6OGdjClxZVGIECuoAGUw44Zu/4mL6DrL9R1MTCQuxUVkGvl491Cdv7zng2GFIN3kAqBFfxmTb/ArUxUG51EnVkU0pLRFJkV7h29Cm+ttwUaqEPdO1dKZHYA6kG2xEUX7O3N392BZ/+6Mi3dupdFbgeE1TccUKNbG8qBTgUfJDz2trIxb8dpvrPfgQLSw8b5wCOVfCkOWKUZaGQ+ttEANfaKSjaolvaA58RJ9n1DPDcsepGdjmf3n4Nejcdwyj0ZVPFDgv2gxXaZd3yLlx2TN0ItNubWjrIpL/Pp2IfyvknV0wtzJ9L+"
//		"YW9zxGlizQV1tRL9rKSjlIboXrqOBz25p90+B4vOYBDu8e57uTspKk3N1eRw0h17P4XrRfz/kTPyoWsqkLpAu7l38QGJ57mu3TuVY+8Qz8Bb6ZQxXz4oRMJmNAlaqA9TG2qmlgUBkquH3Fv0Wu4gN+JV+WyDBsH8U2+8qSZyguo031GlDPR/2/zrVdJ9vQ7e5HVnuPq14ECedbUb4eGIZ0hxSV7OKG8QPqvlFRi3vPhILZ+hZ/elRJMEEMWZ8Aoo13L+s3ERxc1fki1KkQ8Cm2+4ijMq4rXuyCy5ajEHJ1oVOElRwnuHVnyhPR5y/pSysomSNIWLMGYBNQL8X/bOhMbK2zS/K0XAmDVZUC+KhvsvCF5T/q0w/QqxeIj70r4e5Di9rNc5UDfDRe3latJ5I3l3RYrKmN/DPPiSscCQb55QyGoBj6/5YDc6EKELR7rzmGxWTL82LrD15pmWdHT8XWs5xfD/"
//		"thu9764yVAIF8II7FGhzzTQ3LPO/4LIF8dY4/ny4ZlsTORjyF7V84Aq4wtYuYVcQKXX6zq4JGMhKQWcrT/Fwyxu9qnd40FMS6rYLVg2kFS5gnvSHPcVX6iYhpoc9ktu3w4dIgz4c7+skzQ40BAurX9Oc0+fv4XLlYmrasqUBjJDtnRm1FR3vS4Cc+bLGzU9KstXSDPEljug+kuJBJNH3Ua+tNoMxJEBIsEDySaygqE9s2+xr1KuMjMs2P9dYIuUk+uOqm2d6To34RSoawJGbwv3ERsuL15ze40jOIEfXybuJjKfFenpHhi3ZmVc/Dcmy23ztfRWvqAvXmohCPpCVYjFzIYiFdwa67B+8vtNMtu9xkrLwu7DeehWaLnoNKSX+CO/MF7MaOhia/HduF/UgjUdrzfMtCiYSkpCUwJGF/vEknNV7Se6FC5WuJAo4BSUAkwU1G+nFq7OMvIDQPD5D2pZtp55cDug/zDimUNDE4RSr3fkXYQUE9X"
//		"+dCpPtxPA6uUis0AxioWAnBTbs/40qlVlRdaYqrN2tgQTrJsBCR2lzWZ6DNm/2OI0WI4lhTMetLWFrOYo4fC2gUgrRFvft7xlZMxoECGt6CRkoyPmF7Vig1t20jdyLLH0xzutMGiTldDdvagLH5yydyMPsKuFxhEbNCi3gmAICVkcX1/AvsFn0anwb4ixW1N2KwoxbRAwA0DuiqmF1NjWEVY9xHwapaa+De3yOz3/SzGLugqCkEPkE8t+EHH5sJkNDyUKx73+NbMpUQE4A8o+Xq8fe7Q85bL/5sBnfRmk7OUo+kjTkbQy7CxFvrvnFolZh9Op6i+xlO55ARpdna5QYgbsS71QM0piLXolFoFPvZXZtqBEfuik4/+Z6B0YbeKVkrkR0EFdnA73vGyq1OP/vNU+FDBjYrZVbDI8k+B5O7s7rB82sU002KF8oVOm+58kOf4g1u6lStS5FT2nAx4i/+"
//		"1CCuPc2YRau7iZ5lVQ8pOuGTc877HJ9jBvR11oO7l9Rq1rdeOPqDOxJiaJQbkxy/kQWpiYcy0meLPmaZdFr4OwDlpb2tv0YtSyoaAtV/5ue8fqtqyd5IHteeUB3FqfPOUk7rxtW7WmjwC1g5++CuxubJiRvoxMQAYCzJViPurTqq+BvkDxA8hNEMvQpOxGIHzfoWYUhETBYaxjws8YiYVwqGpibLKN9LPbd4pa9j48cEN7h6beM2ltZVIEA3nMK96u2l74Iq8UzMyckliBQIWD0fzWzJY/hprfYZ4iP+464ruMmpPtCXODSmDb43n3/YN4F6RG3Owa/+iMjTPYd+QnBmkcHJRob2SQ/3Pox7WYkZhcV8aL5eoRGKj+z0/5/BhGplHNfQjo6DnRDTTg1Vy2Y9WM/IgGDGpAhhbKuVWtFen2xgevoHQ6NggBURmfD7srrQtCTBAq7XL4mgz4Pc/5X8eiv1BlthXvjks7vx/+M+HgUr+"
//		"zUWL0m+BvSv+kw2/vWoLllihqB86GTtEaKyr0fScw4yUf5MXku8+TIoBEAzUxXZQcPNZ1xj9aGEVdd7I3x/68a5ywWD3uEU6gctBClK1JgiFmKNwVbOJhfDvHzVnmApKknTBiyA6c9q0ofabt1EWVf7IYQT/jmrW1KP0E9lAEtM5JBKQY3zCp/g/4FyvZ9sy7iBtauZm1+Zdj7g6yfrcpUT343WWoXZrbv9SS/RKM0WM+Lc9GItcfRKMMxFiKWezW+TXL3Yrkn8zuPYcBSSmj7kqKkU5WfEwWsdxW70Nd5JuBukT+yALEAL/j8wYGSrrPKgAGCDi+"
//		"sSwmz0sl5bjiX3XnTzyvpTiYmBtcXZwog1qFFDv8SNGth2zwPsUD3MjsI7PFY6LZp3lIfQ1RMn9cUKbHXZhJifhyiF6MQ5BjgttQ27u3HAIF9aKjW3R54JFoIpemfuZKF5mFFtMvEoMRqfpOZbKaOmJNL5n2jsHaqfuhBJypg4JkAtT3LJPhGfEY99yiOO0MFLmPD+QIUv6xIBtIjRxc+9U3CvLbTDGbEIsUNFJGuVWhRY44BgsXOqor7dFTD7ypcCK1WgGSrK1715/hDpEm9YliedGWIyQ9SzCGAOOiZwWnulGlYNALUIoi/yDx9mTCl25F/N4NofZZaM4gtaUOUAObd6Zjw07PI+AQSPubbkXWKXhEUiE1/jfAQ9/SO/ZCwbIuEo0yNJbK89y6YPKYMjwESjnwHQaD7CAkpFUWD/rOTkvbGURX4aQbaiPNzslE4l0rw/Wy9Gg8T/gnnoKB0tyu00faZl4VD8M91TQEev/uy6mU6+/"
//		"GTRx7nGRIXc5iiDpceFD8FEexAoosKLgiV3ZIgwxah3t9JwpQMbCDVnk4LWUnr+yuimJiOeoG7h29uTGyVPFD98RjABnIQW39BKgn1+56PPOkNUjeq/tzP0mZ8+y919CBaqC3ckDYxYMCGho18eJhMnHAL1WgQEFNQlidFFMwlYR3WFXnEFOZ3daOHuMm18+8UTdsItI7WIib7MtboId5lcAvtwMjFAINRpEfN2zaXdXI0SYPwGDY4tFGQinw+wHbHbOoZgIZmnW1ca/HjcynDAy8R528JMbjxZ8ieaA/7Ge6vXX/qefxli/A+vLlHt72fsuvXzWSTBppt6oSsHpuJUIeU8obpoO+4BvpSjkeehg0S4LfTd84s88NO06IEXXIMcNTrnBeVTM8juGmomhk/AIbfmIihtbz8fYVMRQW05GrK9vKx2/oH+pYRGhUc27sS8vVc0/gd2kRnF7o41Oz/"
//		"3Ms9NZTRyz2rLiE8ZlxXOv3gOKxoZiajGfdJx4otLKso0TjRw5HRnsMmDznmSBIT53SdWFCaheOCjXdypfeJYgxCtso2KU5Q0WrqMaXOc=", ENDITEM, 
		"Name=edtUsuario", "Value={pUser}", ENDITEM, 
		"Name=edtSenha", "Value={pSenha}", ENDITEM, 
//		"Name=edtUsuario", "Value=kzm7sp", ENDITEM, 
//		"Name=edtSenha", "Value=@padrao123456", ENDITEM, 
		"Name=hdnTokenRecaptcha", "Value=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=BC9D8A67", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=7IpOis6H1TgSQKATt6DeDxGihbenyP+T0jkPWYNLdLFMJEuL3jgdKaNKRiiNnVptedpXRrBhaj8S75MVY9mhRVI3RXxDOFmYa2ZkbSSQZOdzW5UWT7MDfzf780fIB9SIxviBlS/xgsETydfw8b6DXjkZl+8OSiTQbHgAVrV5HmD5xb6eRg5CvTz8dCqgOjEgXf1fIg==", ENDITEM, 
		EXTRARES, 
		"Url=js/cnpAjax.js", "Referer={host}/frmMain.aspx", ENDITEM, 
		"Url=App_Themes/Default/Fonts.css", "Referer={host}/App_Themes/Default/Default.css?v=31121600220000", ENDITEM, 
		"Url=App_Themes/Default/Menu.css", "Referer={host}/App_Themes/Default/Default.css?v=31121600220000", ENDITEM, 
		"Url=App_Themes/Default/Master_Page.css", "Referer={host}/App_Themes/Default/Default.css?v=31121600220000", ENDITEM, 
		"Url=App_Themes/Default/Utils.css", "Referer={host}/App_Themes/Default/Default.css?v=31121600220000", ENDITEM, 
		"Url=App_Themes/Default/imagens/loading29.gif", "Referer={host}/frmMain.aspx", ENDITEM, 
		"Url=imagens/grid/header.jpg", "Referer={host}/App_Themes/Default/Utils.css", ENDITEM, 
		"Url=App_Themes/Default/imagens/left.gif", "Referer={host}/App_Themes/Default/Menu.css", ENDITEM, 
		"Url=App_Themes/Default/imagens/right.gif", "Referer={host}/App_Themes/Default/Menu.css", ENDITEM, 
		"Url=App_Themes/Default/imagens/menu.gif", "Referer={host}/App_Themes/Default/Menu.css", ENDITEM, 
		LAST);

//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_url("ping", 
//		"URL=https://clients1.google.com/tools/pso/ping?as=chrome&brand=VDKB&pid=&hl=en&rep=2&rlz=C1:1C1VDKB_enUS954US954,C2:1C2VDKB_enUS954,C7:1C7VDKB_enUS954", 
//		"Resource=0", 
//		"RecContentType=text/html", 
//		"Referer=", 
//		"Snapshot=t98.inf", 
//		"Mode=HTML", 
//		LAST);

	lr_end_transaction("ID500_BW_02_Login",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_03_MenuAtendimento");

	web_add_cookie("trigger_state=menu_trigger_7; DOMAIN={domain}");

//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_header("sec-ch-ua-mobile", 
//		"?0");

	web_url("frmMain.aspx", 
		"URL={host}/frmMain.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={host}/frmMain.aspx", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA", "Referer=", ENDITEM, 
		LAST);

//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_3", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t106.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"event\":[{\"download_time_ms\":7072,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"http://storage.googleapis.com/update-delta/gcmjkmgdlgnkkcocmoeiminaijmmjnii/9.28.0/9.27.0/"
//		"7e3b7df34baadd8bb51d557eef5e79f9b2b17108840a903c2b27825e32d44fc3.crxd\"},{\"download_time_ms\":28068,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":45009,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":4033,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult"
//		"\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":24056,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":45009,\"url\":\"https://edgedl.me.gvt1.com/edgedl/release2/chrome_component/"
//		"Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":4024,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"https://redirector.gvt1.com/edgedl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":4024,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\""
//		"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\""
//		"download_time_ms\":4031,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":4028,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":0,\"url\""
//		":\"https://www.google.com/dl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"download_time_ms\":772,\"downloaded\":45009,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"9.28.0\",\"previousversion\":\"9.27.0\",\"total\":45009,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/Pu4v-tN-kWF2q40ZuKM9Sg_9.28.0/AJF3c7ikkTZsKlD4Mc2H2vA\"},{\"differrorcat\":1,\"differrorcode\":12,\"diffresult\":0,\"eventresult\":1,\""
//		"eventtype\":3,\"nextfp\":\"1.91ee417000553ca22ed67530545c4177a08e7ffcf602c292a71bd89ecd0568a5\",\"nextversion\":\"9.28.0\",\"previousfp\":\"1.4302cf764844fc6ca4cd4de8cf5e13481c4dd15b4bd8d667869f9ae2fb54f9bd\",\"previousversion\":\"9.27.0\"}],\"version\":\"9.28.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\""
//		"protocol\":\"3.1\",\"requestid\":\"{81beece4-b147-4627-a597-698d7ca3b531}\",\"sessionid\":\"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_auto_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_auto_header("sec-ch-ua-mobile", 
//		"?0");

	web_url("frmMainMenu.aspx", 
		"URL={host}/frmMainMenu.aspx?ID_Modulo=AT&ID_SubGrupo=AT", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={host}/frmMain.aspx", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
//		"Ch0KDGdvb2dsZWNocm9tZRINOTEuMC40NDcyLjEyNBopCAUQARobCg0IBRAGGAEiAzAwMTABEIW5CxoCGAg8kWMLIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARDR-ggaAhgIqzfKfyIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQ9-QIGgIYCKvApjIiBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABEMm1CRoCGAjnJjGjIgQgASACKAEaJwgBEAEaGQoNCAEQBhgBIgMwMDEwAxAUGgIYCLHnkC0iBCABIAIoAxooCAEQCBoaCg0IARAIGAEiAzAwMTAEEMggGgIYCOK5xpsiBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAMaAhgIeaM2dCIEIAEgAigGGigIDxABGhoKDQgPEAYYASIDMDAxMAEQ4WwaAhgIJKDwwyIEIAEgAigBGicIChAIGh"
//		"kKDQgKEAgYASIDMDAxMAEQBxoCGAiVNYrTIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAfGgIYCGuJ5QQiBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABEKYMGgIYCD0P7HwiBCABIAIoARopCA0QARobCg0IDRAGGAEiAzAwMTABELiZARoCGAgugdtIIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARD80QUaAhgIoxHUTSIEIAEgAigBGigIEBABGhoKDQgQEAYYASIDMDAxMAEQkAsaAhgI174x-iIEIAEgAigBIgIIAQ==&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_BW_03_MenuAtendimento",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_04_MenuPosicao");

//	web_revert_auto_header("Sec-Fetch-User");
//
//	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		
	
	web_link("Posição do Consorciado", 
		"Text=Posição do Consorciado", 
		"Snapshot=t108.inf", 
		EXTRARES, 
		"Url=../imagens/menu_right_border.jpg", "Referer={host}/includes/Menu_Conat.css?v=31121600220000", ENDITEM, 
//		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvOTEuMC40NDcyLjEyNBIeCVJI0Z-P9HesEgUNesI76BIFDUHgbisSBQ2R7rth?alt=proto", "Referer=", ENDITEM, 
//		"Url=http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM", "Referer=", ENDITEM, 
		LAST);

	/* Request with GET method to URL "{host}/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

//	web_revert_auto_header("sec-ch-ua");
//
//	web_revert_auto_header("sec-ch-ua-mobile");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_4", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t109.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"event\":[{\"download_time_ms\":24064,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":60472,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\""
//		":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":24037,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":60472,\"url\":\"https:/"
//		"/edgedl.me.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":4027,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":0,\"url\":\"https://redirector.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":4028,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,"
//		"\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":4030,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/"
//		"AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":4030,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\""
//		"total\":0,\"url\":\"https://www.google.com/dl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"download_time_ms\":882,\"downloaded\":60472,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"286\",\"previousversion\":\"282\",\"total\":60472,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/PUQAMKExNx39eR1v5Sk6Mg_286/AJWEF8YqOUeAD9bwGVH9qZM\"},{\"eventresult\":1,\"eventtype\":3,\"nextfp\":\""
//		"1.d36e34ff48b9ee4a4361007c63aebae5f66afbf9379436f2649b414d802e1f5e\",\"nextversion\":\"286\",\"previousfp\":\"1.418f6627139e37d2fe70c56c6c895b513c1428afc03e057e0616db650c689c74\",\"previousversion\":\"282\"}],\"version\":\"286\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\""
//		"{0cef4808-eb1a-40e1-9de0-0ca55aea5ac9}\",\"sessionid\":\"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);

	lr_end_transaction("ID500_BW_04_MenuPosicao",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_05_LocalizarConsorciado");

//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");

	web_add_header("Origin", 
		"https://{domain}");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConAtSrcConsorciado.aspx", 
		"Action={host}/CONAT/frmConAtSrcConsorciado.aspx?applicationKey=Y0tUAG5AjJq8Q53qxz+kEjoaA/pBy1BDdh7DOKobo+w=", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer={host}/CONAT/frmConAtSrcConsorciado.aspx?applicationKey=Y0tUAG5AjJq8Q53qxz+kEjoaA/pBy1BDdh7DOKobo+w=", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAL2XUVMbNxCA7YMDDKSGkDg0ncLFSdu0ARsSQhIGJwM2QzwFw4BD8+YRd7Kt5k5yJR04L53+jL73ITN9bH8CP6M/Jl3pzmfjOyaZTBt7xqfblfbblVYr+X06Oz9iLjQaZUYlZ644wr/4hONDJuQ2st/8iN82GjnTvGlLd2XlHvFajS1XYo6OMW0jc64vPsIukowTZn4fCKseauFtX0pGt2wsBDomEm85HqFESI4cxpF5N7krqxCBXHAJ2xJdYktMHeJhKpl5OxArx7HvsHst7tSYJDZBIttyzPtD6n1M/Ub5oLZVX1Vd+6/ZzQep6fSEkXayZubxs/WVR+trT55mc8bCrCNhPiAoykLLD/+5lkqnUqn38FFP9Zk24Kd2/FZI7BUqSKIl6wRzQRgtrRVW1HfJKvuu9DkuUexD6O6SdeifusSG2a2zN5iWTp88QY/tx+"
//		"urzx6t4ZWnz0xlfG7Apv45xnIE5LfCduEIe+AWbYW4zGvPPbbb2ENT0KqQZnOXI28knf4iNBT2U/5mlKGxUfj5a3LzRddzrbPQ5/xqYSVvYWozB0yX8r5sLq+u5188vza52RUbQgMs4pTyNXweepK3wAIVpXzY2OhCuy1lZ6NYPD8/L5w/KjDeKj5cWVktvt7fC5zs9fWEA1YAxGloXSx7xOZMsKZctpm3Af2Wg1558MKylB/YxSoNLIo8fNmVoOdGVYSSUl5yH0fyVwKXfc5h7B6zkYtDtTYcmAZkx8Xd+tsODqWhvM2IjS1I4APb9jmECBPloW7vzaenzKcOdvLRsCRf6+jUxauDfa7G9rUC9iUsyrAqCVCtNMJ0zVsSrJXy0IXQ/tRIxFtY1qCz6CAbq2W7HFTxIyi1/UadSN9lAxDY15Az/znn2D/"
//		"9XKj4xP0foHIF5q7DPhNNr9Rno1VeNqrUdn2BBpcL7OM6FO5PZ20Wr9oFWpO8e7Qq9K+/l4vRZu7t+iQLQ2MDvq5Pz8dMKJy/pTcdqLEtvhE8kPcpBS0cE5j40JgeaPlsVU3QqCriQ8VdlfSxxj76mXF4EKoe2z5xnQyc0GdEdVGH1gR8jPAAex9+pnJGM5vNjS4YtmP87i9Mvzraa7zEbqfxEz7FTs4wjKyTm2iqo3H8BExBHWs7gdBIK2mGUIp5W3queavqwLyRJrERt+AQFoxD7jnMMcysMpVWx+7sSErxphp3VK3eVtWzpd6qEFAZ3qQx56Rncin1nb7xIJVSHjq5+zDaCZqGMQIujy1M1dAZaUGSveKueffXoj7Zi00OZuiWLFMxcHMoINHpLozWcVea83DRIRfvLv5glsMG/VwYrzPmwr65uosTxD7ox+"
//		"K4uaTh5cMQXu6UkbPtMshbwvRlBLIM2SjwYnHCnO8pLQdbUYdCobCYMW8n6rQvAB+Jw+8nRK48husHgtuCuoWJHni2p7B6GiDGhQAajYO+0aCdWgjaoQA6QS7jFXzGXLhLROFFBrUaCwtZFRyE91WiLhjvhInyMfHBaS46DE5eqi5/A/H1FBd/ak0Q35AQQGNxUP4yCAUgiQ7V7RT1EDNKJHRauARSCwMhJgPAeBzwXUIkFUgqAemC1P2YRIHMaLllRwpFGZYBZSJOWdSU3aOQssv1sF3ud6L8y1XgFkmVEUnOdIprNTCu0AApEydZCfGoU0fNRg918yXc/AvKkNIEOS0RkJIVAJqMg75NAnFERRPzywnwpbJ68TcntjbZ6xTk3tfJyn5STMXRdxLQVa/DVU5E1EwkAUr/BSxOX7U+AxbhX9ROV814tD4zygTxCLdChVr9YRlYvxa3/sOw9UNuV2mTcQ/xE5hgqEJbuztRIvRUltIFBQ/"
//		"UKhGSNQD94oM7R09SDbcYTOtA1ZsORdoYIC69g+Fs3PDzhMJa5jjY9bqw7yG4GmjCC/gj2sJeCfWrPkCzB7DCUG1gvXVX4A6LAD1z1USWD3poBhO5j6gP1iGmMjuF7LGjNJ89UH/yhBXIL94FhScmBNRsHLWWsGb96dOjeeIxcoi5XQjM8+isCOtsoi6a6+tXlfeTndCLEwyLeOgiGov1upYGOzYMDIAJUuDMxTkPhtcUoj3C+kxw2JYQ2IM7Bolo85FO2e7pgyBvJeqIAt8AmrE40taVOGjB9g4bmb5yMmjlxqCbvs7so+4epi3ZNixdEZR+Urez/fa/2V2lCUMRAAA=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtGrupo", "Value={grupo}", ENDITEM, 
		"Name=ctl00$Conteudo$edtCota", "Value={cota}", ENDITEM, 
		"Name=ctl00$Conteudo$edtVersao", "Value={versao}", ENDITEM, 
		"Name=ctl00$Conteudo$btnLocalizar", "Value=Localizar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=ctl00$Conteudo$edtGrupo", "Value=084744", ENDITEM, 
//		"Name=ctl00$Conteudo$edtCota", "Value=0003", ENDITEM, 
//		"Name=ctl00$Conteudo$edtVersao", "Value=00", ENDITEM, 
//		"Name=ctl00$Conteudo$btnLocalizar", "Value=Localizar", ENDITEM, 
//		"Name=__EVENTVALIDATION", "Value=eQdwumdoaOL4RcMyX4tt6RU+s5uLFXq4SxjBHmm09edM8HovHM4n7XB5qE1IhsVG+VF8tnchTkCaaDyYkUDMUYmoRSh25gEwcSTlm0ZRLTH5iSqCwvPJs2cFLIMauZcokit7U7LPHXEEl0vXfOHvsnqy01CHfnw2bUFQRcETTUrr0PIpVJQ/92uzvLuLGluAPRmXyP/R+T61yk/HSNcCXTidVbscepF/6XAmbNxVYlFOl3ugcgRPqLp//yopiG4r4oWZo5+XL2baGXjqI3tWcGHBxjVF+4Mt3SA+lJr5xQAF+Osk", ENDITEM, 
		EXTRARES, 
		"Url=../js/css/tab/images/ui-bg_flat_75_ffffff_40x100.png", "Referer={host}/js/css/tab/tab.css?v=31121600220000", ENDITEM, 
//		"Url=http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ", "Referer=", ENDITEM, 
		LAST);

	/* Request with GET method to URL "{host}/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

	lr_end_transaction("ID500_BW_05_LocalizarConsorciado",LR_AUTO);

	lr_think_time(3);

//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_5", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t111.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"event\":[{\"download_time_ms\":20037,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":1014901,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/"
//		"APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":24038,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\""
//		"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":1014901,\"url\":\"https://edgedl.me.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4022,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":0,\"url\":\"https://"
//		"redirector.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4030,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4027,\"downloaded"
//		"\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4028,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859"
//		"\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":0,\"url\":\"https://www.google.com/dl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\""
//		"download_time_ms\":1531,\"downloaded\":1014901,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"20210623.381589480\",\"previousversion\":\"20210517.374775859\",\"total\":1014901,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/XleezcHa4M2d3PhczE87Tw_20210623.381589480/APD2xkSOYrqcqcD4h9WusvQ\"},{\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.b4f8bd7ec20326d2a8c935a5c25690be6e8f02d4716e5b96c001a6e10b538556\",\"nextversion\":\"20210623.381589480\","
//		"\"previousfp\":\"1.08c7fbd71f7945793f9ac8a85ddb8d9aa3f02ff4d9893af776014b144485cd8a\",\"previousversion\":\"20210517.374775859\"}],\"version\":\"20210623.381589480\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\"{b30d5359-2fe8-4635-9609-a8a0aad8eef3}\",\"sessionid\":\""
//		"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);

	lr_start_transaction("ID500_BW_06_MenuOfertaLance");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pDtAssembleia",
		"RegExp=edtDT_Assembleia\" type=\"text\" value=\"(.*?) 00:00:00\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pLanceMinimo",
		"RegExp=ctl00_Conteudo_lblVL_Lance_Minimo(.*?)text-align: right;\">(.*?)</span>",
		"Group=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pPorcentMinimo",
		"RegExp=ctl00_Conteudo_lblVA_Lance_Minimo(.*?)text-align: center;\">(.*?)%</span>",
		"Group=2",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_url("frmConCpCadCredenciamentoLance.aspx", 
		 "URL={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?origem=atendimento", 
		"Resource=0",
		"RecContentType=text/html", 
		"Referer={host}/CONAT/frmConAtCnsAtendimento.aspx", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../App_Themes/Default/imagens/select.jpg", "Referer={host}/App_Themes/Default/Utils.css", ENDITEM, 
		"Url=../App_Themes/Default/imagens/select_arrow.jpg", "Referer={host}/App_Themes/Default/Utils.css", ENDITEM, 
		"Url=../App_Themes/Default/imagens/radiobutton.jpg", "Referer={host}/App_Themes/Default/Utils.css", ENDITEM, 
//		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvOTEuMC40NDcyLjEyNBIeCULCYa-MUGuGEgUNMlOrHhIFDQeEA1ISBQ395Jyi?alt=proto", "Referer=", ENDITEM, 
		"Url=../App_Themes/Default/imagens/checkbox.jpg", "Referer={host}/App_Themes/Default/Utils.css", ENDITEM, 
		LAST);

	/* Request with GET method to URL "{host}/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

	web_add_header("Origin", 
		"https://{domain}");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);
	
	web_submit_data("frmConCpCadCredenciamentoLance.aspx_2", 
		"Action={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$rblFormasLance$1", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZ3W8jVxWPnYztfGydzXad7ddktrvb3e16nfFXHLcN1Bl7U4OduLY3BaplejNzbQ87nuvOjN1shRA8ICEeQeKBJyokKnjhAfGOlP+At74hhHigvCEhISGVc+98+GuSLg+VQHUUZ+aec8/vfN17zr35LBS/tsq9rNi6KN6UiGHjoUpudk21jG2k97AlkRMTGQqKd1UuOcM2VPaHloIqfaTpdA57qJwq+lBTCZ3AyzJlNoluNfH7Q83EDWLZ+0h5/HX8RJYTUe7GjMgT22iYRBmaqGRZuH+iYw1xL84wKb3HNdAJ17SRibmrDlXrd+WSbmMTtbDRQ9yV8XAT68gmpka4u85gtY+"
//		"6eH9o28QoKdiyUEuzcUnta4Zm2SZSiYk8zWZZSVmzkA6qYMVGU9g2NlStjw2bcDefxlHUQXeDGdtYxx2AoLySpiIVW5Q7O8f9FugLhinkqINNGzGv0El0nL2wedvBKBKxkcUg6ANQLWIqGnJCl/l8zbznyYjfnplWx8ZQlo4OS206Y/wWf+PewlooFg6p3KtPj0QRXprP1XGqUHPj3Mr99E5+N5vOibl44tv8tdYhTcOOZvaRgogM0uRKHSLAhQ75myOroSODHEP00NttuSHJreGJzJwn17S+ZoNDOvzzVIaJVWyAh1iQ5Ur/ZGiD2VTK86MPZOBwZgFBrhMV6SxylHz1uDQjUa5rRnTB/fA3JpWggkAFCxYM4GAPlsq53GrL9aFuawOdOAK58MMav3lYl8G1FmRqHyztD0wyQjCVkw+JoCCLCCoWCMsQ+qTTifQBVqSNzj4++yVJCkhQIAvgy1CIaWLz7CN47gtEGGBTAT2GSBf6Zx+"
//		"dan2QRoSuORyQFL8BupY1kAwKIvmADlI9n3PcMeOwBwftFqWuHh5RNzdQF5lhiV8/rsktpINPyniEYe1Ft3746duD4t/e5J+diRxbN1REbGTZShnZOLLwh/L3f7/3SYy/5jGazDEt3G9p/aGOzB5/yXf/A+2UjN2+MZ8YVPg6eBkCMBHCcKPJCxclCpXb4S/PhXmMdWX0wWSC+JlzSTEm5GZ+u7oQAvbP4BNypy7Rhz+HWk8sG/dTEtF12Ho0WK2pA2xgWPypssYGkPnkvcy777qMLdvUjG5S6FsQUF07SQrH2LSAbS+XEulPUpAglYYm3jPwEHY9PSk0hie6psDe3CaPsbF3UiigvJLfSRezOSzuFh8lv0jhj5bAzqgrJ0bTGEEext5CVq+lfYgvwcxjpA9xA2mmtbC4sBj7yUVOcf9W3ofM1ewnnrz30l+ohx7F/nqRUpM2/F/H6t1HixCt5TB8sQf6tUTf/"
//		"hdjQldRlGrI1hZ9WPzLlyJKS/+GfeTLYSrLxMf4CTei5oRCEQ4GaL2c3pAjERgOC0LoX+AZ6p1IDAYu+Xx0I48suzz/9HhWYSA+xSNnIms0oVZZTZZM6B+hv/RqcqPCb0AxYeXKKzAq6fHXL242oJvt8Ddmqw+UxQ4Cf7By6iM0ear0ZI2q1fhEw9RGmo67GmGwfacj5EItfhW4vTYK88+NGWdayC7/jFMVIVIDHTlF6ipMBi2gPaZlEprlIa2XlBIfWVC+S8CtaIOpgifMlbuZUDgNTVBNjE/VazkzFrreqMz0Cv/Y+iORP33nTf4SODNIj82xqUzm27TpYdq3+M06of2+KZsnU7Quv0E7GAgE7jq9yz7uc6E6f208oYnV4Yea2UDQHungtli17DRA4R/9jOPv0MYI92GpAbsMLnL55NKAWLT1sb1kATXAiWBXkPI3ff/"
//		"4jSNsmoTqNTSoR9kJCFy25jVEbTiCRP704q9erX7lk1gi3InHE0t8WFE7/NrDZk1+C+sD+R18gtVEOByOq4lYJ54I89FjzdKgg+6pbHAjHKKjy5oBu0TP7uvc5nQvR7tHppfDHwZ+5xva+suLCxRzVb4O+qB9Aop26VsVMkqCNzt8RQ2tJxboz9qz9xYWqJZq4o4jo8MELYLaEWgU0UjrglEPTZ278b1tdnLY7pggxijZkmFNnLlSyBqc8kttfGpz1+CUqbG+lraqEwcbPtomRG9rg/NZVNeiCT228lySgUsNF1waSEjd1wl06GylOWsFEodpsbXDXfOI1FE+QyqV2ipwzwfSmC4AvjgPfifAcqox7Amoifv0/Gp5wJc9guBRAHF+EICW5oFuMaDKoQtUMQAIqgMxYbERfYRN3zxfICNjC44PZeyY90IgzZkPsNzT2geHEGtADCfpJu3zCGe/"
//		"YRTHvplBAIrMA708DYQcIBs16LkeeRDr7DjM0kLX6AkMEObGACA6D3A7wJIyJJUF6YLoTqD5hqyzcTideQSKMjsGKLF5lC2GctB0UQ5MNo3tPZ70hL/32NqIpTgjA8Y5FEBankcSAuyB1UOoNzyoq7SApKggSnFy2kaAFEwAoJV5oFeCgExkWM7RciIBnqNSz35HCxYV6TE5ufdSMHGcFKvz0NcDoKtwhKY54aMu+yOAMn4BiWvnxWdCYhNagVPqcT8+61QE7Oim4BJo9GfHQPqleemvzkpvmErV6BB68j0mrHyVDip+IngkgdKcDQ/INBGCKQD6zOeuHOakQ9wl4NaJXW/NHWLCAGLqHQTH5wV/JWBjnS41rMwwhK9Cm9LF/T003vUBNH7kX2wwVsCdHQLo9fMcKR150AQcWUfG0KZ3GcS79/Q3niPaiVqCM372sbPxzA0C1GWQH95K9+YAcwGRGzuRyTADi0kDm0rKATH9iuHutoE03+"
//		"Mb523yxxVXi2MsuRcQsxZvsFFn3brmAWDAKOBcmce5NxtZsLaJWWVQyfjGzjfSp1HZHt0xcjOQplHgZz1nO5UzyZqIDabEEki9LqbFtHBQL0lCqVyvHlZb7WapfNQsCeWKIB054pMXMx22zn7alKpHLaHWLpdYCaOYO9xNkX7GM1Pn8K+6/Lvibq6QywmCANOy90URnuqlpgScDyq1aqMiHIDDSrXjSktoVJqVKmjAPmwjYDIwW0X+4xVX8goI3C3mdkEbGN10jV9tPdxvtavth46Zk6/A9YI79xkxm0+li3DsymfuF+j8LU9qJrMtZrfTxeIOKw/O6KKYLoy14CKiWBDFjJv3FJYv5G8JR4fVbwjplCh87eibwn0wswpGnv1AqtZAk8/hmDBsOZdPZQpiUhQnNAZIsbBLdXrJHdlsgBsrtZLQrJQffqtaLgm7ue1isThhzKLjm+vua+ywBCE6LFGwG+"
//		"5YeDcHb3c968Hx6SQ4Jn8LRu952PnsbrJI+bbHfIVisrCTZXxpT/HsTiotuqx5dzB+f/oDpOL5pL3zSaXzSZK/CJmZ+VwyK+YLVLUKUFac/hK+11WIViccglPAYmJpXVW78NvzfhOhjtuqwYKCAfYedQXQqaFOIrTOrTT8y2EudKvrzoonYnxMsixJR5bFXbWhJZ+4RZbZ9TO/XEenNWx07V44BoqGRH5Jvt7aD4e9zooBOcCrriKu0W2TKGxzl3pohC22Ougm0HW0dbjuN/EA21BMkX/zTdyb7wExhayA/G3kjnVXVVmGs60ksQTQztPYkSGRLfwxg5sOrxgn1uB1Rlunp56o1MPKY6z2+GjFQCBe7THZUybQpVt1Za04R60oMRRdUx5z2/Q/ZKXvoNM7t0vUXdqHyLnHhoLwXfH23dcFwcT20DSEDtIt/LrqKLt38cR00ETuKSZmgyZGn2JiJmgiazFhur9n110/"
//		"Pjj7uW7Tfy04EXIiBgHD/dcE2ILEwnZGzKSFs19YQnrntXzmtWw6KSCovaOzX0Nbju6QuwKcar1jDZhGD6LhqWOmeyTw0zqII3rB7Ng4hPwVSHw4j2PnUsRkFz3jgk8RaI54UmCRJULwwoUWnKCHwhFXaDDUsg8V451DgTw+QbD/GlTLMu2mZUbkoulsOl0oiHwcxp3TjEMJ//3HEp+YVta7BQJ9Ix2m6by+3H+nrxPRN2hEQ26I6dpd8G4HVgNnrYzD0bkgJsvjdFlxF03ERSyGBb++Os/x8fN/ALFgytvbHgAA", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value=22/07/2021", ENDITEM, 
		"Name=ctl00$Conteudo$rgLance", "Value=LL", ENDITEM, 
		"Name=ctl00$Conteudo$rblFormasLance", "Value=Parcela", ENDITEM, 
		"Name=ctl00$Conteudo$rblTipoOferta", "Value=%", ENDITEM, 
		"Name=ctl00$Conteudo$edtOferta", "Value={pPorcentMinimo}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtOferta", "Value=0,0000", ENDITEM, 
		"Name=ctl00$Conteudo$chkLanceLivre", "Value=on", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=0", ENDITEM, 
		EXTRARES, 
//		"Url=http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw", "Referer=", ENDITEM, 
		LAST);

	/* Request with GET method to URL "{host}/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

//	web_revert_auto_header("Sec-Fetch-User");
//
//	web_revert_auto_header("Upgrade-Insecure-Requests");
//
//	web_revert_auto_header("sec-ch-ua");
//
//	web_revert_auto_header("sec-ch-ua-mobile");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_6", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t114.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"event\":[{\"download_time_ms\":4034,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"http://storage.googleapis.com/update-delta/gkmgaooipdjhmangpemjhigmamcehddo/91.265.200/90.262.200/"
//		"1545561c66bb2d3d98cb81cb6de97245bbcd08cf47b50be2cb91b54f25170cf8.crxd\"},{\"download_time_ms\":24051,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":6449302,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4030,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,"
//		"\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":28083,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":6449302,\"url\":\"https://edgedl.me.gvt1.com/edgedl/"
//		"release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4026,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"https://redirector.gvt1.com/edgedl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,"
//		"\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/"
//		"ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4025,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":4035,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,"
//		"\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":0,\"url\":\"https://www.google.com/dl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/OCbKiERz-4NLK-5rVahaQw\"},{\"download_time_ms\":2263,\"downloaded\":6449302,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"91.265.200\",\"previousversion\":\"90.262.200\",\"total\":6449302,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/ANqUIZTmXqklZH7vguvORWs_91.265.200/"
//		"OCbKiERz-4NLK-5rVahaQw\"},{\"differrorcat\":1,\"differrorcode\":12,\"diffresult\":0,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.59f3cd55c9e8be86981b6fd6adf0114bab54ee03b615e01cb21ead086ca4cb45\",\"nextversion\":\"91.265.200\",\"previousfp\":\"1.48b7cd9a9a4134d608effe24870c91e3bfc6a097c1472878a0c6d8b61f87d0fe\",\"previousversion\":\"90.262.200\"}],\"version\":\"91.265.200\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\""
//		"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\"{26c52cd2-00e1-45ab-93ff-0ba13b184b66}\",\"sessionid\":\"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);

	lr_end_transaction("ID500_BW_06_MenuOfertaLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_07_SimularLance");

	web_add_auto_header("Origin", 
		"https://{domain}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_auto_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_auto_header("sec-ch-ua-mobile", 
//		"?0");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_submit_data("frmConCpCadCredenciamentoLance.aspx_3",
		"Action={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZy28bxxkXV1qSeoWyHFPOa7WO7diOaWpJiqKYRGmoJS2zJSWGpJW2gbsZ7Q7JrZc7zO6SkYOiaA8Fgh5boIeeGhRo0F56KHovoP+gt9yKouih6a1AgQIF0m9mH3xKcQ8BWkSG5d3v9fteM/PN+vNQ7Ooy/7LqGJJ0Qyamg/saudG2tCJ2kNHBtkxOLGSqKNbW+MSEWF/d79sqKnWRblAd9lA6VY2+rhGqICgKFbaIYdfx+33dwjViO/tIffwN/ERR4hH++oTJE8esWUTtW6hg27h7YmAd8S9OCKmdxxXwCVf0gYX5Ky5X77aVguFgCzWw2UH85SG5jg3kEEsn/B2XWO6iNt7vOw4xCyq2bdTQHVzQurqp246FNGIh37NJUVLUbWSAK1h10Bi2g01N72LTIfyNp0kUTdCd2YJNbOAWQFBZWdeQhm0qnZmSfgD+"
//		"QmAqOWphy0EsK1SJ0tkL09uajSITB9kMgj4A1yaWqiO3dOkv9sx/Hq34rQm1Kjb7inx0WGhSjeFb7I27cyuhKBfS+FefHokivDTdq8NWoeHG+KV7qZ3sbia1LW3H4t8RnqtZ+kA3cFsnE/lqC1cbh7RFW7rVRSoiCiAppSpUhw8dCjcGds1AJjmGyqK3m0pNVhr9E4UlVqnoXd2BZLWE56kNC2vYhOyxBlBK3ZO+AymhVp4ffKCAhKsFDKVKNGSwqlL2lePChEWlqpuROe9HuD7qBDUELtiwmAAH+7DUzqVGU6n2DUfvGcQ1yHMPK8LGYVWBtNvQxV2ItNuzyACBKq8cElFFNhE1LBKWDfpkUEX6AKvVQWefnP2SJEQkqtAh8MtUiWVh6+xjeO6KROxhSwU/+sgQu2cfn+pdsEbEttXvkaSwDr4WdbAMDiLlgBKpn8+56ZhI2P2DZoNylw+"
//		"PaJprqI0sThbWjitKAxmQkyIeYFiXkc0fffZ2L/+3t4RnJyrH1hQ1ER3YjlpEDg7P/aH4g9/vfRoVrvqCFktMA3cberdvIKsjrAbpv6+fkmHa16cbgxpfgyxDAUZKyNUKgnhRo1C7LeHSVJmHWKuqOaKf/u3yXAjIn8NPyBNZoA9/DjWe2A7uJmViGLD96LBikwfYxNDQyaLOCMh68l763Xc9wYZj6WY7IXZtKJyhnyTEY2zZILa3nZTon4QoQ8v0Lbxn4j7sfEZCrPVPDF2F/blJHmNz7ySXQ1k1u5PKZ7axtJt/lPgyjT9agDgjnp0obVcE/RZ9gOxOQ/8Qr4LmMTL6uIZ0y56bn5uP/uSipHj/lt6HDtWdJ76991JfaoYeRf96kVOjMfxf1+rdR/NQrUUOfrEH+muBvv0v1oSuogj1kK0t+jD/l69ElRb+DfvIVyNU1omP8RN+QMMJhcI8EOi5OL7xhsNA5kQx9C/"
//		"IDM1OOAqE1UCObtjhRU/mn77MMhBiYzJKOrxCG2qZnb2yBTMkzJj+2VsrCetwaLBjyT9INNIRrl08VMBE2xKuT54ycPy1EOSDHZsBQl2Ilovuycp99DNeoCGMnkyVirAMJH96wkJ8OAkxl7ruxMiHGsIz7nkHtekZyB1croAu4MJQTA9AGJH79CSknNjAhoO5ANKq3hs7ysTRSYeNQBPJd0eVSSFmdOwkVtJDo2u10sQU8I/NPxLls3feElYhfbP82BhGymy+TccZ5n1D2KgSOuVbinUyxmsL63Q2gdTjtjuV7OMuH6oKV4cKdaz1P9StGoLBx4D58fLgg5nB3KbDD+7CMgNFBZLlaSiFHrHpeOP4jQIOQTohwllh3AiMB8MhbJiEetg3aW7ZDQjwVvyhpwlXkPCfXvzVq+U3P43GuVYsFl8QOFVrCSsP6xXlATZ6yjv4BGtxjuNiWjzaisU5IXKs2zpM0B2NEde5EKUu6ibsEB2na/Ab4"
//		"/ManRCZX648B/LubxjrL83PUcxl5Rr4g/YJONqmb2XoLRneHO6yFlqLz9E/K8/enZujXmrx266NFjM0D26HYRhEA70NQT20DP7697fYzWGrZYEZs+DIpj1y50oiu3cqLDTxqcNfhVumzmZXOo6OXGyESJMQo6n3zhfRvIhG/NjM8gkGLtc8cLknI23fIDCFs5XkrhpoIebF5g5/1WfSRAUCyWRyM8c/P5PHfAHw+Wnw2zMipx7DfoDquEvvr7YPfMlniD4HEKeJALQwDXSTAZUOPaCSCUBwMhALlh0xBtgKwgsMMja24YpQxG54L8zkufoAyz9tfHDRsHvEdJtuND6fcfYbxnHjmyACUHga6OVxIOQCOahG7/XIh1hj12HWFoZOb1mAMEUDgMg0wK0ZkRShqWxoF0R3Aj0IZI3R4QbmMyjKJA1QotMomwzloO6hHFhMjR0DvvV4sPc4+oC1OGMDxjkcQFqcRhJnxAOrh9Bs+"
//		"FBX6J06SQ1RjtvTDgKk2QwAWpoGemUWkIVM270+jjTAc9Tq2e/oHZ6a9IXc3ntpNnPYFMvT0NdmQJfhmkx7IkBdDCiAMnwBiyvn1WfEYh3GgFOa8aA+a9QE7OiW6DFo9SdpYH112vqrk9Zrllo2W4Tebo8JO8gKB6WgEXyWSHnuhgds2gizOQD6zBeuHJakQ9wmkNaRXW/FIzFjADH2DoZj04bfnLGxjh817JhhCF8jlt7G3T003PUBNHYUfLxgooA7SQLotfMSKR/50AQSWUVm36HfK4j/3TPYeI7oFGqLLv3sE3fjmSIC1CWwz22mOlOA2zMqN0wis2HNPExq2FKTLogVnBjebjuTF2R8/bxN/rjkeXGMZe/jw2TE64zqrlsvPACcQQWcy9M4dycrC9HWMTsZNDL8YhcEGfCobZ/vBrkxk6dT4Gf9ZLsnZ4INEevMiQWwek1KSSnxoFqQxUKxWj4sN5r1QvGoXhCLJVE+"
//		"cs0nLhY6bJz9tC6XjxpipVkssCOMYu7wNyT6M9RMniO/7Mmnpd3t3Pa2KIqglrknSfBULdRlkLxfqpRrJfEAElaoHJcaYq1UL5XrBbYFMG3M1k/weNmzuQSmdvPbu+AHUDe8sJcbD/cbzXLzoRvg6CtIveDpPiNlsslUHi5b2fS9HNXf9K2m01tSZiuVz++wg8Glzkup3NALPixJOUlKex1PYYVc9qZ4dFj+pphKSuLXj74l3oMAyxDe2Q/lcgU8+QKJkcAWt7PJdE5KSNKIxwAp5XapTy95lI0aJLBUKYj1UvHht8vFgri7vZXP50eCmXdzc817jR4WoDiHBQp23aNxu9vwdsePHuqSSkBisjeBetfHzmZ2E3kqtzWUy+UTuZ0Mk0v5jmd2kinJE816xNi98R9g5c9n7Z3PKpzPkoPlx8LMbicyUjZHXSsBZ8mdLOH3mgbVanEhmP/n4wtrmtaGvx3/"
//		"bzzU8oY0WEpAiIe4kDvrLHm6oVY8tMYv1YJvv3zoZttTi8WjQlS2bdlAts1fcWAaH/lIrLCvy8JiFZ1WsNl2OlwUPA1JwoJyrbHPcf5QxYA0ZnLZ88SLumkRle3rcgcNsM2WB13/bdddV+peHfewA+coCj5sE+/Ddo9YYkZEwQ5y276jaazF2S4SXwBo92mYyZDE1vxQwOuHV8wTu/c6463RC09E7mD1MdY6QqRkIjCvdZjtsRDo2i17tpbcW1aEmKqhq4/5LfqfY4XvotPbtwo0XfqHyP1MDWfB96Rbd14XRQs7fcsUW8iw8eua6+zexYqpWYr8UyhmZilGnkIxPUuRTZegHmzXVS+P989+bjj0fw7cCrkVg4Lh7msi7EFSbistpVPi2S9sMbXzWjb9WiaVEBEcu4OzX8NEjm6TOyJcaP0bDYRG76Dc2A3Tuw0EfT1LInKBdnRYQuEyND5cxbH7ZcRi33eGZz1FoD3iW4FVFg/BCx+"
//		"ac4se4sKe0dlQiwFUVHDvA8rw8kBv+qvlokIHaYUx+Ugqk0rlcpIQA7p7kXE53N9/LAvxcWf9L0Hgb7jFPJ32l//v/HUr+gataMgrMV27c/6HgeWZWkvDcrQuqMnisF2WvEUT9hDznBgcre5zbPj8H6fair3WHgAA", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value=22/07/2021", ENDITEM, 
		"Name=ctl00$Conteudo$rgLance", "Value=LL", ENDITEM, 
		"Name=ctl00$Conteudo$rblFormasLance", "Value=Parcela", ENDITEM, 
		"Name=ctl00$Conteudo$rblTipoOferta", "Value=%", ENDITEM, 
		"Name=ctl00$Conteudo$edtOferta", "Value={pPorcentMinimo}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtOferta", "Value=1,1905", ENDITEM, 
		"Name=ctl00$Conteudo$chkLanceLivre", "Value=on", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$btnSimula", "Value=Simular...", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=100", ENDITEM, 
		EXTRARES, 
//		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvOTEuMC40NDcyLjEyNBIQCVIIaVzE3NLzEgUNMlOrHg==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	/* Request with GET method to URL "{host}/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

	lr_end_transaction("ID500_BW_07_SimularLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_08_ConfirmarLance");

	web_submit_data("frmConCpCadCredenciamentoLance.aspx_4", 
		"Action={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t116.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAOVZ3W8bxxEXKZ1IfTiU5Zi2k+Z0juX4i6KOXyJpx0koklbY6oMmKaVtYFxWvCV18fGWuTsqclAUKYoWRR9boA99alCgQfvShyLPLSCgf0Df8lYURR+avhUoUKBAOrP3QYqkZBdogBahIXpvZ3Z+M7OzM7PHzwORy3OCqChFZtgm060afa+nmbTKLHudNB9/jT5RlOi0cK1p67K8jFy0p7LlfduomqzZM0nBsmhnX6caES46TFqnrRR0m5qkTo0DIlzoT9eoTmxmaky45UxWOqRN13u2zYxCk1oWqWs2LagdzdAs2yQqM4mHPczKSppFdNCINu2T2DY1VK1DDZsJsSG9e831ntUk5Q7R9OW2qfJB+aip9zSVRdqq8PLQAuApUZvoB9Qqsn2TGE2CbLfGy21QnbZAI1xW1FSiUgu5UyPcb4J54Icm22lR0yabIJcvwnn+"
//		"wNetjkcpMptYHAIHQLWY2dSIY0Dy6Zp540G7bwwt26JGTynubBcauKL/FHn1zsR8IBwMqMLtZ0dChJdGPduPHW7u8rNsFjBGhNmVxFoml0qk5XQkui9eqZraoabTtsaGHNsWL9e3MbhbmtkhTcIUUEkpb4EgIbAtLh9aVZ0YbA8ihjxsKNWiUu/tK3wHlE2to9ng1Zb4AsowqUoNcDMPLKXc2e/Z4DuU8sLh+wpwOKuAoGwxleh8+5F8ca8wJFHZ0ozQhPsRrw0qgYJABQuOIeBQDxblnK83lK2ebmtdnTkCheDupnhpe0uB/bHgdHTA0k7XZIcElgrKNpOaxGKSSiXGvYEjHRfiAM65TY4/Pv45i0lEakIowZfRZKZJzeOPYNyRmNSlZhP06BFd6hx/dKR1QBqT2mavy+LiIuha0kAyKEiUDZxEPa847hhy2IONRh2pc9s76OYqaRMzWBQX9jaVOtHBJyV6SOG8h5a+99nDbv6vb4jPD+"
//		"0c334UET607GaJ2HR64nelDz+5/2lYvOwxmtwxddqpa52eTswD8Zzv/gfaEeu7fXE0MFD4AngZNmBgC4PVgiidFSgotyWeH9nmPtaVSkmpgDdsraU1MaspXjIJfv+3i+KFw/cH48cPrHNNYwA2+eu5iQBI+xw+AVfyFA7+FKg/sWzaiReZrkM21CAjxDeoQeEcxEsanyDmk3eSb7/tMtZtUzPaMaljwX7r2n5M2qOmBWz303EZ/8WkIkRaz6T3DdqDRKzHpGpvX9eaUBAa7DE17u9nsyTTzKwl8qk0lXP5R7EvUvijKbAz5MoJY5QTCNPwm8Q6qGsf0HOwco/oPVolmmlNTE5Mhn90llPc/8vvQWBr9hNP3juJL9RDj8J/OUupQRv+r/fq7UeTsFszQfjiA/yawqf/xT3BUxRCDfnZwsHkn78UuzT1L8gjXw5TeSQ+pk+EQzQnEJgWYALL6cl8PT0N00FJCvwTPIPemQ7DxDmfD/"
//		"P89IzL8w+PZw4mIid4lOT0PAbUHC/ZRRNaWmh5vZJdLYuLUGt4NfPqj8oOxKtn9yKHJm2J14aLE1TNFgF/8GrrI9REVHqwhG1uitGRGsTZg9+FAjQH7F6vRsVov53iCnac/lQI1MXnnKIJO9XViVOkLsJa0AI6dqyi0L/3sJwiJXJoQXUvAHdT656oh9JIuRvaCqffGVcTIyfKuZLsC12olodaib8v/YEpn731hngOnDlOj0t9S7nMh9gTce3r4qUthlcQUzH3T9Da4iI2OLARtO20Nuu0IwS2xMv9BTWq9j7QzCqB7kmHJjQMvuf9UfAHPxHEm9g30Q4cNWBXwEUun1LoMgs7I9sLFlADnAh2jVN+2feP31dC0mSoV89Aj2LMoMvmvX6pAbei6T9+"
//		"5Re3K699Go4GW5FIdEoMNtWWOL9b21TepHpXeYvuUzUaDAYjajTcikSDYmhPszTo0g9UPrkYDODsjGZAljiwO7pw6WSrh80l18vhDwK/8w1Xh/OTE4g5p1wFfcg6A0Xb+FSBiCrCkx28oAYWohP4b/75OxMTqKUavenIaHFBk6D2NPSR5FBrg1G7pi5c+/Yqv52stkwQYxTsomENXAPjxOoeiVMNemQLl+Fqq/G2FzvZgcuTGGowpje07uksqmvRgB5LWSHGwYtVF7zYLRJ1XWfQwPPz45wVCByuxVJOuOwR0VE+QzweX8oLL4ylcV0AfHIU/OYYy1FjyAmkRjt4pbY84PMeQfIogDg6CUBTo0DXOVB52wUqGwAE1YGZcNiYfkhN3zxfICdTC24XJeqY9+JYmrMeYIVntQ/uKFaXGU7QDdrnEY5/xSmOfUOTADQ9CvTySSDiANmkiq8aiAexwK/"
//		"cPCx0DS9ogDAyBwChUYAbYywpQVBZEC4EM4HmG7LA5+Hy5hEQZXgOUMKjKEscZaPmomyYfBnPPZ70qJ97bO2QhzgnA8YpFECaGUWSxtgDp4ehNzyoi3gdj6MgpDgxbRNAGk8AoNlRoFfGAcHlyXJungMBcAWlHv8Gr/8o0mNyYu+l8cR+UMyNQl8dA12BGzbGhI86488ASv8BJM6ftj8DEmvQChyhx/39WUARkNFNySXg7g/PgfRzo9JvD0uvms2K0WJ4Md5jvHwVNsp+IHgkCWlOwgMyBsJ4CoA+99STw520TdsM3DqQ9ebdKS4MIE48g+DIqODXxiTWk6WGlxmO8DoztTbt3Cf9rA+gkR3/vQdnBdzhKYBeOM2RxR0PmoEjt4jRs/FVB/Mu737i2cFO1JKc+eOPncQzMglQ50F+cCl1MAKYHrNzfSdyGebYYlKlZjPugJh+xXCz7Via7/"
//		"HF05L8XtnVYo8W3RcQwxYv8lnn3LrmAeCYWcC5MIpzZ3hnwdoa5ZVBZf23gr6RPg1le3THyEtjaRoCP+8526mcMd5ELHIlpkDqVTkhJ6SNrUJRKpS2KtuVeqNWKO3UClKpLBV3HPGxs5m268c/rhUrO3Vps1Eq8BKGmDlhWcZPf2X8FP45lz8p59LZdFqSJFiWWpFlGG0VakXgfFDerFTL0gY4rLC5V65L1XKtXKkVeArgqyk/P/7wgitzFkTl8ukc6AGzl1yz5+q76/VGpbHrGDj4CFwvumufk1OZeCIPF65MciWL65c8qcnkqpxaTeTza7wwOLOTciLb10KYluWsLCfdiEdYMZu5Lu1sV74uJeKy9NWdb0grYGAFzDv+TrGyCZo8hWPAsJl0Jp7MyjFZHtAYIOVsDnV6yZ25VAUHljcLUq1c2v1mpVSQcunVfD4/"
//		"YMyk45ur7mN4uwCbs11AsGvuXDCXhqdbnvWwL4kYOCZzHWbveNiZVC6WR77VPl82H8uupThfwlM8tRZPyC5rxp2MrJz8ACl/Oun+6aTC6aSif/y4mZl0LCVnsqha2Tkj0Vmnu4TvBRV2rBUMwB1gMjq1oKpt+Dvw/qKBltuowXGCiWggGHD6nVl3baAVDSwIs1X/1bEQuN52l0WiYTFctKyiTixLuGhDRz7wjlnhL6fFmS1ytEmNtn0QDKNzHX+LU8rV+now6HVXHE3lcudcdVzzGyZr8gRfPCCH1OLnBI1sOzo78bhSo11qQ0El/stx5r4c7zJTSknETyU3rVtiqHhAm4+p2lZVHvWO06ZACWfUd25A5mmgz+CGyCvGvtW9x2lchfsHYqhsEEBQD7jQE1bgOa64Ws86N64QM5q61nwsrOKvc4V3ydHNGwV0m/"
//		"YBcd52Q134lnzj1j1JMqndMw2pRXSL3sP0B4Cvn70wMboQcyea8tS1qVPWhp5hbfKUtdhyhnnKXvZTtnvOIFn0T1zIpYXcYwnEUP+Ezg3uipedBH41dhPKaXIvuswXHtoqjUsPeiazVhvU7DDrrptO3QyCoq+4j4sOd9WEWwdrY7N+dyBHucy3XNh+HsPOcTCp3fE4Mul4KpWP5fPI4T8Ax4ovci3n5p2zRSZ8kal4Tk7E5CQX6T0AR+qkSCc/pSDig1let8FPuVQ2lsKF3oiT831O54jPPoBmQ9mGJs26GJiDi72pUVPapu+LM5yC7+xv3n7Zfef3Ft2P71bwP+9X6Dhy7RqaLWTjma4NyL8PQH2KZ+AvIeMXjpI4SuIohaMUjtI4SuMog6MMjtZwtIajLI6yOMrhKIejPI7yGRQs4xeOECOBGImk/Oq++dpsFT8r/4XP0qvBD+"
//		"fdqHVdNuNujH5b2nHuxRKFrPQeBBImMfflEFwwvcsZ3gPhVgZ3F2jLLdYywbeE/+AOrd0n1HJ+9Tsg7xI4VuTdHjgZk1vVpMcf81vdOu040Fvujj84/qlu4497TgJ0EiIw0s5dCWq9nF1NysmEdPwzS0qs3c0k76YSMYmAKofHvwTFyE12S4Lt894cQBTgu57giTc57q3brx3jOEJnrA7306N4AYpLR7Op897R5O9S+z01ImDi9aRAJYsG4EEITDhZORCcdoWOh5rxocKic+9W+pd0/sNcpaTghVXhRMg3qUQim5XFCMw7LwwcSvBvPyyK0ZPKeu9ZQd/pFtd0VF/hP9PXCabXsNF13rWFeGmc8F7AzY1dNdvfjtYZezLT76Jn3ao27SLeC0p+inXGkf7434UFH+BbIgAA", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value={pDtAssembleia}", ENDITEM, 
//		"Name=ctl00$Conteudo$edtDT_Assembleia", "Value=22/07/2021", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Inibe_Modalidade_Oferta", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$btnConfirma", "Value=Confirmar", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Valor_Quitacao", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnSN_Cota_Parcela_Atraso", "Value=N", ENDITEM, 
		"Name=ctl00$Conteudo$hdnMensagem_Lance_Ja_Credenciado", "Value=Consorciado já credenciado nesta assembleia e a oferta de lance respeitará o último lance ofertado. Deseja alterar o lance?", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=446", ENDITEM, 
		LAST);

//	web_revert_auto_header("Origin");
//
//	web_revert_auto_header("Sec-Fetch-User");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmConCpCadCredenciamentoLance.aspx_5", 
		"URL={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?Comprovante=S&CredLanceFiltro=False", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={host}/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=58+PFTHOwQige2fr2wzsnOCOIaCP56B4XvZCVB+0g8bn/W6+fyKCVtYds5KqlgRL", 
		"Snapshot=t117.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvOTEuMC40NDcyLjEyNBKVAQnIrpvhbAEAjBIFDfNRIiYSBQ2X7omfEgUN5HTk1xIFDU84hfkSBQ2yE-9vEgUNVEoa1hIFDUlXcXsSBQ2PoklBEgUNipz76xIFDQahC2ESBQ3kQUhiEgUNumhO-RIFDTTPyiISBQ3CfOAUEgUNQ2I3CBIFDVLkFGsSBQ2u_uCEEgUNPSQQ5hIFDazsO_cSBQ189xCE?alt=proto", "Referer=", ENDITEM, 
		"Url=../CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUVKufFnMkspJ4LzgjLz5szEd05WZco6Ap4hTNUU+wNMBNN+h2Aowu2lJ9p72mnDGzthY9LaSzLOgDybr+gCVwjnfqGM0la04A116zrhSymAkUw2bEnjHh96Ai+T72w4HKA==", "Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc"
		"+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", ENDITEM, 
		"Url=../CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUVKufFnMkspJ4LzgjLz5szEd05WZco6Ap4hTNUU+wNMBznHgml4vobaJbmd6M/XqraTrCgm3U0ch19RqmH3TLyeomXMWH5oSlga9QRrXlDSuu1UZTXH81RRAKViVorqUtg==", "Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc"
		"+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", ENDITEM, 
		"Url=../CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUVKufFnMkspJ4LzgjLz5szEd05WZco6Ap4hTNUU+wNMB+o41yRJh1ARceWyqp4Pj6NB1lbQMpNyt+G3U3/2AWOhHC5jEeqDdozs4hV0CsCLBUzM1uUpnl0xIpb9oPMRE/g==", "Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc"
		"+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", ENDITEM, 
		LAST);

//	web_revert_auto_header("Upgrade-Insecure-Requests");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"image");

	web_url("frmConCmNewconReports.aspx", 
		"URL={host}/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&stimulsoft_image=Save.gif", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t118.inf", 
		LAST);

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"iframe");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Upgrade-Insecure-Requests", 
//		"1");

	web_url("frmConCmNewconReports.aspx_2", 
		"URL={host}/CONCM/frmConCmNewconReports.aspx?URL=frmConCpCadCredenciamentoLance.aspx&CredLanceFiltro=False&sr_print=77b11f6a64644998", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t119.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUVKufFnMkspJ4LzgjLz5szEd05WZco6Ap4hTNUU+wNMBtl/qyMoEJKh0OC+TUdmyBBOHcazwBXHpQX06wDUQmbR6YOwSTyAA21huZ1Kv2NaXrk5lUYBQtDQM3M6jWQzcrQ==", "Referer={host}/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+"
		"XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", ENDITEM, 
		"Url=frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUVKufFnMkspJ4LzgjLz5szEd05WZco6Ap4hTNUU+wNMB4Chis4hFfAcxXq4NaDYjgJ56iMPm+UpwqGd9N9nGrVF48UABk/uNWmBuqGFgS83bHGIXOtfshEHJY5VIocvXyg==", "Referer=https://{domain}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+"
		"XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_BW_08_ConfirmarLance",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_09_VoltarParaOferta");

	web_add_header("Origin", 
		"https://{domain}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-User", 
//		"?1");

	web_submit_data("frmConCmNewconReports.aspx_3", 
		"Action=https://{domain}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{domain}/NewconWeb/CONCM/frmConCmNewconReports.aspx?applicationKey=qmr3XW7c5CZeVPK6zKICeiwdCxT+IQabJXAglVeOevycNmE8EJ8Gc+XH8GAi0spsG5NRxKt1vC8tm0llmLA6lrDpVvR/u68dMqpmYyTQkCBb4dj8UpbBM2tSx2t+2tDzG6ZjTErW8sPInS2Y0AVAUWdM00fk6lrtjGa31oQwg8E=", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAM1Z23LbNhCtlaBxLq06k1btTBvWk/glE4xHTlM7eUin1s12bEWKaDtppzMqTIISapJgQdCW8h996xf0A/p77YLQjbrYaaDOxA8yCUKH2MXZs7vQPyv5r1aQ1W6XeSgF9+MW/T1hgjZ5LEvEOTug/Xa78AN64Ei/WFxXs2ji8nVbstf0tEV9IrlgcE/OKapdMSl93B4+bk89rjERyybpUFQ1wmkKer4EmJe0t4zVHJKBUT8awez4PtozQignQtBQr2V5SCWzrQKIeCkYL8y867oKpiQoOYtR3QjLliR0iZDNSq0GU0yXVg1OqetSV2PtGmEdx/Q4ZA53qSFQmQeRoHFMXfTKzLpexIVsSe8Iom0n3g8Upw7M+"
//		"OB6O2p9PiOhYwp2wHzfjohDD1kILDs0W1kia5SmTCub70FFkIsSFy4VaN8wnOUhDzvawrIZ9xn4nRoyfkBRm4WdDxGrwpPTJWOZZRjYv6prroH1xJcMdq/GfGNNLnOfC8NyYFeQfuwQ37SsGOOYxVudh9zpCh4sEchMnLR4VogkjdDvo2PT3FChHgES2P1Y0qAaAkEhbAyZcEQUwc0waoIEy8FombpIafceJSC6cY1zCf8Mq4UWDfg5rQaR7Kd5Br00E+AzFkHwJUE4WCWyl0Cxxulv1JE1LgIipeKEGSj4sRFOuFJ70nBz9EqrxOkq4CNudymVhpujMScqQzOFVT1SiyrIuussEevtB4rVWyqWWe3ViGi44wHN9J6ihmk3xi+agoWywp0kgGYINc0B6yC4Xj+domp9Mz1PEcs86qeVdehCGoy6zInRL+aw0C41hF6tRg+5JJLxMDZ0g0pCrMMk8W3WCYlMBEWvzbI/"
//		"lWUqJPOYQyStQdYti34k+fE++kIDs6DT3vGBGcSmYZegu+PhEQp6qAfT/qSUSMnDHQf6H2IzSXfcgIUsloK4XJDhScn0VF5hMfFhmaCkJPNu2G2XKQ7xPLq1WXz83fdbm9tPt/JuIefl84XrVs5xPevOceuwvUf9qA3mUXiWy8GMVS9fyFk3TljMIM923XQwl7sG31u17tpdDi0CPwuIOIv1WrpWPnWPCgLoVGUS3374xwo4LUj8mHtyQz/agEkb2pUnjF5Q8Wjo1/EX8drcr+G1E8g7QIbnj4ubTzY2NzafFYsbRbxWhtoCNvR5SBPwlY/XmlD8MueA9o/4GQ2fg1lb8Oecks1nW0+2yUfW58qAJlGpW6XaoQV31RkVVccqIfVHpheue9plw4/cSvZ+8PGZ6xZWPBeewv2v1voczoF9kEpCVbq4ylaKrkuRUGtVKdKeDHx0nJ46tEjYodimaVKMdwVPohLv4Z85D3C6/"
//		"zplYq05EDAUZ04a8JQqWV/bSZpqX4LFtgR96aRLOSF+Qql1IxVE6SFx2dvTF7doDFWACkl9/yohPpP9iZWM5s+tavB0XaJfXmEesi97ebYkxYuKSjy8AEDVb1jFK3Rl0Y4U4A3gjTi+gE540lcP3wUwnTtAureIB3oS8ogfU+tO6oWh5jfGGWrkgUySz9y9zdz18GjZo1HrwWxiWWS51bgIp0xfxNgXEe2g/SsZO+wjcaYT1Pw56kcjxmgqlONzVL+UCoMtVo5vCJiu4GBaBPEMoopnSlXry1mTJpnfdD3097X/TP3hWRUM1KnscjcbEdPHdThz4IbHR2Z4fOiF5x1b4ezB03Rs40mm4oyleHbX8ZyCAC9K6fgKrqutUEkPrkFsD2nYkV08h+54cbLEM8KERwSlTiLAk1qd8TSoHtY7aJ930K3xBg405dRDj96FSDAx1YpvFgTJZDRrwji9pdO+GS4/lN5EMdp7b0mfziE3FWS151Af/"
//		"blimChGQj6/D8TzOzk8txfD091UKrlXKtjDRaxf9IX1xSyeFf05YTafS28CYN69OYE0mSNKTD4pWo+uWMCcNaevaLgxevq+G2Z9mrKTQ6nW5BAZBkhpjgOpJB6QNhOvn4yo9bhY3P7Q6ZU6dRcqliXGa5pP7b5/9v+UQasDlXybcfv9+VVhhkeD+mR9EUMX1QZHzFuqgwZMlpdjXsqNmdLz/qUSMBOqpSBapkVpOLwGhUo5335vs96xzta7Anaivy4Nr+wvU3jqtyU8/nUIT/6+g/UY+FA5YQSmRyfNxpnn6uZN+vnT/LpOe77elai6lM5Iez2VGlDeTDSsL9LsWYq7uZvQCOe+zXVdN3dLXxU+zt1Qg9bNOunpAMmtwePb6czt9Do/vv4XuqqThSAhAAA=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=AT", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$SaveTypeList", "Value=Adobe PDF File...", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioPageNumber", "Value=1", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$PagesRange", "Value=ctl00_Conteudo_StiWebRelatorioAll", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoom", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageFormat", "Value=Jpeg", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioExportMode", "Value=Table", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageResolution", "Value=10", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageCompressionMethod", "Value=Jpeg", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioImageQuality", "Value=10", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$BorderTypeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioSimple", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoomX", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioZoomY", "Value=0.25", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingTextOrCsvFile", "Value=1252", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ImageTypeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioColor", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingDifFile", "Value=437", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ExportModeGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioTable", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioSeparator", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncodingDbfFile", "Value=Default", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$SaveReportGroupBox", "Value=ctl00_Conteudo_StiWebRelatorioSaveReportMdc", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioPasswordSaveReport", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioUserPassword", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioOwnerPassword", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioEncryptionKeyLength", "Value=Bit40", ENDITEM, 
		"Name=ctl00$Conteudo$StiWebRelatorio$ctl00_Conteudo_StiWebRelatorioSubjectNameString", "Value=", ENDITEM, 
		"Name=ctl00$Conteudo$btnVoltar", "Value=Voltar", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=SG4LdgOsjRi5rvbOJMm0yIVUV+QjnSjKDluWBHtHG9FXy+kWa+RKIAMW4///0aXzAhKhZalEvYWJ10FgWYwhAPj3oatI80GLicX/i4TPTpKDy3Hokcmpt2SNVk9BZqKURoCWcoNiyioqgEeuVuDp1enmHTzFWvq5n9VLZwPhZzkoJ6lCufasPlV2hzs5ZcJYqqXLU461L+tj331i/bE76+54TFPYfSyU8EycGyOouaXfwRuRni9wZeeCIZm4F50ajnJiWjwJghMBTSryoh9dcYtI62f0czp+q+fQ/exF8RXkLMDAvOqgV1+gLJ+sHLAIC0JZ2SwHEPcxnK+me4FVHuap8sn4JJk1st0C5jiF8WwdnESM52rk7cZ6HAMxS/eQMFlzazoDxTff99iAdtkoPy8IpNS07mxaWBaanRm2urKBQ61uQ/"
//		"v6R4Qc0SmMCK0NUi8INhlizdCneOh1UV8P2443WbmYG2QT7bEjkFteNqTzHlfYwprD2X+02zdb98QWQ//V5TNBsKP5LUV+goQcfaQ+EuqtydcXHaupSpl2bFKIsyL4ZuY7b142l4eh6j2D8zvcGh/XV/uwP4mVPm9In4L8wrZerCKIqRTEhUH5G+mYrV7gxyJzVgEa7SnW3oEABVkB30N9rLN96NYtfvI2IpNefve/zh8YfS7sFQabWrohyxUA3n4FyL9cx+6OohPWpo1b+aUqxOx9Y+gSmdpJcOQW2mnO4h8ek9DkGxA8UYToOL4F2wnp8+aDOsztqTlISUcW/+xzVm9u8D8NOUeyzkv7gNj7aFN+a16ESauirZdI2lhsHECKA5ncMkFazdHVxOsYVemGPzPxG4j5EMRgogLa9IkfIySVFgCLIcM+D3jDSu9581gLpsYm0+T1N/6sHf1xaQBUXc6s4/"
//		"xqEa4vF6HoaexarAhW1r0dySeuDEcrQXwK/s4t3msI656JAujWqYQ4utzJKYGueTdcVTTxmXQFP8VS+JBiPmWBOK40734h4GwudSTJC5wmR0Zloe7PduSBqdtGE9SLqizySdohmZrwIOt6J/iyRqoJUh7VWh9tB7bdOL3eY92XbYByuST4EtLZF52rjxsJUnaWBPEvIXWVJI+OZz4WhUrzSTXeJY8BphV47NXEmKFsECcyAcKLMv9OFnQkYkXezx3FXiCkGYpRuF0w7/Av5LrJtvkqXTYlXl1DxSE4TozBuSIGpOofA5YQuu9sakfBFiD/BEOst2zhbzJw2At6r9M+BMVNwNtsHGds7Wti6ykVw1LVg8tPbe2A6nYRnhRdBcFzYjqoynIIRWkKegIYUt61xjBARWp9WX+gho0HG0FGlubEPxqDhdwQEy9LNFLIIEvcTILtg7I5ZrWA1EpVBjdIlYL+"
//		"oSiKiQTEnBEVDPdezzwn6bOOJMyhbHtG4WQlsP9GpGGh/opxehZ5fsqQhDFv01bowOiKCXk+r1LmJ/jtPe3Sa2xEUh2VJwLgxxAin7JPX1mNhPLeQUE7YEx4aQOL9QMBPfCaKjQZ5V4NRLfKMugFrvlEzPZMINjA9N96r+v4mtr0bsuw48+aj4jZXO5T+uAMY+ZPAajza/a8nWzQLzbHBMSRAuM7qXUP4OpHgE5DMPm9MiM4Lt/qxC3Byj0lS4gpr78N8E3TAjz+Hmlin2xCq2iSj23M8+N/UjAEnRVtUt8sD/Ugh7E5hbVbN9Gp8EJO3I6HDToJiFbUu7UVTniPIwV+"
//		"NSczFkBGwc0cV24kHmAzeRgshWhgQKHRQdFj6MnlpgAc6Khny3HHulPgKefSyBpAKDoo5YRJSaPWRnCLgLA0baN5INIitesN4SbtsPFcMjCI3LpFBLFgSIE0E766B0LATjMuBJw85T6EjWuAGCKG8H7cS91EPqRF3kK8KqbWRTexAEBOiDg2fsOOr+GA9C5FjDwQ+xhwEz7udwipZCw2gPHvgpB5W7goXfuUJi+CihCzWfoPRdErQ34DOGnsEAwLMTOgq5ljaRVKCtPSVZcgu0CEmuhUw0kp9gBM+6+/mWsqblr3P/qr23WYIY2/cFywsMzb0h83crbyUviWyelP8t7EF/NYzEbQplMYwP7slRCChJMCnyREoZ3ZG3uvliVZYfkBthmODOn0BMcM8tvzrPTNRIw8t9WwkA/ryoJlnZseMXYLwUgKRGxQbwSSv777qKffce2dv194ZplQrc6yhLt+"
//		"YkFjFlRDVNnFkvvkVT1jB1l81qXpBkOsm7mqkUnXixSOcJd5iGOELED7uiop5nuV5ULDmYoduLykAsPdsbNfuR7bqK8HXASBvJEXAG9o74qrET8rUElCvhS9r3e+xLR8Fx8rsJxSDVWt/4mUVwhAz0WzE1WpSv+JKkkD+nCYo+B8Jf1g2T4rVXtVlm9A5uhzB7fRFQ++Hh55nMkDiHRTqvq/qA6RkTpC8BjGEfKf1mcMdsne6xitMkwTKzcVYd/g/PkqzNcqeJiA+w3S1dSEn3PL1KI7CiSyT/Pmxy5Ki4s2c/WKm/1DNVLJ44WD9KLRBtiahbeZVP3NSeNFohXrEY9nwMusyttpoOXeIkoX9JA+pDJafXOTL0PZI5l6i4igewcp1PsEW4vC5pARnm87enUIMAECoh9Mkp9yWsTU6pYEbhFz93cGZeGsYpcdsdIh8o5Lu/9878JJoF6OR1+ho8vOy4WicWYxZM8qBoNtKgI2Bq8DCxj4N2"
//		"+K0sweKoqtG6p23Yez+SoHeyzpIFJA9J5gmEWVkavers2goWdXT/PL/V39Q8LovoyuWvfUpXia0rxAdRYPwLjG6MqY98d+WRTIiZ6QRC8GWhLY/82Vehte9UoUslXFsh6Hm93CEumxQMw3xQUDQDyXtF5QFeoIDdrYm0dfVrocUZIE6g5IxrKmXDK0MZeJxv+oYANtP8BLJnGkzfeKfg3XytAQH25xB1QtKP1W9YX0RTudIkf/54IR4k9gf60t4wOn3klZyjsOkZ6kSJbhb88VRDVLGomT3CScyFOou+2zC57PhpjaocSAMTbOB+zvhXCJI39moLpuYhYPU6BZb5UYJOcuS/VlkYJ2FJmJ4xpNmdVkNKzMCgWAYTD3e6ft52TcBiXA07yHhrolYZ43XCPzDFov8iTE9Z7mFVJ5qR20CknrrCmPHRcDI7ec7Jaowut087XMDMQunJTFOST/"
//		"JTqMHck1Svi1ZAhvMSTBN6j44i9J96iQbTMW13g3EBu4liu/ND941HParttFwSYAuWToSeTtYoNsrFrQ", ENDITEM, 
		LAST);

	/* Request with GET method to URL "https://{domain}/NewconWeb/includes/imagens/Arrow_top_header.gif" failed during recording. Server response : 404*/

	lr_end_transaction("ID500_BW_09_VoltarParaOferta",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_10_VoltarAoInicio");

	web_reg_save_param_regexp(
		"ParamName=pVState",
		"RegExp=id=\"__VSTATE\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=pEventValidation",
		"RegExp=id=\"__EVENTVALIDATION\" value=\"(.*?)\" />",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		LAST);		

	web_url("frmMain.aspx_2", 
		"URL=https://{domain}/NewconWeb/frmMain.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{domain}/NewconWeb/CONCP/frmConCpCadCredenciamentoLance.aspx?applicationKey=oDlGaetLIS1/SzzqB0SZ/gpyYQ+WdzhppcHPJNBdau0csfuV2KyaIpCV5LlUB/uL", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		EXTRARES, 
//		"Url=http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg", "Referer=", ENDITEM, 
		LAST);

//	web_revert_auto_header("Sec-Fetch-User");
//
//	web_revert_auto_header("Upgrade-Insecure-Requests");
//
//	web_revert_auto_header("sec-ch-ua");
//
//	web_revert_auto_header("sec-ch-ua-mobile");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"none");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"no-cors");
//
//	web_add_auto_header("Sec-Fetch-Dest", 
//		"empty");
//
//	web_custom_request("json_7", 
//		"URL=https://update.googleapis.com/service/update2/json", 
//		"Method=POST", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t122.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"event\":[{\"download_time_ms\":31039,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":19066,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms"
//		"\":4030,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":0,\"url\":\"http://redirector.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":28062,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":-2145386477,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":19066,\"url\":\""
//		"https://edgedl.me.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":4023,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":0,\"url\":\"https://redirector.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":4029,\"downloaded\":0,\"downloader\":\"bits\",\""
//		"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":0,\"url\":\"http://dl.google.com/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":4039,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":0,\"url\":\"https://dl.google.com/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/"
//		"I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":4025,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":0,\"url\":\"http://www.google.com/dl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":4026,\"downloaded\":0,\"downloader\":\"bits\",\"errorcode\":12,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\","
//		"\"total\":0,\"url\":\"https://www.google.com/dl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"download_time_ms\":596,\"downloaded\":19066,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2657\",\"previousversion\":\"2644\",\"total\":19066,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/chrome_component/AIQWwBRSWwfx2JCxD0aw30k_2657/I-4-aBwqaCFG5rMUT0QDpg\"},{\"eventresult\":1,\"eventtype\":3,\"nextfp\":\""
//		"1.c963f6d51cdf6ffd8352f0a7feeb3a5bde0cbfdcf1cdb7598ba8b58f06bf0207\",\"nextversion\":\"2657\",\"previousfp\":\"1.da6e5438360451f080aa9a979fdf5e13097788f7f07530c48a9c2b9564cae34c\",\"previousversion\":\"2644\"}],\"version\":\"2657\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"hw\":{\"physmemory\":128},\"lang\":\"pt-BR\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1999\"},\"prodversion\":\"91.0.4472.124\",\"protocol\":\"3.1\",\"requestid\":\""
//		"{5ed0beb8-f343-4cdc-bcdb-90c3e01a4ebe}\",\"sessionid\":\"{25936182-bad7-4e82-b6b5-916b4e7888f6}\",\"updaterversion\":\"91.0.4472.124\"}}", 
//		LAST);

	lr_end_transaction("ID500_BW_10_VoltarAoInicio",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("ID500_BW_11_Logout");

	web_add_header("Origin", 
		"https://{domain}");

//	web_add_auto_header("Sec-Fetch-Dest", 
//		"document");
//
//	web_add_auto_header("Sec-Fetch-Mode", 
//		"navigate");
//
//	web_add_auto_header("Sec-Fetch-Site", 
//		"same-origin");
//
//	web_add_header("Sec-Fetch-User", 
//		"?1");
//
//	web_add_header("Upgrade-Insecure-Requests", 
//		"1");
//
//	web_add_header("sec-ch-ua", 
//		"\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
//
//	web_add_header("sec-ch-ua-mobile", 
//		"?0");

	web_submit_data("frmMain.aspx_3", 
		"Action=https://{domain}/NewconWeb/frmMain.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{domain}/NewconWeb/frmMain.aspx", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=ctl00$Conteudo$lkbSair", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_SelectedNode", "Value=ctl00_Conteudo_tvwEmpresat1", ENDITEM, 
		"Name=ctl00_Conteudo_tvwEmpresa_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwAgenda_PopulateLog", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_ExpandState", "Value=en", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_SelectedNode", "Value=", ENDITEM, 
		"Name=ctl00_Conteudo_tvwConexoesUsuario_PopulateLog", "Value=", ENDITEM, 
		"Name=__VSTATE", "Value={pVState}", ENDITEM,
//		"Name=__VSTATE", "Value=H4sIAAAAAAAEAJWU328aRxDHYc3BYeNcojYoraVj00RqUrfc8aOhQpalCyD3VIwjwM7jac0ux6p3t/R2oeQlUv+GvvW1D5X63r+APyzdvYPaMW6lLg83mvnuzsyH2f2QNZ7saabndVgkYhbwIflpQWPyhnHxGk1+/IG887yyrn02EYFtP1cqssDsuVj+3AvnMeFIe7IbcnwSYaQ93Y1Im6wY4Zd8gWLKtMephIa+5wSCxGhEohnSPrlxD0mABFPal6nTDZFPXi+EYJEzIZyjERXEwSGNKBcxwixG2rP7paxLOQpUDROBPsotZME0JJFg2hd3qvZj3GECcbl3ziK6JJQbPtY+35UNmKATirhxcpwpgfzj7L7b9TZOHXyQy8CGdvBNrdVstuxGs/XKwGUwNYxyzgQTPDVLl8O+"
//		"9z0J5t5bck1kDACp0KdGGZiFK8rpdUBmOHGWQFZ5izSKSDwTYaCVxpIUdCOVLcBgLzk2NyYroR29dc4GvSF8c9Hv98YufGGnq/7qu5dmYcxYMKbz/1RhDAqqWJlVNlcEGaOcNw8HZEni3mqOIkwwNksjEkiyRILARDtKAHlbQN7NyIiaWewjLly5bQUA1j89zgBtz27byijnKzmtsJGa2hUKFkTL2qa+TeR/LNel/Gu7Ztfg2bnTgU733B24o/HQ6V4MHdjtwc7FYLT+ddhxL0awP+46laKWrZn6tli/su/L9oqKNNDvNlnJ40oBV/TdMlXefDrp6kR7274zEZRFB19VR++4IGFV/pXVS1d9tnesOo4JUYxub9iTZewmsE7o6RWbrP+"
//		"E0fp3BuV5MGJLxiHifCGnlcMIwbSIpycWPZWVHL23ZMfOmTWNQ5nR8dNwFfH5ytSTK3EZB9qX7y2q7IhbanC8zeBYqdpzlpSz6jza0Dm4xSUruYBKXrkf3O9+pCzg/x+SphtNWRyi9R/rvwiHnF3HBCI4Ue+F7DwhXCkdHOd2Oe3L7b9kJaj1b4GgIYMoueuwDe2GZbesul2vwVqrbTfbzRb8Z6UvAnTEAgV3pY1G227cSE+uY2idJk8TJKs5jeUnbMP6t1atnuxJ0ZPKofbiX7AmDx9it7hum0noKl4zyaugeD0C2YfljPqVZIMZDA438Zyc0ocYlzMK8X3CopEq5Zn7mz15eWbyUpyjVZ9EvpgBmKRU8QeJbdzYfwNZRor3EAYAAA==", ENDITEM, 
		"Name=__VIEWSTATE", "Value=", ENDITEM, 
		"Name=ctl00$hdnID_Modulo", "Value=", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value={pEventValidation}", ENDITEM,
//		"Name=__EVENTVALIDATION", "Value=FMlZ5WkMY5IVzRDJi48uoGUVWZT0BFKpcSuTRXHawvPizQGFeKrTMEIvAe6IxSj4h6nOeSo1SgvN/vIZv8ro3A97T5AZezt2fmp1ZGxFpMU28Nk+MKgoZ/xBLf1cP8smGVbhwK+jL4WpO3o2KzmWTyzsxXJBPcmSDCmGmWLrBn92mCnoGtgYCgc2d+u3y5x8t2lCSoaTy6Rculc8QK7XnfzaHLhI2TCiVl+yZzIUOKCZLvnSq5CiQBx+7CZikuy/OgGuCw==", ENDITEM, 
		LAST);

	lr_end_transaction("ID500_BW_11_Logout",LR_AUTO);

//	DXC_AppendFile(lr_eval_string("{LogFileName}"), lr_eval_string("{grupo},{cota},{versao},,{senha}"));
//	DXC_AppendFile(lr_eval_string("{LogFileName}"), lr_eval_string("{pUser},{NM_Usuario}"));

	return 0;
}