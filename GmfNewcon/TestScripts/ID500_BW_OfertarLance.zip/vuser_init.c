/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{
    DXC_Init(0);
//    lr_param_sprintf("LogFileName", "..\\ID500_DW_gooddata-%s-vu%d.dat", lr_eval_string("{rightnow}"), vuser_id);
//    DXC_AppendFile(lr_eval_string("{LogFileName}"), "grupo,cota,versao,cpf,senha");
//    DXC_AppendFile(lr_eval_string("{LogFileName}"), "CD_Usuario,NM_Usuario");
	return 0;
}