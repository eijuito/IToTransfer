#ifndef _DXC_UTILS_
#define _DXC_UTILS_

// =====================================================
// Include files
// -----------------------------------------------------
#include "stdio.h"
#include "stdlib.h"
// =====================================================
// Global variables
// -----------------------------------------------------
int vuser_init_ok = 0;
int vuser_id, scenario_id;
char *vuser_group;
char vuser_start_time[MAX_DATETIME_LEN];
// =====================================================
// Function declarations
// -----------------------------------------------------
int DXC_Init(int print_message);
int DXC_LoadFileToParameter(char *fileName, char *parameterName);
int DXC_AppendFile(char *filename, char* text);
// =====================================================
// Function code
// -----------------------------------------------------
int DXC_Init(int print_message) {
	int rc = 0;
	lr_whoami(&vuser_id, &vuser_group, &scenario_id);
	lr_save_datetime("D%Y%m%dT%H%M%S", DATE_NOW, "rightnow");
	if(print_message) {
		lr_message("*** start time: %s: group: %s, vuser: %d, scenario: %d, hostname: %s, controller: %s",
		           lr_eval_string("{rightnow}"),
		           vuser_group,
		           vuser_id,
		           scenario_id,
		           lr_get_host_name(),
		           lr_get_master_host_name());
	}
	vuser_init_ok = rc;
	return rc;
}
// -----------------------------------------------------
int DXC_LoadFileToParameter(char *fileName, char *parameterName) {
	FILE *f;
	long numBytes;
	char *b;
	
	int rc = 0;
	if((f = fopen(fileName, "r")) == NULL) {
		lr_error_message("Unable to open %s", f);
		return LR_FAIL;
	}
	fseek(f, 0L, 2); // 2 = SEEK_END
	numBytes = ftell(f);
	fseek(f, 0L, 0); // 0 = SEEK_SET
	b = (char *)calloc(numBytes, sizeof(char));
	if(b == NULL) {
		lr_error_message("Unable to allocate buffer of %d bytes", numBytes);
		fclose(f);
		return LR_FAIL;
	}
	fread(b, sizeof(char), numBytes, f);
	lr_save_string(b, parameterName);
	fclose(f);
	return LR_PASS;
}
// -----------------------------------------------------
int DXC_AppendFile(char *filename, char* text) {
	FILE *ActFile;
	int rc = 0;
  	if((ActFile = fopen(filename, "a")) == NULL) {
		lr_error_message("ERROR: Failed to open file for appending: %s", filename);
		return -1;
	}
	fprintf(ActFile, "%s\n", text);
	fclose(ActFile);
	return rc;
}
// =====================================================
// -----------------------------------------------------

// =====================================================
#endif /* _DXC_UTILS_ */