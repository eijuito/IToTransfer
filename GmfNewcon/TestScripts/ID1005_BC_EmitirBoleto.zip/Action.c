/****************************************************************************************/
/* Criado por: Fabio Hashiguchi                                                         */
/* Criado em:  05/06/2021                                                               */
/*                                                                                      */
/* Sistema: Business Core                                                               */
/* Funcionalidade: ID1005 Emitir Boleto                                                 */
/* Pre-requisitos: Consorciado (Grupo/Cota/Vers�o) precisa ter boleto pendente, sendo   */
/* que o script seleciona a segunda pend�ncia da lista                                  */
/****************************************************************************************/

Action()
{
	
	lr_start_transaction("ID1005_BC_01_IniciaRDP");	

	rdp_connect_server("Host={pHost}", 
		"UserName={pUser}", 
		"EncryptedPassword=60bc02f4e", 
		"Domain=", 
		RDP_LAST);

	rdp_set_lock("StepDescription=Lock Key Set 1", 
		"LockKeyValue=VK_NUMLOCK", 
		RDP_LAST);

	lr_end_transaction("ID1005_BC_01_IniciaRDP", LR_AUTO);

	lr_think_time(10);
	
	/*	This script contains keyboard steps without automatic synchronization.
		Consider adding a synchronization step before the relevant keyboard steps.*/

	lr_start_transaction("ID1005_BC_02_OK");
	
	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=260", "ImageTop=485", "ImageWidth=53", "ImageHeight=53", "ImageName=snapshot_111.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 1", 
		"Snapshot=snapshot_57.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_02_OK",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_03_LoginRDP");	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=356", "ImageTop=483", "ImageWidth=97", "ImageHeight=47", "ImageName=snapshot_112.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 2", 
		"Snapshot=snapshot_58.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 1", 
		"Snapshot=snapshot_59.inf", 
		"TypedKeys={pPassword}", 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 3", 
		"Snapshot=snapshot_60.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 4", 
		"Snapshot=snapshot_61.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_03_LoginRDP",LR_AUTO);
	
	lr_think_time(10);

	lr_start_transaction("ID1005_BC_04_NewCon");
	
	/*Tenta abrir o NewCon pela primeira vez*/	
	
	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=4", "ImageTop=208", "ImageWidth=86", "ImageHeight=82", "ImageName=snapshot_113.png", ENDIMAGE, 
		RDP_LAST);
	
	rdp_key("StepDescription=Key Press 5", 
		"Snapshot=snapshot_63.inf", 
		"KeyValue=N", 
		"KeyModifier=CONTROL_KEY,ALT_KEY", 
		RDP_LAST);
	
	/*Responde No para deletar o shortcut*/	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=369", "ImageTop=343", "ImageWidth=316", "ImageHeight=115", "ImageName=snapshot_114.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 6", 
		"Snapshot=snapshot_64.inf", 
		"KeyValue=N", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);
	
	/*Tenta abrir o NewCon pela segunda vez*/	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=3", "ImageTop=213", "ImageWidth=74", "ImageHeight=73", "ImageName=snapshot_115.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 7", 
		"Snapshot=snapshot_65.inf", 
		"KeyValue=N", 
		"KeyModifier=CONTROL_KEY,ALT_KEY", 
		RDP_LAST);
	
	/*Responde Run para executar o NewCon*/	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=374", "ImageTop=342", "ImageWidth=251", "ImageHeight=71", "ImageName=snapshot_116.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 8", 
		"Snapshot=snapshot_66.inf", 
		"KeyValue=R", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_04_NewCon",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("ID1005_BC_05_LoginNewCon");	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=395", "ImageTop=392", "ImageWidth=103", "ImageHeight=46", "ImageName=snapshot_117.png", ENDIMAGE, 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 2", 
		"Snapshot=snapshot_67.inf", 
		"TypedKeys={pUsuario}", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=392", "ImageTop=428", "ImageWidth=100", "ImageHeight=49", "ImageName=snapshot_118.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 9", 
		"Snapshot=snapshot_68.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 3", 
		"Snapshot=snapshot_69.inf", 
		"TypedKeys={pSenha}", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=512", "ImageTop=470", "ImageWidth=84", "ImageHeight=48", "ImageName=snapshot_119.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 10", 
		"Snapshot=snapshot_70.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=509", "ImageTop=472", "ImageWidth=86", "ImageHeight=39", "ImageName=snapshot_120.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 11", 
		"Snapshot=snapshot_71.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_05_LoginNewCon",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_06_SistemaNewCon");	

	rdp_sync_on_image("StepDescription=Image Synchronization 1", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=252", "ImageTop=217", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_73.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 1", 
		"Snapshot=snapshot_72.inf", 
		"MouseX=272", 
		"MouseY=237", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_06_SistemaNewCon",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_07_Atendimento");	

	rdp_sync_on_image("StepDescription=Image Synchronization 2", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=13", "ImageTop=135", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_75.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 2", 
		"Snapshot=snapshot_74.inf", 
		"MouseX=33", 
		"MouseY=155", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_07_Atendimento",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_08_LocalizarConsorciado");	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=481", "ImageTop=319", "ImageWidth=60", "ImageHeight=50", "ImageName=snapshot_121.png", ENDIMAGE, 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 4", 
		"Snapshot=snapshot_76.inf", 
		"TypedKeys={pGrupo}", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=550", "ImageTop=321", "ImageWidth=45", "ImageHeight=49", "ImageName=snapshot_122.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 12", 
		"Snapshot=snapshot_77.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 5", 
		"Snapshot=snapshot_78.inf", 
		"TypedKeys={pCota}", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=596", "ImageTop=337", "ImageWidth=27", "ImageHeight=28", "ImageName=snapshot_123.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 13", 
		"Snapshot=snapshot_79.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_type("StepDescription=Typed Text 6", 
		"Snapshot=snapshot_80.inf", 
		"TypedKeys={pVersao}", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=515", "ImageTop=505", "ImageWidth=77", "ImageHeight=36", "ImageName=snapshot_124.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 14", 
		"Snapshot=snapshot_81.inf", 
		"KeyValue=VK_TAB", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=514", "ImageTop=505", "ImageWidth=73", "ImageHeight=39", "ImageName=snapshot_125.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 15", 
		"Snapshot=snapshot_82.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_08_LocalizarConsorciado",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_09_EmissaoCobranca");	

	rdp_sync_on_image("StepDescription=Image Synchronization 3", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=140", "ImageTop=274", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_84.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 3", 
		"Snapshot=snapshot_83.inf", 
		"MouseX=160", 
		"MouseY=294", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_09_EmissaoCobranca",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_10_LocalizarPendencias");	

	rdp_sync_on_image("StepDescription=Image Synchronization 4", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=317", "ImageTop=175", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_86.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 4", 
		"Snapshot=snapshot_85.inf", 
		"MouseX=337", 
		"MouseY=195", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=550", "ImageTop=547", "ImageWidth=70", "ImageHeight=34", "ImageName=snapshot_126.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 16", 
		"Snapshot=snapshot_87.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 5", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=757", "ImageTop=236", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_89.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 5", 
		"Snapshot=snapshot_88.inf", 
		"MouseX=777", 
		"MouseY=256", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_10_LocalizarPendencias",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_11_SelecionarPendencia");

	/*Seleciona sempre a segunda linha*/	

	rdp_sync_on_image("StepDescription=Image Synchronization 6", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=140", "ImageTop=314", "ImageWidth=20", "ImageHeight=37", "ImageName=snapshot_127.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_double_click("StepDescription=Mouse Double Click 1", 
		"Snapshot=snapshot_90.inf", 
		"MouseX=153", 
		"MouseY=342", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_11_SelecionarPendencia",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_12_ImprimirBoleto");	

	rdp_sync_on_image("StepDescription=Image Synchronization 7", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=468", "ImageTop=613", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_95.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 6", 
		"Snapshot=snapshot_94.inf", 
		"MouseX=488", 
		"MouseY=633", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_12_ImprimirBoleto",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_13_OK_Enviado");	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=670", "ImageTop=427", "ImageWidth=35", "ImageHeight=37", "ImageName=snapshot_128.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 17", 
		"Snapshot=snapshot_96.inf", 
		"KeyValue=VK_RETURN", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_13_OK_Enviado",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_14_FecharBoleto");		

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=985", "ImageTop=0", "ImageWidth=26", "ImageHeight=22", "ImageName=snapshot_129.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 18", 
		"Snapshot=snapshot_97.inf", 
		"KeyValue=VK_F4", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_14_FecharBoleto",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_15_NaoEmitirOutro");			

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=557", "ImageTop=427", "ImageWidth=31", "ImageHeight=34", "ImageName=snapshot_130.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 19", 
		"Snapshot=snapshot_98.inf", 
		"KeyValue=N", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_15_NaoEmitirOutro",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_16_FecharJanelas");		

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=923", "ImageTop=65", "ImageWidth=23", "ImageHeight=18", "ImageName=snapshot_131.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 20", 
		"Snapshot=snapshot_99.inf", 
		"KeyValue=VK_F4", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=703", "ImageTop=190", "ImageWidth=24", "ImageHeight=24", "ImageName=snapshot_132.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 21", 
		"Snapshot=snapshot_100.inf", 
		"KeyValue=VK_F4", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=983", "ImageTop=3", "ImageWidth=30", "ImageHeight=16", "ImageName=snapshot_133.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 22", 
		"Snapshot=snapshot_101.inf", 
		"KeyValue=VK_F4", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);
	
	lr_end_transaction("ID1005_BC_16_FecharJanelas",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_17_EncessarSessao");	

	rdp_sync_on_image("StepDescription=Image Synchronization", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=454", "ImageTop=427", "ImageWidth=35", "ImageHeight=33", "ImageName=snapshot_134.png", ENDIMAGE, 
		RDP_LAST);

	rdp_key("StepDescription=Key Press 23", 
		"Snapshot=snapshot_102.inf", 
		"KeyValue=Y", 
		"KeyModifier=ALT_KEY", 
		RDP_LAST);

	lr_end_transaction("ID1005_BC_17_EncessarSessao",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_18_Sair");	
	
	rdp_sync_on_image("StepDescription=Image Synchronization 8", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=817", "ImageTop=71", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_104.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 7", 
		"Snapshot=snapshot_103.inf", 
		"MouseX=837", 
		"MouseY=91", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	lr_end_transaction("ID1005_BC_18_Sair",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("ID1005_BC_19_DesconectarRDP");		
	
	rdp_sync_on_image("StepDescription=Image Synchronization 9", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=9", "ImageTop=725", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_106.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 8", 
		"Snapshot=snapshot_105.inf", 
		"MouseX=29", 
		"MouseY=745", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 10", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=3", "ImageTop=594", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_108.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 9", 
		"Snapshot=snapshot_107.inf", 
		"MouseX=23", 
		"MouseY=614", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_image("StepDescription=Image Synchronization 11", 
		"WaitFor=Appear", 
		"AddOffsetToInput=Default", 
		IMAGEDATA, 
		"ImageLeft=12", "ImageTop=538", "ImageWidth=40", "ImageHeight=40", "ImageName=snapshot_110.png", ENDIMAGE, 
		RDP_LAST);

	rdp_mouse_click("StepDescription=Mouse Click 10", 
		"Snapshot=snapshot_109.inf", 
		"MouseX=32", 
		"MouseY=558", 
		"MouseButton=LEFT_BUTTON", 
		"Origin=Default", 
		RDP_LAST);

	rdp_sync_on_server_disconnect("StepDescription=Sync on Server Disconnect 1", 
		RDP_LAST);
	

	lr_end_transaction("ID1005_BC_19_DesconectarRDP",LR_AUTO);	

	return 0;
}