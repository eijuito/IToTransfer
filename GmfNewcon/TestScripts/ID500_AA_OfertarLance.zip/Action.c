//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("ID500_AA_01_LoadURL");
	truclient_step("14", "Navigate to URL", "snapshot=Action_14.inf");
	lr_end_transaction("ID500_AA_01_LoadURL",0);
	lr_start_transaction("ID500_AA_02_Login");
	truclient_step("15", "Click on Grupo/Cota", "snapshot=Action_15.inf");
	truclient_step("16", "Acessar", "snapshot=Action_16.inf");
	{
		truclient_step("16.1", "Click on Grupo textbox", "snapshot=Action_16.1.inf");
		truclient_step("16.2", "Type grupo in Grupo textbox", "snapshot=Action_16.2.inf");
		truclient_step("16.3", "Type cota in Cota textbox", "snapshot=Action_16.3.inf");
		truclient_step("16.4", "Type versao in Vers�o textbox", "snapshot=Action_16.4.inf");
		truclient_step("16.5", "Type ***** in Senha passwordbox", "snapshot=Action_16.5.inf");
		truclient_step("16.6", "Click on Acessar button", "snapshot=Action_16.6.inf");
	}
	lr_end_transaction("ID500_AA_02_Login",0);
	lr_start_transaction("ID500_AA_03_LinkLanceLivre");
	truclient_step("18", "Click on Lance Livre", "snapshot=Action_18.inf");
	truclient_step("20", "Click on ofertar um Lance Livre", "snapshot=Action_20.inf");
	lr_end_transaction("ID500_AA_03_LinkLanceLivre",0);
	lr_start_transaction("ID500_AA_04_LinkValor");
	truclient_step("22", "Click on Valor (%)", "snapshot=Action_22.inf");
	truclient_step("24", "Get Visible Text from Valor minimo", "snapshot=Action_24.inf");
	truclient_step("25", "Right click on Valor minimo", "snapshot=Action_25.inf");
	truclient_step("27", "Click on Valor textbox", "snapshot=Action_27.inf");
	truclient_step("28", "Type pValue in Valor textbox", "snapshot=Action_28.inf");
	truclient_step("30", "Click on CONTINUAR button", "snapshot=Action_30.inf");
	lr_end_transaction("ID500_AA_04_LinkValor",0);
	lr_start_transaction("ID500_AA_05_NaoRepetir");
	truclient_step("32", "Click on Ant Radio radiogroup", "snapshot=Action_32.inf");
	truclient_step("34", "Click on CONTINUAR button", "snapshot=Action_34.inf");
	lr_end_transaction("ID500_AA_05_NaoRepetir",0);
	lr_start_transaction("ID500_AA_06_ReduzirParcela");
	truclient_step("36", "Click on Reduzir Parcela", "snapshot=Action_36.inf");
	lr_end_transaction("ID500_AA_06_ReduzirParcela",0);
	lr_start_transaction("ID500_AA_07_ConfirmarLance");
	truclient_step("38", "Click on CONFIRMAR button", "snapshot=Action_38.inf");
	lr_end_transaction("ID500_AA_07_ConfirmarLance",0);
	lr_start_transaction("ID500_AA_08_ImprimirComprovante");
	truclient_step("40", "Click on IMPRIMIR COMPROVANTE button", "snapshot=Action_40.inf");
	lr_end_transaction("ID500_AA_08_ImprimirComprovante",0);
	lr_start_transaction("ID500_AA_09_Logout");
	truclient_step("42", "Click on button (1) button", "snapshot=Action_42.inf");
	truclient_step("44", "Click on button (2) button", "snapshot=Action_44.inf");
	truclient_step("45", "Mouse Over", "snapshot=Action_45.inf");
	truclient_step("46", "Click on Sair button", "snapshot=Action_46.inf");
	truclient_step("47", "Click on Sair", "snapshot=Action_47.inf");
	lr_end_transaction("ID500_AA_09_Logout",0);

	return 0;
}
